# Story Reference Writing

Load `/creative-writing-skills:llm-writing` if it is not already loaded. This resource is for story
support material, not narrative prose: clear, durable, source-aware writing
that supports the story instead of becoming it. Every entry needs a reader, a
purpose, and a reason to exist. `resources/kb-layout.md` says where each page
lives.

Pick the mode that matches the artifact:

- **Fact extraction**: turn chapters, scenes, or sessions into durable story
  facts. Follow `resources/fact-extraction.md`.
- **Wiki / reference writing**: explain a story concept. Below.
- **Vocabulary writing**: record canonical terms, aliases, deprecated names,
  and boundaries, which prevents two names for one thing, one name for two
  things, or a term used outside its meaning. The entry fields are in
  `resources/kb-layout.md` § Vocab Pages; `/creative-writing-skills:shared-dao` covers vocabulary
  discipline.
- **Decision capture**: record a settled creative choice. Below.
- **Issue logging**: preserve a writing problem that outlasts the current
  pass. Follow `resources/writing-issues.md`.

## Wiki / Reference Writing

Explain a story concept so future workers can use it: a location, faction,
magic rule, relationship, object, timeline, or recurring motif. Prioritize
mechanism and boundaries over pretty summary.

Read before writing:
- Source passages or decisions
- Existing related kb pages
- Vocab and naming conventions

A good reference page answers: what is it, how does it work, where is it shown,
what does it constrain, and what remains unknown?

## Decision Capture

Record a settled creative choice that will affect future work on its topic
page: the choice, its reason, and what it changes downstream. Name a
rejected alternative only with what ruled it out. Live brainstorm options
stay out.
