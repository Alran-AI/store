# Dependency Review

Repository: {{repository}}
Question: {{question}}

## Workflow

1. Verify `.ontoly/SoftwareGraph.json`.
2. Build with `ontoly build .` if missing.
3. Check trust with `ontoly coverage .`.
4. Use Ontoly MCP capabilities: `FindDependencies`, `FindDependents`, `FindCycles`, `GraphStatistics`.
5. Inspect files only if Ontoly cannot answer.

## Response

- Summary:
- Capabilities invoked:
- Evidence:
- Confidence:
- Fallbacks used:
- Recommended next action:
