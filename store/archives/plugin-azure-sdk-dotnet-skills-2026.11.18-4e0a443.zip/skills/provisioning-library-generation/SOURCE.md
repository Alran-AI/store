# Source

Unmodified copy of `.github/skills/provisioning-library-generation` from https://github.com/Azure/azure-sdk-for-net
at commit 4e0a443400dbd982431646b449475bf5d4aadf94 (2026-11-18), under the MIT licence.

Copyright (c) 2015 Microsoft

The licence text is in LICENSE.txt. Nothing in this folder was edited.
