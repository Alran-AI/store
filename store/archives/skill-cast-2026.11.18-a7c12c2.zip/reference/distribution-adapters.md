# Cast Distribution Adapters

Purpose: Adapt personas for downstream agents without changing the underlying persona record.

## Contents

1. Adapter overview
2. Echo adapter
3. Spark adapter
4. Growth adapter
5. Compete adapter
6. Scribe[unified] adapter
7. Generic fallback
8. Selection logic
9. Multi-persona delivery

## Adapter Overview

| Adapter | Focus |
|---|---|
| Echo | testing flows, friction, confidence, recent changes |
| Spark | unmet needs, opportunity signals, constraints |
| Growth | lifecycle, churn risk, re-engagement |
| Compete | expectations, switching behavior, loyalty anchors |
| Scribe[unified] | business context, alignment, decision confidence |
| Generic | minimal neutral summary |

## Echo Adapter

Use exact anchor:

`## ECHO_CONTEXT`

Required sections:

- `Persona Confidence`
- `Recent Changes`
- `Recommended Review Priority`

## Spark Adapter

Required sections:

- `## Persona: {name}`
- `### Unmet Needs`
- `### Feature Opportunity Signals`
- `### Constraints`
- `### Key Behaviors (Design Constraints)`

## Growth Adapter

Required sections:

- `## Persona: {name}`
- `### Engagement Profile`
- `### Value Drivers (Why They Stay)`
- `### Churn Risk Factors`
- `### Re-engagement Triggers`
- `### Lifecycle Recommendations`

## Compete Adapter

Required sections:

- `## Persona: {name}`
- `### Expectations Baseline`
- `### Comparison Behavior`
- `### Competitive Vulnerability`
- `### Loyalty Anchors`

## Scribe[unified] Adapter

Required sections:

- `## Persona: {name}`
- `### Business Summary`
- `### Key Metrics Context`
- `### Business Objectives Alignment`
- `### Risk Areas`
- `### Decision Confidence`

## Generic Adapter

Required sections:

- `## Persona Summary: {name}`
- `### Core`
- `### Context`
- `### File`

## Adapter Selection Logic

| Target | Adapter |
|---|---|
| Echo | Echo adapter |
| Spark | Spark adapter |
| Growth | Growth adapter |
| Compete | Compete adapter |
| Scribe[unified] | Scribe[unified] adapter |
| Unknown | Generic fallback |

## Multi-Persona Delivery

When sending more than one persona, include:

- `## Cast Distribution: {service_name} -> {target_agent}`
- `### Quick Comparison`
- `### Individual Profiles`
- `### Cross-Persona Patterns`
