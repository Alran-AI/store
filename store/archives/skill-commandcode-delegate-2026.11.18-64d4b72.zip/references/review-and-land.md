# Review and land

Command Code did the typing; you own the judgment. This is where delegation earns its keep or quietly
ships a mistake. The discipline is simple to state and easy to skip under time pressure: **verify
against reality, never against the self-report — and read the diff as generated code, which fails in
ways a green gate can't see.**

One thing to add to the usual routine here: the run had no sandbox. An implementation dispatch goes out
under `--yolo`, so "did it stay inside the brief's paths?" is a question requiring more than `touchedFiles`,
not one the tooling answered for you.

## Check the tests before trusting the gates

If the diff touches existing tests, review those edits *first* — before the gate re-run means anything.
A weakened assertion, an added skip, or a deleted test makes the gate measure less than it did before
the run; green is only meaningful if the yardstick wasn't shortened.

- **Unbriefed edits to existing tests are a contract change, not part of the fix.** The brief asked for
  an implementation; nothing in it authorized moving the goalposts. Flag them, don't absorb them.
- **Skipped, disabled, or commented-out tests added in this diff:** treat the underlying test as failing
  until proven otherwise, whatever the annotation's comment claims.
- **Loosened assertions** (exact match relaxed to contains/truthy, error-type checks broadened, tolerance
  widened): same treatment.

## Re-run the gates yourself

`result.json` carries Command Code's own claim that the gates passed. Treat that as a claim, not
evidence — re-run the project's actual test/lint/build commands in the working tree and read the output.
And keep the result in proportion: **passing is necessary, not sufficient.** An implementer can *game* a
gate, not just misreport it — that is what the test check above and the sweep below exist to catch.

For changes with their own verification shape, go further:

- **Migrations / schema:** round-trip them (apply, reverse, re-apply on a scratch target) and check for
  drift, rather than trusting that "the migration is reversible."
- **Removals / renames:** grep the codebase for dangling references to whatever was removed.
- **Anything stateful:** exercise the actual behavior, don't just confirm it compiles.

## Read the diff against the brief

Open the diff (`touchedFiles` in the result is your starting list) and hold it against what you asked
for:

- **Out-of-scope writes** — this is the first check here, not an afterthought. Under `--yolo` there was
  nothing stopping a write outside `--cd` or outside the paths the brief named. `touchedFiles` is a
  `git status` review aid, not containment proof: it misses ignored files and anything outside the
  repository. A worktree isolates the checkout but not the process. Use a container or another
  OS-enforced boundary when writes outside the target tree are unacceptable.
- **Scope creep** — did it change things the brief said to leave untouched? Unasked refactors, renames,
  "while I was here" edits. These are the most common quality problem in delegated work.
- **Scope shortfall** — did it do the whole task, including the edge cases and cleanup, or stop at the
  first plausible version? A `stopReason` of `max_turns` in `result.json` is a strong hint of a run that
  stopped mid-task rather than finishing.
- **Quiet judgment calls** — sometimes Command Code makes a defensible decision the brief didn't
  anticipate. Don't just accept it because it looks reasonable; understand it and decide.
- **A commit it made itself** — the brief forbids it, but nothing enforced that. Compare `HEAD` with
  the pre-dispatch baseline, then inspect status, staged and unstaged diffs, and the intervening log.
  Review the full baseline-to-HEAD range directly and preserve a recovery ref before any optional soft reset on an isolated unshared branch. Never uncommit unrelated/shared history.

## The implementer sweep

Generated code fails in systematic ways that gates are structurally blind to — each of these can sit in
a diff whose tests are all green. Walk them against every diff before you commit:

- **Hardcoded success or fixture data** on a path the brief says does real work — a canned
  `{status: "ok"}` or default return passes tests *by design*. If Command Code couldn't implement
  something, the diff should fail loudly, not pretend.
- **Catch-all error handling that returns a default** instead of propagating — the suppressed failure is
  exactly what the gate would have caught. A broad catch is only acceptable with a recovery path the
  contract documents.
- **Unverified imports and API calls** — confirm every new dependency, method, and signature exists in
  the *installed* version (read the lockfile or the package, don't trust plausibility).
- **Dead weight** — unused imports, helpers nothing calls, unreachable branches, "Step 1/Step 2"
  comment scaffolding, comments that restate the line below them.
- **A second way to do what the file already does** — a new HTTP client, error idiom, or logging style
  introduced beside the existing one instead of reusing it.
- **New tests that assert internals** — asserting that an internal helper was called, or mocking the
  project's own functions to isolate a "unit." Assess whether the mock tests a real external boundary or only mirrors internals; prefer observable behavior for regression coverage.
- **Near-duplicate test bodies** differing by one value — fold into one data-driven test or drop the
  copies; bloat reads as coverage but isn't.
- **Speculative surface** — optional parameters, config flags, or abstractions with no caller in this
  diff or the repo. Delegated work gets the concrete behavior the brief asked for, nothing extra.
- **Guards for impossible cases** — null/type checks for values the code's own contract already
  excludes. Noise that buries the validation that matters at real trust boundaries.

Anything the sweep catches goes back to Command Code as a delta brief (below) or gets fixed in the tree
before commit — and either way is reported to the user (see "Surface, don't absorb").

If the `guard-skills` package is installed, run the relevant guard on the diff for the full treatment —
`clean-code-guard` on production code, `test-guard` on tests, `docs-guard` on documentation. The sweep
above is the built-in floor; the guards go deeper.

## The commit boundary

When the gates pass and the diff holds, **you commit** — the orchestrator, never Command Code. This
isn't a workaround for a missing feature; it's the deliberate boundary. Under `--yolo` Command Code is
perfectly capable of committing, and that is precisely the problem: committing should be the act of the
party that verified the work, and a self-committed run has to be unpicked before it can be reviewed.
Write a clear message describing what landed. If your project attributes co-authorship, that's the place
for it.

From dispatch until that commit, the uncommitted working tree is the authoritative copy of the
implementer's work — the only one you can commit from, and often the only copy at all. Never run
`git checkout`, `reset`, `clean`, or a branch switch in the workspace between those two points —
however messy an interrupted run looks, inspect it first: `git status`, `git diff`, `git diff --cached`
for anything the implementer staged (plain `git diff` is blind to the index), and open any untracked
files (`??` in `git status`) directly — they are the implementer's new files, and no diff shows their
contents. The tree is evidence, not clutter. After that inspection the verdict can legitimately be to
discard — work built on a premise you have since corrected, for example — and then `git checkout`/`clean`
is the right tool. The ban is on reflexive cleanup before anyone has looked.

## Reworking: send the delta, not the whole task

If the review turns up problems, don't restate the entire brief. Continue the same Command Code session
with just the correction:

```bash
echo "The fix is right, but the test mocks the DB session - use the real migrated fixture instead, and
drop the now-unused import." | node "<skill-dir>/scripts/relay.mjs" --session <sessionId> --cd /path/to/repo
```

(`<skill-dir>` is this skill's install directory — see [dispatch-and-poll.md](dispatch-and-poll.md).
`<sessionId>` is the field of that name from the prior `result.json`.)

`--session <sessionId>` keeps the context from the first run, so a short delta is enough; use
`--continue-last` only when no session id came back, since "most recent" is global and another run can
steal it. Then review again — rework gets the same gate-rerun, test check, diff-read, and sweep as the
original, no shortcuts. Repeat until it's right, then commit.

## Surface, don't absorb

The human opted into delegation, so committing verified, gate-passing work is the agreed contract.
But keep them in the loop on anything that changes the shape of the work:

- **Report design decisions** Command Code made, and any defensible-but-unrequested turns it took.
- **Note non-blocking nitpicks** you chose not to block on, so the human can overrule you.
- **Report any write outside the brief's paths**, and any `readOnlyViolation: true` on a read-only
  dispatch, even when the change itself looks harmless. Those say something about the run's containment,
  which is the human's call to weigh, not yours to normalize.
- **Stop and ask** if correct completion requires going beyond the brief — don't expand the mandate on
  your own. A scope change is the human's call, not yours or Command Code's.

For a multi-task run, capture these in the progress file rather than letting them scroll past — see
[multi-task-queues.md](multi-task-queues.md).
