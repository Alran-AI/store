# Source

Unmodified copy of `workbuddy/connectors/everyinfra/skills/everyinfra-jd` from https://github.com/everyinfra/everyinfra-agent-plugins
at commit 6796f199fe4b6aac88e0dc1f1abe0b2dcf15fe2e (2026-11-18), under the Apache-2.0 licence.

Copyright 2026 EveryInfra

The licence text is in LICENSE.txt. Nothing in this folder was edited.
