# Source

Unmodified copy of `pm-go-to-market/skills/growth-loops` from https://github.com/phuryn/pm-skills
at commit 9af7bfd0bc47fdad43c2eaa7a43cd13918e7aaef (2026-11-08), under the MIT licence.

Copyright (c) 2026 Pawel Huryn

The licence text is in LICENSE.txt. Nothing in this folder was edited.
