---
name: disability-benefit-appeal
description: "Summarise what Disability Benefit Appeal does in one line. Use when asked to [trigger phrases the user would say]. Produces [the concrete artifact]."
---

# Disability Benefit Appeal Skill

One-line summary of the value this skill delivers. <!-- TODO: rewrite -->

## Working from a brief

Deliver the full artifact even from a thin brief — infer and label assumptions, never refuse for missing context. <!-- TODO: tailor -->

## Required Inputs

Ask for (if not already provided), else infer and label:
- <!-- TODO: the inputs to gather -->

## Output Format

<!-- TODO: a concrete template (headings/tables) of the final artifact -->

## Quality Checks

- [ ] <!-- TODO: a check the output must pass before hand-off -->

## Anti-Patterns

- [ ] Do not <!-- TODO: the mistake this skill prevents -->

## Example Trigger Phrases

- "My disability benefit was denied."
- "Appeal my PIP/SSDI decision."
- "How do I challenge a benefits decision?"

Run this skill in your browser: https://mohitagw15856.github.io/pm-claude-skills/skill/disability-benefit-appeal.html
