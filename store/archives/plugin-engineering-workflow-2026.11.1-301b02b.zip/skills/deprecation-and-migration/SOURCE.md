# Source

Unmodified copy of `skills/deprecation-and-migration` from https://github.com/addyosmani/agent-skills
at commit 301b02b12bff98e4688e6984af6556802322bbde (2026-11-01), under the MIT licence.

Copyright (c) 2025 Addy Osmani

The licence text is in LICENSE.txt. Nothing in this folder was edited.
