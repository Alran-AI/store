# Webhooks

Two separate features that share a settings page and nothing else.

| Direction | What it is | Configure at |
|---|---|---|
| **[Outbound](#outbound-webhooks)** | Courier `POST`s workspace events (message delivered, template published, audience changed) to *your* endpoint | Platform → Webhooks → Outbound Webhooks |
| **[Inbound](#inbound-webhooks)** | *Your* systems `POST` JSON to a Courier-generated URL; the events can start journeys | Platform → Webhooks → Inbound Webhooks |

Both live under [Platform → Webhooks](https://app.courier.com/settings/webhooks).

Neither is a send path. To *send* a notification over an HTTP callback, that's the webhook
*channel* on a template, which is a different thing again.

<a id="outbound-webhooks"></a>

**Contents:** [Quick Reference](#quick-reference) · [Outbound Webhooks](#outbound-webhooks) · [Inbound Webhooks](#inbound-webhooks) · [Related](#related)

## Quick Reference

### Rules
- Webhooks are scoped to the environment they're created in. A test webhook never fires for production events.
- Respond 2xx within 10 seconds and do the work async.
- Events can arrive more than once. Deduplicate on `data.id` plus `data.status` (or the event type), never on `data.id` alone.
- Verify signatures against the raw request bytes, not a re-serialized object.
- Inbound events need a `userId` that matches an existing Courier user, or nothing starts.

## Outbound Webhooks

### Setup

1. Platform → Webhooks → **Outbound Webhooks** → **Add**.
2. Name it and give it a URL that accepts `POST`.
3. Copy the `whsec_...` signing secret Courier creates for the destination. Every event is signed with it.

> **Webhooks are scoped to the environment they're created in.** A webhook created in test only
> fires for test events, and never for production ones. If you need both, create a destination in
> each environment. This is the most common "my webhook never fires" cause.

### Event Types

Every payload is `{ "type": "...", "data": { ... } }`. Branch on `type`, and ignore unknown
values, since more types get added over time.

| Event type | Fired when |
|---|---|
| `message:updated` | A message changes status |
| `notification:submitted` | A template is submitted for review |
| `notification:submission_canceled` | A pending submission is canceled before publishing |
| `notification:published` | A template is published (directly, or when a submission is approved) |
| `audiences:created` | An audience is created |
| `audiences:updated` | An audience's definition changes |
| `audiences:deleted` | An audience is deleted |
| `audiences:user:matched` | A user starts matching an audience filter |
| `audiences:user:unmatched` | A user stops matching an audience filter |
| `audiences:calculated` | Courier finishes recalculating an audience |
| `preferences:user:updated` | A user opts in, opts out, or changes a topic's channels, from any surface ([payload](#preference-events)) |

There is no `message:bounced` or `message:complained`. Hard bounces and spam complaints arrive as
`message:updated` with `data.status` of `UNDELIVERABLE`, the aggregate cause in `data.reason`, and
the provider's own message in `data.providers[].error`. Drive list hygiene off those fields.

The three `notification:*` events are the hook for TMS integrations and custom approval workflows.
`notification:published` is the one to listen for if you sync template content to an external system.

`audiences:user:matched` is the same event behind the journey Audience trigger. React to it with a
webhook, or start a journey, whichever fits.

### Responding

Courier gives your endpoint **10 seconds**. Acknowledge first, then do the real work in a queue or
background job. A slow dependency on your side turns into a delivery failure on Courier's.

Retries, when the failure looks temporary:

| Outcome | Retried |
|---|---|
| Network error, or no response inside 10 seconds | Yes |
| `408`, `429`, or any `5xx` | Yes |
| Any other `4xx` | No |

Retries continue for roughly a day, then Courier gives up.

**Events can arrive more than once, so handlers must be idempotent.** `data.id` is the *resource*, so one message's events share it: dedupe on `data.id` plus status, as in the Rules. `preferences:user:updated` is simpler: its `data.id` is unique per change.

### message:updated Payloads

Timestamp fields accumulate as the message progresses, so a `CLICKED` event still carries
`enqueued`, `sent`, `delivered`, and `opened`.

| Status | What it adds to `data` |
|---|---|
| `ENQUEUED` | `enqueued` |
| `SENT` | `sent`, plus `sent` on the matching entry in `providers` |
| `DELIVERED` | `delivered`, plus `delivered` on the matching entry in `providers` |
| `OPENED` | `opened` |
| `CLICKED` | `clicked` |
| `UNROUTABLE` | `reason` (e.g. `NO_PROVIDERS`) and `error`. `providers` is empty. |
| `UNDELIVERABLE` | `reason` (e.g. `UNSUBSCRIBED`) and `error`, plus `error` on the failing provider entry |

`data` matches what [`GET /messages/{id}`](https://www.courier.com/docs/api-reference/messages/get-message)
returns, and carries any metadata on the message: `trace_id`, `tags`, `event`, and `utm`.

```json
{
  "type": "message:updated",
  "data": {
    "id": "1-612fa552-15f7d6ba51bf229857c037a7",
    "status": "DELIVERED",
    "enqueued": 1630512466717,
    "sent": 1630512468691,
    "delivered": 1630512501708,
    "event": "SFTYJKSF0241SVH2TWY97TTFFTQG",
    "notification": "SFTYJKSF0241SVH2TWY97TTFFTQG",
    "recipient": "b19fb0e0-8cd6-4337-b41c-92c780c80d1a",
    "providers": [
      {
        "provider": "slack",
        "status": "DELIVERED",
        "channel": { "key": "direct_message:slack", "name": "Slack" },
        "sent": 1630512468691,
        "delivered": 1630512501708
      }
    ]
  }
}
```

Delivery statuses like `DELIVERED` depend on the provider confirming asynchronously, while
engagement statuses (`OPENED`, `CLICKED`) are tracked by Courier directly. **Engagement events can
arrive before delivery confirmation, or without it ever arriving.** Don't write a state machine that
assumes `DELIVERED` precedes `OPENED`.

For the full status list and what each one means, see [reliability.md](./reliability.md#message-status-glossary).

<a id="preference-events"></a>

### preferences:user:updated Payloads

One event type covers opting in, opting out, and editing a topic's channels, from any surface.
`data` is one change to one topic:

```json
{
  "type": "preferences:user:updated",
  "data": {
    "id": "eb4023e3-62cc-4488-a4fc-d98230994f6a",
    "timestamp": "2026-09-24T18:12:04.442Z",
    "user_id": "user_123",
    "tenant_id": "acme-corp",
    "topic_id": "pt_01kx4h2jdafq8bk996nn92357r",
    "topic_name": "Product updates",
    "status": "OPTED_OUT",
    "custom_routing": [],
    "has_custom_routing": false,
    "previous": {
      "status": "OPTED_IN",
      "custom_routing": ["email"],
      "has_custom_routing": true
    }
  }
}
```

- `data` is the same entry `GET /preferences/logs` returns, with the same `id`.
- `previous` holds the value the change replaced, and is left out when that isn't known (a user's first change to a topic).
- `tenant_id` is left out for changes made outside a tenant. `custom_routing` is empty unless `has_custom_routing` is `true`.

Resetting a topic to its default sends no event. For how resets work and how to keep a copy of
preferences in your own system, see [preferences.md](./preferences.md#mirroring-preferences-in-another-system).

<a id="verify-webhook-signatures"></a>

### Verifying Signatures

Courier signs every event with HMAC-SHA256, keyed with the destination's `whsec_...` secret, in a
`courier-signature` header:

```
t=1631816343012,signature=33777cdae0468ff0939b3609d02d14e6e80ca093c2ea233455f0767055218875
```

`t` is when Courier signed the event, in **milliseconds** since the epoch. `signature` is a
hex-encoded HMAC-SHA256 over `${t}.${raw_body}`, keyed with the webhook secret.

Four steps: split the header on `,` then each part on `=`; build `signed_payload` as
`timestamp + "." + raw body`; compute the HMAC; compare in constant time. Also reject events whose
timestamp falls outside a tolerance window you pick, which bounds how long a captured request stays
replayable.

> **Verify against the raw bytes, not a re-serialized object.** `JSON.stringify` on a parsed body
> can reorder keys or change whitespace, producing a hash that never matches. Configure the
> framework to keep the raw body: `express.raw()`, or Next.js with the body parser disabled.

**TypeScript (Express):**

```typescript
import crypto from "crypto";
import express from "express";

function parseCourierSignature(header: string | undefined) {
  if (!header) return null;
  const parts = header.split(",").reduce<Record<string, string>>((acc, part) => {
    const [k, v] = part.split("=");
    if (k && v) acc[k.trim()] = v.trim();
    return acc;
  }, {});
  if (!parts.t || !parts.signature) return null;
  return { timestamp: parts.t, signature: parts.signature };
}

function verifyWebhookSignature(
  rawBody: Buffer,
  header: string | undefined,
  secret: string,
  toleranceMs = 5 * 60 * 1000
): boolean {
  const parsed = parseCourierSignature(header);
  if (!parsed) return false;

  const ts = Number(parsed.timestamp);
  if (!Number.isFinite(ts) || Math.abs(Date.now() - ts) > toleranceMs) {
    return false;
  }

  const expectedHex = crypto
    .createHmac("sha256", secret)
    .update(`${parsed.timestamp}.${rawBody.toString("utf8")}`, "utf8")
    .digest("hex");

  const a = Buffer.from(parsed.signature, "hex");
  const b = Buffer.from(expectedHex, "hex");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

app.post(
  "/webhooks/courier",
  express.raw({ type: "application/json" }),
  (req, res) => {
    const signature = req.headers["courier-signature"] as string | undefined;
    if (
      !verifyWebhookSignature(
        req.body,
        signature,
        process.env.COURIER_WEBHOOK_SECRET!
      )
    ) {
      return res.sendStatus(401);
    }

    const payload = JSON.parse(req.body.toString("utf8"));
    res.sendStatus(200);              // ack inside 10s
    queue.add("process-webhook", payload);
  }
);
```

**Python (Flask):** the same steps with `hmac.new(secret.encode(), f"{t}.{raw_body.decode()}".encode(), hashlib.sha256).hexdigest()` and `hmac.compare_digest`, where `raw_body = request.get_data()` is read before Flask parses the JSON.

<a id="inbound-webhooks"></a>

## Inbound Webhooks

The other direction: Courier hands you a URL, third-party systems `POST` JSON to it, and the events
that arrive can start journeys. Use one when a system can fire an HTTP request but can't call the
Courier API.

### Setup

1. Platform → Webhooks → **Inbound Webhooks** → **Add**.
2. Give it a name and description, and save.
3. Courier generates the URL: `https://api.courier.com/inbound/webhook/<token>`.

**The name is permanent.** You select the webhook by name wherever you consume its events, and its
events are tied to that name, so pick something recognizable.

```bash
curl -X POST https://api.courier.com/inbound/webhook/YOUR_WEBHOOK_TOKEN \
  -H "Content-Type: application/json" \
  -d '{
    "event": "order-shipped",
    "userId": "user_123",
    "properties": { "order_id": "ORD-9042", "carrier": "UPS" }
  }'
```

No API key and no auth header. The token in the URL identifies the workspace, **so treat the URL as
a secret**. Anyone holding it can push events into the workspace. If it leaks, delete the webhook
and create a new one to get a fresh URL.

### Payload Rules

Courier accepts any payload up to **6 MB** and answers `202` once accepted. A `404` means the URL is
wrong or the webhook was deleted.

| Payload | What Courier does |
|---|---|
| JSON object | Parses it and exposes the fields as data |
| JSON array | Unpacks it, and each object becomes its own event |
| Anything else | Keeps the payload as a string on a `raw` field and names the event `custom` |

Two reserved fields:

| Field | Purpose |
|---|---|
| `event` | Event name. It picks which events start a journey. Must be a string. Absent → the event is named `custom`. |
| `userId` | Identifies the recipient. Courier resolves the user and loads their profile. String or number, coerced to string. |

Every other field passes through as data.

> **`userId` must match an existing Courier user.** Without a resolvable recipient there is nothing
> to send to, so the event will not start a journey. This is the most common reason an inbound
> event lands but nothing happens.

### Using the Events

Point a journey's **Webhook trigger** at the webhook by name, then optionally narrow to a single
`event` name. Leave it empty to start on any event from that source. Payload fields become
`data.<field>` on the run.

> **Send real traffic before you build.** Courier learns event names and payload shape from events
> it has actually received, so until one arrives the event picker and variable hints are empty.

**You can also build the Webhook trigger over the API.** Use a trigger node with `"trigger_type": "webhook"` and `event_source`, plus an optional `event_id` to match one `event` name. See [journeys.md](./journeys.md#triggers).

## Related

- [reliability.md](./reliability.md): delivery statuses, idempotency, retries
- [patterns.md](./patterns.md#webhook-handler): handler checklist
- [journeys.md](./journeys.md): trigger types and journey structure
- [Outbound Webhooks](https://www.courier.com/docs/monitor/webhooks/outbound) · [Inbound Webhooks](https://www.courier.com/docs/monitor/webhooks/inbound)
