# Template Metrics

`GET /notifications/{id}/metrics` returns one template's delivery funnel as a time series: sent, delivered, opened, clicked, errors, and undeliverable, broken out per provider and channel inside every bucket. Use it to build a dashboard, alert when a delivery rate drops, push the numbers into a warehouse, or answer "how is this template doing?" without opening the Courier app.

These are aggregates for one template. For one message's timeline, use [cli.md](./cli.md) and Message Logs instead.

**Contents:** [Quick Reference](#quick-reference) · [Pick a window and granularity](#pick-a-window-and-granularity) · [Read the response](#read-the-response) · [Fetch and roll up](#fetch-and-roll-up) · [Break out by channel](#break-out-by-channel) · [Plan limits and rate limits](#plan-limits-and-rate-limits) · [Errors](#errors) · [Observability exports](#observability-exports) · [Related](#related)

## Quick Reference

### Rules

- **Set the window with `lookback`, or with `start`+`end`.** `lookback` is an ISO 8601 duration counted back from now (`P30D`, `P12W`, `PT12H`), default `P30D`. `start`+`end` are ISO 8601 timestamps with an offset and must be supplied together. Send one form, never both: `lookback` with `start`/`end` returns `400`.
- **Label charts with the response's `start` and `end`, not the values you requested.** Courier widens the window outward to whole buckets, so a request for the last 36 hours at `DAY` returns two or three whole UTC days, depending on the time of day.
- **Go coarser, don't split the range.** A granularity too fine for the window returns `400`. Switch `HOUR` to `DAY` rather than issuing several calls.
- **There is no bucket-level total.** Sum the rows in a bucket yourself, and guard the division: a quiet bucket has `sent: 0`.
- **A window past your plan's cap returns `402`, not a truncated series.** Check the cap before widening.
- **Per-template only.** Workspace-wide means `client.notifications.list()` then one call per template, paced against the plan's requests-per-second.
- **US region only.**

### Common Mistakes

- Treating an all-empty series as proof a template sent nothing. **An unknown template ID returns `200` with an empty series, not `404`.** Confirm the ID first.
- Expecting sends made without a template to show up. They never appear here.
- Reading `opened` on a channel with no open tracking. It is always `0` there, which is not the same as "nobody opened it."
- Reading a low `delivered` count as failed mail. `delivered` needs the provider to report back, through polling or a webhook set up on the provider's integration page. With tracking off, messages stay at `sent`. Check tracking before assuming an outage. See [Analytics: set up delivery tracking](https://www.courier.com/docs/monitor/analytics#set-up-delivery-tracking).

### SDK shape

| | Node | Python |
|---|---|---|
| Fetch metrics | `client.notifications.getMetrics(templateId, { lookback, granularity })` | `client.notifications.get_metrics(template_id, lookback=..., granularity=...)` |

CLI: `courier notifications get-metrics --id <template-id> --lookback P7D --granularity DAY`. See [cli.md](./cli.md#template-metrics).

MCP: `get_notification_metrics`, with the same window rules.

## Pick a window and granularity

`granularity` sets the bucket size: `HOUR`, `DAY` (the default), `WEEK`, or `MONTH`. `WEEK` buckets start on Sunday. All boundaries are UTC, with no timezone support, so a "day" is a UTC day.

A finer granularity caps the window it can cover:

| Granularity | Maximum window |
|---|---|
| `HOUR` | 7 days |
| `DAY` | 90 days |
| `WEEK` | Uncapped |
| `MONTH` | Uncapped |

`WEEK` and `MONTH` have no window cap, but **every response is limited to 1000 buckets**, and a request that would exceed that returns `400` too.

Either one of `start`/`end` alone returns `400`, as does a `start` that is not earlier than `end`. An `end` in the future is accepted and not clamped, so the trailing buckets come back empty.

## Read the response

```json
{
  "notificationId": "nt_01kx4h2jdafq8bk9aftxak4b40",
  "granularity": "DAY",
  "start": "2026-08-17T00:00:00Z",
  "end": "2026-08-20T00:00:00Z",
  "series": [
    { "period": "2026-08-17T00:00:00Z", "data": [] },
    {
      "period": "2026-08-18T00:00:00Z",
      "data": [
        { "provider": "sendgrid", "channel": "email", "sent": 412, "delivered": 408, "opened": 173, "clicked": 41, "errors": 0, "undeliverable": 4 },
        { "provider": "twilio", "channel": "sms", "sent": 96, "delivered": 95, "opened": 0, "clicked": 12, "errors": 1, "undeliverable": 0 }
      ]
    },
    {
      "period": "2026-08-19T00:00:00Z",
      "data": [
        { "provider": "sendgrid", "channel": "email", "sent": 380, "delivered": 377, "opened": 151, "clicked": 33, "errors": 2, "undeliverable": 1 }
      ]
    }
  ]
}
```

`end` is exclusive: the `08-20` bucket is not in this series.

`series` holds one entry per bucket between the snapped `start` and `end`, oldest first. Each entry has a `period` (the start of the bucket, UTC) and a `data` array with one row per provider and channel that handled a message in that bucket. Quiet buckets are still returned with `data: []`, so a series plots as-is with no gap filling on your side.

What each count means:

| Field | Means |
|---|---|
| `sent` | Messages handed to the provider |
| `delivered` | Provider confirmed delivery. Depends on the provider reporting it back |
| `opened` | Messages opened at least once. Always `0` on channels with no open tracking |
| `clicked` | Messages with at least one tracked link click |
| `errors` | Messages the provider rejected or failed on, **including ones a later provider then delivered** |
| `undeliverable` | Messages Courier could not deliver on any provider for the channel |

`errors > 0` with `undeliverable: 0` means a fallback provider covered the failure. Not an outage.

## Fetch and roll up

```typescript
const metrics = await client.notifications.getMetrics(templateId, {
  lookback: "P7D",
  granularity: "DAY",
});

for (const bucket of metrics.series) {
  const sent = bucket.data.reduce((n, r) => n + r.sent, 0);
  const delivered = bucket.data.reduce((n, r) => n + r.delivered, 0);

  // Guard the division: a quiet bucket has sent === 0
  console.log(bucket.period, sent ? delivered / sent : null);
}
```

Chart the range as `metrics.start` to `metrics.end`, the snapped values.

## Break out by channel

Every row carries `provider` and `channel`, so comparing channels for one template needs no extra calls. Sum rows by `row.channel` across the series, and compare channels without open tracking on `clicked` (with link tracking on), not `opened`. Worked example in [multi-channel.md](./multi-channel.md#track-routing-effectiveness).

## Plan limits and rate limits

| Plan | Max lookback | Requests per second |
|---|---|---|
| Developer (free) | 30 days | 1 |
| Business | 90 days | 2 |
| Enterprise | No limit | 5 |

Rate limits are per workspace, and every response carries `RateLimit-*` headers, so a backfill can pace itself instead of guessing.

Walking every template in a workspace means one call per template against that limit. Read the headers and back off rather than firing the whole list concurrently:

`notifications.list()` is paginated (`paging.more` plus an opaque `paging.cursor`), so a sweep has to page or it silently covers only the first page:

```typescript
let cursor: string | undefined;

do {
  const page = await client.notifications.list(cursor ? { cursor } : undefined);

  for (const template of page.results) {
    const metrics = await client.notifications.getMetrics(template.id, {
      lookback: "P30D",
      granularity: "DAY",
    });
    // handle metrics, then pace the next call on the plan's requests-per-second
  }

  cursor = page.paging.more ? page.paging.cursor ?? undefined : undefined;
} while (cursor);
```

See [templates.md](./templates.md#list-templates) for the list call itself.

## Errors

| Status | `type` | When |
|---|---|---|
| 400 | `invalid_params` | Malformed duration or timestamp, `lookback` combined with `start`/`end`, one of `start`/`end` without the other, `start` not earlier than `end`, a granularity too fine for the window, or more than 1000 buckets |
| 402 | `payment_required` | The window reaches further back than the plan's cap. Not a truncated series |
| 429 | `rate_limit_exceeded` | Too many requests per second. Wait the seconds in `Retry-After` |
| 503 | `service_unavailable` | Temporary. Retry after the seconds in `Retry-After` |

## Observability exports

Courier also exports metrics and logs to Datadog, New Relic and any OpenTelemetry endpoint (Enterprise plan), set up in the console: [Observability](https://www.courier.com/docs/monitor/observability). Use [outbound webhooks](./webhooks.md) instead when your own code must act on each event.

## Related

- [templates.md](./templates.md) - the rest of the `/notifications` API: CRUD, publishing, versions
- [cli.md](./cli.md) - per-message triage when one send failed, rather than aggregates
- [reliability.md](./reliability.md) - delivery statuses and webhooks for real-time per-message events
- [multi-channel.md](./multi-channel.md) - acting on what the per-channel numbers tell you
- [Analytics](https://www.courier.com/docs/monitor/analytics) - the same metrics in the Courier app
- [Template Metrics API docs](https://www.courier.com/docs/monitor/template-metrics)
