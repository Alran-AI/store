---
name: plan-campaign
description: >-
  Campaign planner: turns a product, offer, goal, budget and date into a plan the marketer can approve
  and a designer can start from today, with every channel kept or dropped for a reason. Zero paid is a
  valid answer; it never spends. Use when the ask names a campaign, a launch, drop or season push, a
  budget or a date: I have this budget and a launch date — what do I run, where?; plan my launch, drop
  or Black Friday push; plan a campaign; how should I split $5k; plan next month's campaign; our CAC
  blew up — replan. Not for a broad "grow my brand", "get more customers" or "where do I start" with
  no campaign, budget or date — use where-to-start; not for pausing ads on a sold-out product — use
  run-paid-campaigns; not for an email-only send plan — use email-lifecycle; not for reading this
  week's numbers — use analyze-performance.
version: 0.1.4
---

# plan-campaign

## What you get

A **campaign plan** the marketer reads in 30 seconds and a designer can start from today, written and delivered through the `write-report` skill (`../write-report/SKILL.md`): a clickable file, a copy saved to the brand, and the same text on the GooseWorks campaign record (local mode: a copy in this folder, no campaign record). It opens with **In short** (what the plan rests on; the goal and whether the money gets there; which channels the plan covers and why; where we run and where we don't; the split; the first test; then "do this first, because of …" — what's needed this week), then Decisions for you, the story, What to do (at most six moves) and What we're not doing — with the long working tables in an appendix (`references/brief-template.md`): who it's for and what we say, the money math and forecast, channel decisions, budget split, paid structure, tests, angles per channel, offer, backwards calendar, asset list, how we'll measure it, hand-offs, replan triggers, what we couldn't check.

## Before you start

1. **Setup first:** do the `marketing-guide` skill (`../marketing-guide/SKILL.md`) §1–2 (connect, brand, brain read) before anything else; the job line is "plan your campaign". This playbook offers **local mode** (marketing-guide §5): plan from the live site, the marketer's answers and their connectors (read-only), and save the plan in the local `plans/<slug>/` in place of the campaign record; it skips every `gooseworks:` call from the look-first pass (`references/intake.md` § 1, local mode) through write-back (`references/brief-template.md` § Write-back, local mode). With GooseWorks, load the campaigns, meta, social and files groups in one `gooseworks:tools_load`.
2. **Look first — ask nothing yet.** Do `references/intake.md` §1 in full before the first message: the brain chapters a plan needs, what's connected, what's already planned or measured, the research, the last plan and how its bets did (run-memory's Start steps, job `campaign plan`, subject the campaign slug — `references/run-memory.md`), the claims contract and the live site (required every run).
3. **Then one short message, like a person would ask** — `references/intake.md` §2 is the single source for its shape and wording: what you found in two or three lines, then at most four plain questions, product and offer first. Only the product, audience, goal, budget and date block planning; everything else becomes a labelled assumption (`references/intake.md` §3).
4. **A goal that isn't a number** ("make it big", "as many installs as possible"): offer 2–3 concrete options built from the brand's own numbers and the budget (metric + target + date), steering vanity metrics to the one the business needs. The marketer picks; you never set it.
5. **Research missing?** If the customer-words bank or the angle bank is missing, say so in one line and offer to do that research first; if the marketer wants to go ahead, angles are labelled "starting point". Public benchmarks for the money math may be looked up with web search and are labelled as such.

## Steps

1. **Frame the job.** If a matching plan already exists (same product or occasion, overlapping dates), say so in one line and treat this run as a **refresh**: re-check every number in it against today's look-first facts (the live prices first) and how its bets did (`references/run-memory.md`), re-run the money math, the channel check, the frequency check and the tests, and write a fresh plan in the current shape with a short "What changed since the last plan" line in In short. Never paste a stored plan as the report. **"Start from scratch"** (or "ignore earlier work") makes this a first run: don't read or carry earlier plans, notes or run records, and say so in one line ("Starting fresh: I won't use earlier plans or notes."); the brand's rules and approved claims still apply. A new number that contradicts what the marketer said earlier in this conversation is flagged before planning on it ("100 sign-ups a day" is ~3,000 a month, against "over 1,000 free users" in total). Mode — *launch*, *goal push to a date*, *always-on month*, *monthly replan*, *trigger replan* (replans: `references/replan.md`; a "CAC blew up" replan with no performance read from the last ~7 days recommends reading the numbers first). Launch tier T1/T2/T3 with the reason (`references/launch-and-calendar.md`; "n/a" outside launches). Note promo dates and other live campaigns, and the **buyer's** busy season in the window, not only the seller's dates (`references/launch-and-calendar.md` § The buyer's calendar). Read `references/company-types.md` for the brand's type. Name the business result the plan is judged on (signups or paid accounts for SaaS, orders for DTC, bookings for local) — every leg says how it moves that number.
2. **Money math and the top-down check** — atom the `plan-campaign-goal-chain` skill (`../plan-campaign-goal-chain/SKILL.md`) part 1, `references/unit-economics.md`. What a customer may cost, with a source on every number; subtract the baseline; budget ÷ incremental goal against history or labelled base rates. If it already needs a miracle, say so in one line and continue — the full case comes at step 5.
3. **The live picture.** Competitors' current campaigns from the stored research (don't re-scrape), seasonal moments, stock on anything featured; in replan mode the scored bets from the run records (analyze-performance's scorecards, run-paid-campaigns' money moves and verdicts) and the paid change log (`ads/campaigns/<slug>/decisions.md`, its `### YYYY-MM-DD — …` blocks). A leg or angle that didn't work is not funded again without a new reason, named.
4. **Channel decision** — atom the `plan-campaign-channel-decision` skill (`../plan-campaign-channel-decision/SKILL.md`), `references/channel-decision.md`. Every channel that could work, ads and non-ads alike, kept or dropped with the deciding reason and a brand fact; channels that clearly don't apply fold into one "Not relevant:" line with reasons. No channel is assumed — Meta included. For each channel check that the people it reaches are the **buyer** (not peers, builders or rivals); if the marketer chose a channel that reaches someone else, say so once, plainly, and then follow their choice. Zero paid is valid.
5. **Budget, tests, forecast** — atoms the `plan-campaign-budget-and-tests` skill (`../plan-campaign-budget-and-tests/SKILL.md`) then the `plan-campaign-goal-chain` skill (`../plan-campaign-goal-chain/SKILL.md`) part 2, `references/budget-and-tests.md`. All budget lines; any retargeting or known-list leg states its audience size and weekly frequency and is capped near ~5 a week (§2b); tests with one variable, money per cell, when it can be read, an end date and what each result means; per-leg targets, three scenarios, and — if the expected one misses — the case for changing the goal, with the marketer choosing the lever.
6. **Calendar backwards from the date** — `references/launch-and-calendar.md`, incl. "claims signed off" by T-30 when the hero product has none.
7. **Write the plan** — atom the `plan-campaign-brief-and-assets` skill (`../plan-campaign-brief-and-assets/SKILL.md`), `references/brief-template.md`, following the `write-report` skill (`../write-report/SKILL.md`) §1: In short first, plain words, no ids, every fact with its source and date. Angles from the angle bank and customers' words; signed-off claims only, verbatim; ad-policy risk per angle; the asset list complete enough for a designer.
8. **Attack it before showing it.** The parts a generic plan gets wrong must be present and right: the economics from **today's** prices (allowable cost vs the budget's implied cost); each channel checked against the actual buyer; any retargeting or known-list leg with its audience size, weekly frequency and cap; every test changing **one** thing, with money per version, a read date and an action for win, lose **and** unclear (two things changing → two tests, or say what it can't tell you); the buyer's busy moment on the calendar. Numbers reconcile (leg target = leg spend ÷ expected cost; lines sum to the budget); every channel kept or dropped has its reason; no unsigned claim; no angle addressing the viewer's personal attributes or making a regulated claim; every asset has a producer and a due date inside its lead time; then every check in write-report §3.
9. **Deliver for approval** — write-report §2 (topic `campaign-plan`). The brand copy goes through the `save-to-brain` skill (`../save-to-brain/SKILL.md`) as `plans/<slug>/<YYYY-MM-DD>-plan-v<N>.md` ("Campaign plan — <Brand> — <date> v<N>", `versioned: supersede`; local mode: its local branch). With GooseWorks, on a new campaign, or one whose brief is an unapproved draft, with no creative plans pending, the same text also goes on the campaign record as `status: "draft"`; an **approved** live brief is never overwritten before the yes. In chat, **only** this (no tables, no re-pasted sections):

   > Do this first (because <the findings it rests on, in a few words>): <the one move, who, by when>.
   > The plan: [<title>](<local link>) — <also saved to your brand | saved in this folder (local mode)>.
   > Decisions I need: <the 2–4 decisions in one line>. Approve the goal, channels, split, asset list and headline?

   In a hosted chat with no files, put the full plan in the chat (write-report §2.2) and end with the same three lines, the second one only saying where it is saved ("saved to your brand", or, without GooseWorks, "not saved anywhere — keep a copy").

## Approval gates

- This playbook **never spends**, never launches and never makes ads. Every output is a proposal.
- The marketer approves the goal and forecast, the **channel decisions**, the **budget split**, the asset list, the tier and the headline message; in a replan, every reallocation with its reason.
- An unrealistic goal goes back to the marketer as the case for changing it; the lever is their choice.

## Output and write-back

After the yes (`references/brief-template.md` § Write-back; local mode: its local branch, which versions the approved plan and the run record and skips the campaign record, concepts and link):
- **Campaign record** — `gooseworks:campaign_upsert`: the approved plan as `brief_md` (status line "Approved <date> by <name>", version bumped), `status: "planned"` only if it was a draft, `goal`, `budget_cents` (the total), dates, `hero_product_ids`, `channels` (paid social only when a paid-social leg runs), `intake` in the marketer's own words. Re-save the readable file and the brand copy with the approved status.
- **Concepts** for each paid static or video angle — `gooseworks:add_campaign_concept` / `gooseworks:update_campaign_concept` (pending plans checked first): person, message, and proof **only** when the claim is signed off and accepted by the server for that product; otherwise proof stays empty and the gap is named. A zero-paid plan has none.
- **Making the ads is not this playbook.** If the marketer asks to make or price the ads, stop here: say in plain words that making the ads is the next step and it starts with a claims check, and offer it. Never request generation or approve a credit quote, and never fill a concept's proof with unsigned text to get one.
- **Hand-offs** in the plan by role (static ads, video ads, photos, content, paid, email, organic social, creators, claims, human), and in the closing message as plain offers of the next job (video ads with the goose-video skill and product photos with goose-product-photos, from the asset rows; without GooseWorks, the rows go to whoever makes them; real creators filming stay with the creators role).
- **The run record** — the End steps of the `run-memory` skill (`../run-memory/SKILL.md`) (`references/run-memory.md`): the plan's numbers and every bet (each leg and test with owner, read date and how we'll know), saved at delivery and re-saved on approval. On the marketer's approval only, the plan's target, tests and approved reallocations are also proposed to the Brand Brain's chapter 20 for their yes in the app (`references/run-memory.md` § Reaching the brain).
- **Repeat it? Judge first.** At the end of the run, decide whether a repeat would help this brand. A standing or always-on plan with live channels and weekly performance reads → offer a **monthly replan** (reason: the split and tests should follow what the reads show; cadence: first week of each month). A one-off push that ends on a date (a launch, a Thanksgiving window) → no schedule; at most suggest one replan at its mid-point checkpoint. Offer only with the reason and the cadence; on a yes create it by marketing-guide §3 Schedules (local mode: the host's scheduler, or say it isn't available). With GooseWorks: `gooseworks:automation_upsert` per the `spend-gate` skill (`../spend-gate/SKILL.md`)'s automation rule (created paused; each run uses credits); the method goes in `plans/method/`, the prompt is `references/run-memory.md` § Setting up the schedule (a draft for approval only; never overwrite the live brief, move money, publish or spend). Each scheduled replan is delivered through the `write-report` skill (`../write-report/SKILL.md`), opening with what changed since the last plan.

## Done when

- The marketer was asked only what the look-first pass couldn't find, in one short message that started with the product and offer.
- The plan passes write-report §3 and says which channels it covers and why, where we run and where we don't, platform by platform.
- A designer could start from the asset list today; every budget line traces to a goal-chain leg and the lines sum to the budget; every number says where it came from.
- No number the marketer withheld was invented; no unsigned claim appears; an unrealistic goal produced the case for changing it.
- The plan opens with one click, is saved to the brand, and — after the yes — the campaign record holds the approved plan. Local mode: saved in this folder, and after the yes the approved version is the newest `plans/<slug>/` file.

## Out of scope

- Making or pricing any asset — make-static-ads, make-content (offered as the next job). Video ads go to the goose-video skill and product photos to the goose-product-photos skill (GooseWorks skills, not playbooks), offered as the next job the same way; their rows in the asset list are ready to hand over.
- Launching, pausing or moving money — run-paid-campaigns.
- Doing the research — research-market, research-competitors (offered when missing).
- Approving claims — the claims gate's scoped sign-off, inside the job that needs the lines; a full claims audit is not covered yet.
- Measuring results — analyze-performance (this plan writes what it will be judged on).
- Offer mechanics — interim: the plan's offer line plus email-lifecycle's send calendar.
