---
name: story-planning
description: |
  Planning work before prose: creative direction, brainstorming, outlining, and story architecture. Load when deciding what should happen or how a story should be structured.
metadata:
  type: mode-shift
---

# Story Planning

Use this for pre-page decisions: what the story wants, what options exist, and how chosen direction becomes outline structure. Do not use it for production prose or critique.

Load only the resource needed:

- `resources/creative-direction.md` — author-facing direction and option synthesis.
- `resources/brainstorming.md` — exploratory capture, source tagging, and the brainstorm report.
- `resources/story-architecture.md` — arc, chapter, scene, and beat structure.
- `resources/story-architecture/chapter-and-scene.md` — writing an outline: what each beat carries.
