# Brainstorming Capture

Capture story brainstorming as minimal working notes that preserve creative freedom. The core principle: record what was stated, mark what was suggested, and don't fill gaps the author left open.

## Brainstorm Report

When producing a standalone brainstorm document, tag all generated content
as `<AI>` since none came from the author:

```markdown
# [Topic]: [Angle]

## The Need
<AI>The creative need you read behind the question, in a sentence or two.</AI>

## Approach
<AI>What direction you explored and why.</AI>

## Ideas
<AI>Concrete possibilities, organized logically.</AI>

## Tradeoffs
<AI>What each option gains and gives up.</AI>

## Connections
<AI>How this connects to existing story threads.</AI>

## Open Questions
<AI>Questions the author should consider before committing.</AI>
```

Open with the need: the first phrasing of a brainstorm question is often a
surface framing of a deeper creative need (`/creative-writing-skills:intent-modeling`), and stating
your read lets the author correct it before weighing options.

Present options and tradeoffs, not a recommendation: convergence is the
author's. Make each option concrete enough to evaluate and distinct enough to
be a different choice. A good open question reframes the decision space.

Save the document in the work directory's `brainstorm/` folder as
`brainstorm-[topic].md`.

## Capturing the Author's Ideas

When recording a brainstorm the author leads, capture it as follows.

### Source Tagging

**Default: untagged text = the author said it.** Most brainstorm content comes from the author, so untagged is the common case.

Three tags for special context:

**`<AI>...</AI>`**: AI suggestions and possibilities. Use when offering ideas the author didn't state. Keep brief: 2-3 options, not exhaustive lists.

**`<hidden>...</hidden>`**: Author-only information for planned reveals. Secret motivations, future twists, behind-the-scenes reasoning that readers and characters don't know yet.

**`<rejected>...</rejected>`**: Ideas explicitly considered and discarded. Recording why something was rejected prevents re-suggesting it and preserves the reasoning for later reconsideration.

### Minimal Capture

Record what the author stated. Don't elaborate, don't fill gaps, don't invent details they didn't mention.

AI suggestions are valuable: wrap them in `<AI>` tags and keep them brief.

- "Character A competes with B" → capture as stated. Optionally: `<AI>Tournament? Political? Trial?</AI>`
- "Maybe creates tension" → record as uncertain. Don't resolve the maybe.
- "Three kingdoms" → note three kingdoms. Don't name them.

### Preserve Vagueness

If the author left it vague, the notes stay vague. "Might," "maybe," "thinking about," "something like": all preserved as-is. Vagueness isn't a problem to solve; it's creative space the author is keeping open.

Multiple contradictory options coexist until the author chooses. Don't resolve them. Don't pick the "best" one.

### Output Format

Use whatever structure fits the discussion: bullet lists, topic sections, timeline format, question-driven, freeform. The goal is clarity, not template compliance.

Essential elements:
- Minimal capture of author's words
- Vagueness preserved
- AI suggestions wrapped in `<AI>` tags
- Author-only info wrapped in `<hidden>` tags
- Rejected ideas wrapped in `<rejected>` tags when relevant

## Brainstorming Types

All brainstorm types share the core principles above. See resources for specialized guidance:

- [`resources/brainstorming/chapter-planning.md`](brainstorming/chapter-planning.md): beat and scene exploration, pacing thoughts, chapter structure
- [`resources/brainstorming/character-development.md`](brainstorming/character-development.md): motivations, arcs, relationships, voice
- [`resources/brainstorming/worldbuilding.md`](brainstorming/worldbuilding.md): systems, cultures, geography, lore
- [`resources/brainstorming/continuity-timeline.md`](brainstorming/continuity-timeline.md): chronology, contradictions, knowledge propagation

Read the relevant resource when the brainstorm focuses on that area.

## Calibration

The success check: the author says "yes, that's what I said." Capture stated
facts, preserve uncertainty, add brief tagged options when useful, keep notes
minimal.

## File Placement

`/creative-writing-skills:story-memory` `resources/kb-layout.md` has the work layout and what reaches the kb.
