# Story Architecture

Structure story at multiple levels so that each scene, chapter, and arc serves
the larger narrative. The patterns here apply across methodologies (three-act,
hero's journey, kishotenketsu, etc.): adapt them to what the story needs.

## Structural Levels

Stories operate at nested scales. Decisions at one level constrain and enable
decisions at others.

**Saga/Series**: the full story spanning multiple arcs. What's the overarching
question or transformation? How do arcs build on each other?

**Arc**: a self-contained narrative movement spanning multiple chapters. Each
arc has its own question, rising tension, and resolution, but also advances the
saga-level story. An arc that resolves its own conflict but doesn't change
anything at the saga level is filler.

**Chapter**: a unit of reading. Chapters need internal momentum (something
changes by the end) and external momentum (the reader wants to continue).

**Scene**: the fundamental building block. A scene happens in a specific time
and place, involves specific characters, and changes something. Scenes that
don't change anything are candidates for cutting or combining.

## What Makes Structure Work

**Causation over sequence.** "And then" is not structure. "Therefore" and "but"
are. Events should cause or complicate each other, not merely follow each
other. Can you reorder the scenes without the story breaking? If yes, the
structure is a sequence, not a plot.

**Stakes that escalate.** Each structural level should raise the stakes from
the previous one. Escalation doesn't always mean bigger explosions — stakes can
escalate emotionally, morally, or informationally.

**Setup and payoff.** Every significant payoff needs setup, and every
significant setup needs payoff. The best setups are invisible until the payoff
arrives. Track open setups explicitly across arcs.

**Tension and release.** Sustained tension becomes numbness. The reader needs
variation in intensity at every scale: within scenes, chapters, and arcs.

## Resources

- [`resources/story-architecture/arc-design.md`](story-architecture/arc-design.md): arc components (hook,
  complications, midpoint shift, crisis, resolution) and arc pacing.
- [`resources/story-architecture/chapter-and-scene.md`](story-architecture/chapter-and-scene.md): writing
  an outline (what each beat carries), chapter design (internal completeness,
  external pull), scene design (earning presence), outline vs discovery
  writing.
- [`resources/story-architecture/structural-problems.md`](story-architecture/structural-problems.md):
  common problems (saggy middle, rushed ending, filler arcs, disconnected
  scenes, stakes plateau) and when to use diagrams.
