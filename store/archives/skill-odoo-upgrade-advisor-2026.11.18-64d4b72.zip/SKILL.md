---
name: odoo-upgrade-advisor
description: "Step-by-step Odoo version upgrade advisor: pre-upgrade checklist, community vs enterprise upgrade path, OCA module compatibility, and post-upgrade validation."
risk: critical
source: "self"
date_added: "2026-03-04"
---

# Odoo Upgrade Advisor

## Overview

Upgrading Odoo between major versions (e.g., v15 → v16 → v17) requires careful preparation, testing, and validation. This skill provides a structured pre-upgrade checklist, guides you through the upgrade tools (Odoo Upgrade Service and OpenUpgrade), and gives you a post-upgrade validation protocol.

## When to Use This Skill

- Planning a major Odoo version upgrade.
- Identifying which custom modules need to be migrated.
- Running the upgrade on a staging environment before production.
- Validating the system after an upgrade.

## How It Works

1. **Activate**: Mention `@odoo-upgrade-advisor`, state your current and target version.
2. **Plan**: Receive the full upgrade roadmap and risk assessment.
3. **Execute**: Get a step-by-step upgrade command sequence.

## Upgrade Paths

| From | To | Supported? | Tool |
|---|---|---|---|
| v16 | v17 | ✅ Direct | Odoo Upgrade Service / OpenUpgrade |
| v15 | v16 | ✅ Direct | Odoo Upgrade Service / OpenUpgrade |
| v14 | v15 | ✅ Direct | Odoo Upgrade Service / OpenUpgrade |
| v14 | v17 | Tool-specific | OpenUpgrade requires each intermediate migration; official service eligibility must be checked separately |
| v13 or older | supported target | Assess coverage | Check official-service eligibility or historical OpenUpgrade branches/module coverage |

Confirm a tested database+filestore restore and rollback/cutover plan before any migration. Uploading production backups to an external upgrade service needs authorization for the data transfer; redact secrets and use isolated staging credentials. See [official upgrade guidance](https://www.odoo.com/documentation/17.0/administration/upgrade.html) and [OpenUpgrade setup and version sequencing](https://oca.github.io/OpenUpgrade/040_run_migration.html).

## Examples

### Example 1: Pre-Upgrade Checklist

```text
BEFORE YOU START:
  ☑ 1. List all installed modules (Settings → Technical → Modules)
        Export to CSV and review for custom/OCA modules
  ☑ 2. Check OCA compatibility matrix for each community module
        https://github.com/OCA/maintainer-tools/wiki/Migration-Status
  ☑ 3. Take a full backup (database + filestore) — your restore point
  ☑ 4. Clone production to a staging environment
  ☑ 5. Run the Odoo Upgrade pre-analysis:
        https://upgrade.odoo.com/ → Upload DB → Review breaking changes report
  ☑ 6. Review custom modules against migration notes
        (use @odoo-migration-helper for per-module analysis)
  ☑ 7. Upgrade and test in staging → Fix all errors → Re-test
  ☑ 8. Schedule a production maintenance window
  ☑ 9. Notify users of scheduled downtime
  ☑ 10. Perform production upgrade → Validate → Go/No-Go decision
```

### Example 2: Community Upgrade with OpenUpgrade

```bash
# Clone OpenUpgrade for the TARGET version (e.g., upgrading to v17)
git clone https://github.com/OCA/OpenUpgrade.git \
  --branch 17.0 \
  --single-branch \
  /opt/openupgrade

# Modern OpenUpgrade supplies addons, not the Odoo server. Install a reviewed
# target-version Odoo server and openupgradelib; include openupgrade_framework
# and openupgrade_scripts in the staging config addons_path. Disable outbound
# mail, cron, payments and external connectors in the cloned database.
# Run the migration against your staging database
python3 /opt/odoo-17/odoo-bin \
  --update all \
  --database odoo_staging \
  --config /etc/odoo/odoo.conf \
  --stop-after-init \
  --load=base,web,openupgrade_framework

# Review the log for errors before touching production
tail -200 /var/log/odoo/odoo.log | grep -E "ERROR|WARNING|Traceback"
```

### Example 3: Post-Upgrade Validation Checklist

```text
After upgrading, validate these critical areas before going live:

Accounting:
  ☑ Trial Balance totals match the pre-upgrade snapshot
  ☑ Open invoices, bills, and payments are accessible
  ☑ Bank reconciliation can be performed on a test statement

Inventory:
  ☑ Stock valuation report matches pre-upgrade (run Inventory Valuation)
  ☑ Open Purchase Orders and Sale Orders are visible

HR / Payroll:
  ☑ All employee records are intact
  ☑ Payslips from the last 3 months are accessible and correct

Custom Modules:
  ☑ Every custom module loaded without ImportError or XML error
  ☑ Run the critical business workflows end-to-end:
      Create sale order → confirm → deliver → invoice → payment

Users & Security:
  ☑ User logins work correctly
  ☑ Access rights are preserved (spot-check 3-5 users)
```

## Best Practices

- ✅ **Do:** Always upgrade on a **copy of production** (staging) first — never the live instance.
- ✅ **Do:** Keep the old version running until the new version is **fully validated and signed off**.
- ✅ **Do:** Check OCA's migration status page: [OCA Migration Status](https://github.com/OCA/maintainer-tools/wiki/Migration-Status)
- ✅ **Do:** Use the [Odoo Upgrade Service](https://upgrade.odoo.com/) pre-analysis report to get a list of breaking changes **before writing any code**.
- ❌ **Don't:** Skip intermediate versions with OpenUpgrade. The official Odoo upgrade service has its own supported-source/target policy; do not impose OpenUpgrade's sequence on it.
- ❌ **Don't:** Upgrade custom modules and Odoo core simultaneously — adapt Odoo core first, then fix custom modules.
- ❌ **Don't:** Run OpenUpgrade against production directly — always test on a staging copy first.

## Limitations

- Examples target **v14–v17**. Older OpenUpgrade branches exist; migration feasibility depends on module coverage and custom data, not a blanket v13 cutoff.
- **Enterprise-exclusive module changes** (e.g., `sign`, `account_accountant`) may have undocumented breaking changes not included in OpenUpgrade.
- The **Odoo.sh** automated upgrade path has a separate workflow (managed from the Odoo.sh dashboard) not covered here.
- OWL JavaScript component migration (legacy widget → OWL v16+) is a complex front-end topic beyond the scope of this skill.
