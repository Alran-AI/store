---
name: structured-artifact
description: 'Load when the human wants something to browse rather than read: an HTML page that explains or presents information, with its delivery.'
metadata:
  type: reference
---

# Structured Artifact

Decide what the reader should take from the page before choosing tools. The
first view says what the page is and shows its main point without a click.
Detail, method and evidence sit behind expandable sections or further down.
The context the reader needs to decide, and any caveat that changes the
decision, stays beside the claim it qualifies.

Read [delivery](resources/delivery.md) when building the artifact. Read
[diagrams](resources/diagrams.md) when showing relationships or flows, and
[images](resources/images.md) when embedding, annotating, or comparing
images and screenshots.
