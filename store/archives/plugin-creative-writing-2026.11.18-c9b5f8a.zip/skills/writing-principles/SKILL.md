---
name: writing-principles
description: |
  What fiction readers want (reader reward channels) and the specific ways LLM training damages them. Load when drafting prose, critiquing, or diagnosing why a passage feels flat.
metadata:
  type: principle
---

# Writing Principles

## Trust the Reader

The reader is an active collaborator. They reconstruct emotions from behavior,
infer motives from action, hold tension across scenes, fill gaps the text
leaves open, and make assumptions about what's coming next. That work is where
the reward lives: reconstruction, inference, anticipation.

In conversation, explaining, resolving, clarifying and completing is what
helps; it is what you were trained to do well. In fiction the same moves do
work the reader wanted to do themselves, and the reading experience loses
what they would have found. The failure modes below are all forms of
this: not trusting the reader to interpret an emotion, hold an ambiguity,
follow subtext, or tolerate unresolved tension.

Trust doesn't mean obscurity. Readers also need coherent narrative, stable
geography, and enough access to model characters. The discipline is knowing
when to leave space and when to orient.

## Economy

Every element does more than one thing. A line of dialogue advances plot
AND reveals character. A sensory detail grounds the scene AND shows who the
POV character is. A transition compresses time AND carries an emotional
beat. Single-purpose prose makes fiction go flat: description that only
describes, dialogue that only informs, interiority that only labels.

Economy isn't minimalism. Dense, lyrical prose can be economical when every
phrase carries weight. Sparse prose can be wasteful when it takes ten short
sentences to do what one image could do. The measure is whether removing
the element would cost the reader something.

Completeness serves an answer: every beat covered, every emotion named,
every ambiguity resolved. A scene needs less. Ask what you can leave out
and still have the scene work. What's the reader
already doing for you?

## Reader Reward Channels

Readers enjoy fiction through overlapping reward channels. Good prose protects
the relevant channels at once; damaging one damages the reading experience.

- **Transportation**: entering the story world. Protected by coherent
  narrative progression, consistent POV, concrete sensory grounding. Consistent
  POV means writing from inside the character's knowledge state: what have
  they experienced, what do they actually know right now, what would they
  notice and miss? The full story is in your context window; the character
  only has what they've lived through. Separate those.
- **Aesthetic**: sentence-level pleasure. Protected by variety in rhythm,
  word choice, sentence shape, and punctuation. Style is a reward channel, not decoration.
- **Social simulation**: modeling characters as minds. Protected by access
  through behavior and interiority, distinct voices, emotion the reader
  interprets rather than being told.
- **Flow**: challenge-skill fit and smooth processing. Protected by pacing that
  matches the scene's work and sentences that support comprehension without
  making the reading trivial.
- **Curiosity / prediction reward**: wanting to know what happens, what a clue
  means, what a character will choose, or whether an expectation will be
  confirmed. Protected by information gaps, uncertainty, setup/payoff, suspense,
  and withheld implications that the reader can actively model.

The channels compose: optimizing one at the expense of others fails.
Over-explaining breaks social simulation. Under-explaining breaks
transportation. Generic style breaks aesthetic pleasure. Impenetrable style
breaks flow.

## Punctuation Tells

Readers increasingly associate em dashes with AI-generated prose. Default to
punctuation that leaves less visible AI residue: sentence breaks, commas,
colons, semicolons, parentheses, or dialogue beats. Rewrite the sentence
around the actual relationship between clauses instead of substituting a
hyphen. Use dashes only when a project style file or author instruction makes
them part of the voice. When a line needs interruption, prefer the project's
documented interruption pattern and keep it consistent.

## Applying the Principles

This skill is the diagnostic layer: it names what readers want and how
training damages it. When a passage feels off and you can't name why, check
the reward channels — which one broke? — then see `resources/failure-modes.md`
for common patterns and fix heuristics.

## Resources

- [`resources/failure-modes.md`](resources/failure-modes.md): per-pattern
  deep dives with examples and fix heuristics.
- [`resources/antipatterns.md`](resources/antipatterns.md): the patterns that
  mark prose as AI-written, sorted by evidence quality; writers check a draft
  against it before handing it back, critics hunt for them.
