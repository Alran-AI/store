# Source

Unmodified copy of `skills/debugging-and-error-recovery` from https://github.com/addyosmani/agent-skills
at commit 39b723ceebf81474d0557c1fecd01eddab585563 (2026-11-13), under the MIT licence.

Copyright (c) 2025 Addy Osmani

The licence text is in LICENSE.txt. Nothing in this folder was edited.
