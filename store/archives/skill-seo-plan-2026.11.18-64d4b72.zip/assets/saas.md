<!-- Imported template dated 2026-02-07; locally reviewed 2026-10-23. -->

All word-count, page-count, timing, character-range and publishing targets are editorial starting points, not Google requirements or guaranteed ranking effects. Use verified credentials, original evidence and real business facts only. Schema examples contain placeholders/fictional ratings that must not be published unchanged. Vocabulary validity differs from Google rich-result eligibility; check current feature documentation.
# SaaS SEO Strategy Template

## Industry Characteristics

- Long sales cycles with multiple touchpoints
- Feature-focused decision making
- Comparison shopping behavior
- Heavy research phase before purchase
- Integration and ecosystem considerations

## Recommended Site Architecture

```
/
├── Home
├── /product (or /platform)
│   ├── /features
│   │   ├── /feature-1
│   │   ├── /feature-2
│   │   └── ...
│   ├── /integrations
│   │   ├── /integration-1
│   │   └── ...
│   └── /security
├── /solutions
│   ├── /by-industry
│   │   ├── /industry-1
│   │   └── ...
│   └── /by-use-case
│       ├── /use-case-1
│       └── ...
├── /pricing
├── /customers
│   ├── /case-studies
│   │   ├── /case-study-1
│   │   └── ...
│   └── /testimonials
├── /resources
│   ├── /blog
│   ├── /guides
│   ├── /webinars
│   ├── /templates
│   └── /glossary
├── /docs (or /help)
│   └── /api
├── /company
│   ├── /about
│   ├── /careers
│   ├── /press
│   └── /contact
└── /compare
    ├── /vs-competitor-1
    └── /vs-competitor-2
```

## Content Priorities

### High Priority Pages
1. Homepage (value proposition, social proof)
2. Features overview
3. Pricing page
4. Key integrations
5. Top 3-5 use case pages

### Medium Priority Pages
1. Individual feature pages
2. Industry solution pages
3. Case studies (2-3 detailed ones)
4. Comparison pages (vs competitors)

### Content Marketing Focus
1. Bottom-of-funnel: Comparison guides, ROI calculators
2. Middle-of-funnel: How-to guides, best practices
3. Top-of-funnel: Industry trends, educational content

## Schema Recommendations

| Page Type | Schema Types |
|-----------|-------------|
| Homepage | Organization, WebSite, SoftwareApplication |
| Product/Features | SoftwareApplication, Offer |
| Pricing | SoftwareApplication, Offer (with pricing) |
| Blog | Article, BlogPosting |
| Case Studies | Article, Organization (customer) |
| Documentation | TechArticle |

## Key Metrics to Track

- Organic traffic to pricing page
- Demo/trial signups from organic
- Blog → pricing page conversion
- Comparison page rankings
- Integration page performance

## Comparison & Alternative Pages

Comparison pages may serve high-intent visitors, but this bundle establishes no universal conversion-rate advantage. Measure with a defined traffic population and qualified conversion event.

**Recommended page types:**
- `/{product}-vs-{competitor}`: Direct 1:1 comparison
- `/{competitor}-alternative`: Targeting competitor brand searches
- `/compare/{category}`: Category comparison hub
- `/best-{category}-tools`: Roundup-style pages

**Best practices:**
- Include structured comparison tables with pricing, features, pros/cons
- Be factually accurate about competitors: verify claims regularly
- Include customer testimonials from users who switched
- Answer real comparison questions; do not promise Google FAQ rich results or AI-citation benefit from FAQPage markup
- Update regularly: stale comparison data damages credibility
- Cross-reference the `seo-competitor-pages` skill for detailed frameworks

**Legal considerations:**
- Nominative fair use generally permits competitor brand mentions for comparison purposes
- Do NOT imply endorsement or affiliation
- Do NOT make false or unverifiable claims about competitor products
- Different jurisdictions have different trademark laws: consult legal counsel

## Competitive Considerations

- Monitor competitor feature releases
- Track competitor content strategies
- Identify keyword gaps in feature coverage
- Watch for new comparison opportunities

## Generative Engine Optimization (GEO) for SaaS

- [ ] Include clear, structured feature comparisons that AI systems can parse and cite
- [ ] Use SoftwareApplication schema with complete feature lists and pricing
- [ ] Publish original benchmark data, case studies, and ROI metrics
- [ ] Build content clusters around key product categories and use cases
- [ ] Ensure integration pages have clear, quotable descriptions
- [ ] Structure pricing information in tables AI can extract
- [ ] Monitor AI citation across Google AI Overviews, ChatGPT, and Perplexity
