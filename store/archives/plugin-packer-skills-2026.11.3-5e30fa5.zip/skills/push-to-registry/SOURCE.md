# Source

Unmodified copy of `plugins/packer/skills/push-to-registry` from https://github.com/hashicorp/agent-skills
at commit 5e30fa5c867ba6777c37e4206babfd08049c396f (2026-11-03), under the MPL-2.0 licence.

The licence text is in LICENSE.txt. Nothing in this folder was edited.
