---
name: healthcare-system-primer
description: "Summarise what Healthcare System Primer does in one line. Use when asked to [trigger phrases the user would say]. Produces [the concrete artifact]."
---

# Healthcare System Primer Skill

One-line summary of the value this skill delivers. <!-- TODO: rewrite -->

## Working from a brief

Deliver the full artifact even from a thin brief — infer and label assumptions, never refuse for missing context. <!-- TODO: tailor -->

## Required Inputs

Ask for (if not already provided), else infer and label:
- <!-- TODO: the inputs to gather -->

## Output Format

<!-- TODO: a concrete template (headings/tables) of the final artifact -->

## Quality Checks

- [ ] <!-- TODO: a check the output must pass before hand-off -->

## Anti-Patterns

- [ ] Do not <!-- TODO: the mistake this skill prevents -->

## Example Trigger Phrases

- "How does healthcare work in [country]?"
- "Do I need health insurance in [country]?"
- "I just moved and need to see a doctor."

Run this skill in your browser: https://mohitagw15856.github.io/pm-claude-skills/skill/healthcare-system-primer.html
