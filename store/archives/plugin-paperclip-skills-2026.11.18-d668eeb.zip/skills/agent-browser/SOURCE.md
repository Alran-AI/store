# Source

Unmodified copy of `packages/skills-catalog/catalog/optional/browser/agent-browser` from https://github.com/paperclipai/paperclip
at commit d668eeb66056f51659494250d9d5b533c1189273 (2026-11-18), under the MIT licence.

Copyright (c) 2025 Paperclip AI

The licence text is in LICENSE.txt. Nothing in this folder was edited.
