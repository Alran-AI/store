# Shared alerting architecture

Use this reference to decide where code belongs before editing it.

## Layer map

| Layer                       | Location                                                     | Owns                                                                                                                                       |
| --------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------ |
| Pure lifecycle decisions    | `products/alerts/backend/facade/lifecycle.py`                | State transitions, policy decisions, and notification actions                                                                              |
| Shared alert door           | `products/alerts/backend/facade/`                            | Contracts, constants, scheduling math, delivery SLOs, and insight alert reads and writes. Other products call it                           |
| Shared alert implementation | `products/alerts/backend/logic/`                             | Destination configuration and persistence, internal-event delivery, and email transport. Only the facade calls it                          |
| Insight alert evaluation    | `products/alerts/backend/evaluation/`                        | Insight query extraction, comparison, and breach formatting. Core still drives it directly                                                 |
| Product adapter             | `products/<name>/backend/`                                   | Domain evaluation, model snapshots, the single mutator, event payloads, allowed destinations, due queries, history, and orchestration      |
| Shared alert creation UI    | `frontend/src/lib/components/Alerting/AlertWizard/`          | Reusable HogFunction destination, trigger, and configuration flow                                                                          |
| Shared product alert UI     | `products/alerts/frontend/components/`                       | Container-agnostic editor layout, definition primitives, advanced options, destination editor, schedule presentation, and evaluation chart |
| Product UI                  | `products/<name>/frontend/` or `frontend/src/scenes/<name>/` | Form logic, API calls, product fields, normalized adapters, entry points, detail tables, and wizard configuration                          |

`products/billing_alerts` is the reference adopter for the backend boundary shape: it holds destination ids and the facade contracts, and never an alerts model or queryset.

`products/logs` is the reference adopter for fixed-cadence scheduling, HogFunction destinations, delivery rollback, product-owned Temporal orchestration, and the shared product alert editor components.

Logs and insight alerts both adapt their product state to the shared lifecycle engine. Insight alerts are the reference adopter for calendar anchors, weekend skipping, and email delivery. Both products use shared schedule restrictions for quiet hours. Each product keeps its model, due query, and scheduling persistence. The evaluation package is shared across insight query kinds, but it is not a generic evaluator for unrelated products.

## Boundary

Consumers import `products.alerts.backend.facade.*`. The tach interface also exposes `presentation.views.*` and `routes.*`, which carry the DRF surface other products mount or reuse in process.

- Models, querysets and DRF objects never cross the facade in either direction.
- Facade functions take and return contracts, ids, and plain values.
- Consumers hold ids and come back to the facade for anything else.

Core still runs the insight-alert pipeline itself, so its imports of the alert models, the insight evaluation, the insight lifecycle adapter, the investigation episode reader and the Max tool stay open. Those five are named in the legacy-leaks block for `products.alerts` in `tach.toml`, and the product stays non-isolated until the block is empty.

## Frontend contract

Shared product alert UI lives in `products/alerts/frontend/components/`. It is presentation infrastructure, not a frontend product registry.

- `AlertEditor`, `AlertEditorFormDetails`, and `AlertEditorSection` provide the container-agnostic form shell.
- `AlertDefinition*` components provide composable definition, schedule, next-evaluation, and timezone presentation.
- `AlertAdvancedOptions` owns shared collapse and enabled-count behavior.
- `QuietHoursFields` renders shared quiet-hour inputs from a normalized restriction, cadence, and project timezone.
- `AlertNotificationDestinationEditor` renders normalized saved and pending destinations.
- `AlertEvaluationHistoryChart` renders normalized evaluation points and current thresholds.

Products own keyed kea logic, API calls, form schemas, source/filter controls, supported destination types, HogFunction payloads, threshold conversion, enabled-count calculation, and history tables. Keep modals, scene widths, and embedded-section sizing in the product surface.

`AlertWizard` remains the shared HogFunction creation flow. Adopters provide keyed `alertWizardLogic` props with supported sub-template IDs, `WizardTrigger[]`, `WizardDestination[]`, and optional URL or preset behavior. Backend destination support alone does not make an option available in the wizard.

Read [frontend-alerting.md](frontend-alerting.md) before adding or extending a product alert frontend. Follow `frontend/src/AGENTS.md`, use generated API types, and guard network submissions from double clicks.

## Lifecycle contract

`products/alerts/backend/facade/lifecycle.py` is pure Python.

- `CheckInput` normalizes one product evaluation.
- `AlertSnapshot` contains only fields needed for lifecycle decisions.
- `AlertPolicy` represents deliberate differences between adopters. Its defaults are existing behavior, not a menu of speculative options.
- `evaluate_alert_check(...)` and `evaluate_alert_failure(...)` return `AlertCheckOutcome` without persistence.
- Control-plane helpers such as `apply_enable`, `apply_disable`, `apply_snooze`, and `apply_threshold_change` return `ControlPlaneOutcome`.
- `NotificationAction` tells the product which event to deliver.

The product converts its model to a snapshot and applies the outcome through one local `apply_outcome` function. Extend `.semgrep/rules/security/alert-state-must-go-through-state-machine.yaml` when another product adopts this contract.

Error behavior is load-bearing:

- Failed checks do not clear an already firing alert.
- Inconclusive checks preserve state and failure count.
- Transient errors are silent unless the policy opts into counting them.
- Error notification normally occurs on the first failure edge.
- Delivery failure must not consume a lifecycle or failure-counter edge that should be retried.

## Destination contract

Product-facing destination setup lives in `products.alerts.backend.facade.destinations`. Read that module for the full surface. An adopter starts from:

- `validate_destination_data`
- `destination_handles_event_kind`
- `build_alert_destination_config`
- `create_alert_destination_hog_functions`
- `soft_delete_alert_destinations`

The module also holds the destination limits. The insight-alert event and destination-type constants live in `products.alerts.backend.facade.api`.

`send_alert_email` lives in `products.alerts.backend.facade.email`. The data types the
functions above take and return live in `products.alerts.backend.facade.contracts`.

`create_alert_destination_hog_functions` returns the ids of the hog functions it created. It
does not return model rows, so the caller keeps ids and asks for anything else through
another facade read.

`EventKindSpec` describes destination-neutral content for one event kind. The shared builder converts it into a HogFunction payload through an internal registry where each destination type owns its template ID, required fields, input building, read-back, and read redaction. Adding a destination type means adding one entry there. Products own event IDs, event properties, wording, actions, and their allowed destination list.

Not every destination type has something to send for every event kind. An incident manager such as PagerDuty follows only the kinds that trigger or resolve an incident, which a product marks with `EventKindSpec.incident_action`. Every other destination type follows only the kinds without it. Filter a product's event kinds with `destination_handles_event_kind` before building configs; `build_alert_destination_config` raises for a kind the destination type does not handle.

An incident manager needs a resolve for every trigger, or the incident it opened stays open and absorbs the next trigger on the same deduplication key. So the incident kinds follow the firing state, not the notification: emit one on every transition into and out of firing, even when cooldown suppresses the notification. Logs alerts do this with `$logs_alert_incident_opened` and `$logs_alert_incident_closed`, read from `incident_edge` in `products/logs/backend/alert_state_machine.py`.

A destination type whose configuration is a credential, such as the PagerDuty integration key, stores it as a secret template input. The read path merges `encrypted_inputs` back before it reads a config, so grouping and duplicate detection see the real value while `redact_destination_data` keeps it out of API responses.

Validation failures raise `AlertDestinationValidationError`, a plain exception with a message and an optional field name. The adopter's view translates it into its own framework's validation error, because the facade has no HTTP layer of its own. `as_drf_validation_error` in `posthog.exceptions` does that translation for a DRF view.

Deletion is fail-closed. Always scope it with `team_id`, `alert_id`, and the product's allowed event IDs.
`create_alert_destination_hog_functions` refuses any destination in the call that the alert already has, so call it with the alert row locked.

## Delivery contract

HogFunction notification workers use `products.alerts.backend.facade.destinations`:

1. `produce_alert_internal_event(...)` returns a `ProduceResult` or `None`.
2. `flush_alert_internal_events(...)` flushes the shared producer. Batch workers should flush once per produced batch.
3. `alert_internal_event_delivered(...)` checks whether the producer acknowledged each internal event after the flush.
4. The product persists notification-dependent lifecycle changes only for acknowledged internal events.

This acknowledgement confirms production to the internal-event transport, not downstream HogFunction execution or final Slack, Discord, webhook, or Microsoft Teams delivery. The helpers log and capture producer failures. The product owns rollback, retry timing, schedule advancement, and check-history semantics.

Wrap the delivery step in `alert_delivery_slo(...)` from `products.alerts.backend.facade.delivery_slo`. Logs' Temporal activities are the reference.

Email callers use `send_alert_email(...)` from `products.alerts.backend.facade.email`. The caller owns recipients, authorization, subject, template, context, error handling, and a stable `campaign_key` for the required retry and deduplication behavior.

## Scheduling contract

`products/alerts/backend/facade/scheduling.py` is pure Python and owns reusable scheduling math:

- `compute_shard_offset_seconds(...)` deterministically assigns a UUID-keyed alert to scheduler ticks.
- `advance_next_check_at(...)` advances from the prior schedule, skips missed intervals, snaps to the midnight-anchored cadence grid, and applies the shard offset.
- `CalendarInterval` and `to_calendar_interval(...)` define the product-facing interval contract.
- `next_calendar_check_time(...)` computes fixed-cadence or team-local daily, weekly, and monthly anchors while preserving wall-clock behavior across DST changes.
- `validate_and_normalize_schedule_restriction(...)` and `parse_blocked_windows_tuples(...)` validate product payloads and produce the pure blocked-window contract.
- `scan_next_unblocked_utc(...)`, `is_utc_datetime_blocked(...)`, and `is_weekend(...)` apply timezone-aware restrictions without importing Django models.

Use the scheduler's real interval when computing shards. Use the same shard function when creating, updating, and advancing an alert.

Products translate their enums and stored payloads into the shared contract. Due eligibility, schedule persistence, retry behavior, and orchestration stay product-specific because model fields, states, snooze behavior, and tenant constraints differ.
