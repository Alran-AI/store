---
name: rice-impact-matrix
description: "Scores features using both RICE and strategic alignment for nuanced prioritisation. Use when asked to prioritise features, build a priority matrix, combine quantitative scoring with strategic fit, or decide what to build next with multiple competing initiatives. Produces a scored priority matrix with RICE scores, strategic alignment ratings, quadrant placement, and sequencing recommendations."
---

# RICE + Strategic Alignment Skill

Produce a prioritisation output that balances quantitative RICE scoring with qualitative strategic fit — because the highest RICE score isn't always the right next bet.

## Required Inputs

Work from what is given. If any of these is missing, still produce the complete output: fill each gap with a reasonable assumption marked *(assumed, confirm)* and list those assumptions at the end. Ask a question first only when the core subject itself is missing (there is nothing to write about).
- **List of initiatives or features to prioritise** (names and brief descriptions)
- **Current strategic priorities or OKRs** (needed to rate strategic alignment)
- **Reach estimates** (users affected per quarter — even rough estimates work)
- **Effort estimates** (person-months — from engineering if available)
- **Quarter or planning period**

## Two-Stage Process

### Stage 1: RICE Scoring
- Reach: Users affected per quarter
- Impact: 3/2/1/0.5/0.25 scale
- Confidence: 100% / 80% / 50%
- Effort: Person-months
- RICE = (R × I × C) / E

### Stage 2: Strategic Alignment Score
Rate each initiative against your current strategic priorities (provided as input):
- Directly supports top OKR: +3
- Supports secondary OKR: +2
- Neutral: +1
- Contradicts strategic direction: -1

### Final Priority Score
Combined Score = RICE Score + (Strategic Alignment × 10)

**Validate** — Flag any initiative where RICE score and strategic alignment conflict sharply (e.g., high RICE, low alignment). These require an explicit team conversation before sequencing.

## Output Structure

### Priority Matrix — [Quarter]
| Initiative | RICE Score | Strategic Alignment | Combined Score | Quadrant | Recommendation |
|------------|------------|--------------------|--------------------|----------|----------------|
| [name] | [score] | [score] | [combined] | [Now/Next/Later/Drop] | [action] |

#### Quadrant Definitions
- **Now:** High RICE + High Strategic Alignment → Build this quarter
- **Next:** High RICE + Lower Alignment → Queue for next quarter
- **Later:** Lower RICE + High Alignment → Revisit when capacity allows
- **Drop:** Low RICE + Low Alignment → Remove from backlog

#### Recommendations
[Top 5 initiatives with rationale for sequencing]

## Deeper Materials

This skill ships with support files — use them when they are available:

- **`references/strategic-weighting.md`** — Blending RICE with Strategic Fit — Without Cooking the Books. Apply it while producing the output; it carries the calibration and judgment calls the method summary above compresses.
- **`templates/matrix-worksheet.md`** — a fill-in version of the deliverable with the quality gates inline. Offer it when the user wants to work the document themselves rather than have it generated.

## Scoring Rubric (0–40)

Score any output of this skill before handing it over; 32+ is ship-quality.

| Dimension | 0 | 5 | 10 |
|---|---|---|---|
| Scoring integrity | Invented or uniform component values; 100% confidence everywhere | All components estimated, but confidence levels unexamined and scales inconsistent across rows | Every component sourced or explicitly flagged; no unvalidated 100%s; 50%-confidence rows marked and scale choices (e.g. reach units) stated |
| Strategic-alignment rigour | Alignment rated on "feels strategic" with no reference to priorities | Ratings given but not tied to named OKRs; nothing scores negative | Every rating maps to a specific OKR by name; initiatives that contradict strategy actually receive −1 |
| Conflict surfacing | Combined score presented as the definitive ranking | Sharp RICE-vs-alignment divergences are visible in the table but never discussed | Every sharp divergence is flagged with an explicit conversation recommendation (owner, forum, and a scoreable alternative where one exists) |
| Quadrant decisiveness | Everything lands in "Now"; no Drops | Quadrants used, but Drop recommendations are vague ("deprioritise") and capacity is ignored | Honest distribution including specific Drop actions with re-entry conditions, and sequencing checked against actual capacity |

## Quality Checks

- [ ] All RICE components have an estimate (even if low confidence — flag those)
- [ ] Strategic alignment is rated against specific OKRs, not general "feels strategic"
- [ ] Conflicts between RICE rank and strategic alignment are explicitly flagged
- [ ] "Drop" recommendations are specific — not just "low priority, deprioritise"
- [ ] Confidence levels on estimates are noted where weak (drives the 50% confidence flag)

## Anti-Patterns

- [ ] Do not treat the combined score as a definitive ranking — use it to structure a conversation, not replace one
- [ ] Do not rate strategic alignment as "high" because an initiative feels important without mapping it to a specific OKR
- [ ] Do not place all initiatives in the "Now" quadrant — a matrix with no "Drop" recommendations is not credible
- [ ] Do not ignore the conflict flag when RICE rank and strategic alignment sharply diverge
- [ ] Do not accept 100% confidence on estimates that have not been validated with data

## Example Trigger Phrases

- "Prioritise features."
- "Build a priority matrix."
- "Decide what to build next with multiple competing initiatives."

Run this skill in your browser: https://mohitagw15856.github.io/pm-claude-skills/skill/rice-impact-matrix.html
