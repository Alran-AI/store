---
name: cognee-server
description: Use when the user wants to run the cognee API server (and optional UI) on their own machine — starting it, checking it's healthy, connecting the SDK or other clients to it, and choosing the right auth posture.
---

# Start the cognee server locally

## From an installed cognee (no Docker)

```bash
cognee-cli -ui
```

launches the full local stack: FastAPI backend on **http://localhost:8000**
and the UI on **http://localhost:3000**. Needs `LLM_API_KEY` in the
environment or `.env`. The interactive API reference is at
http://localhost:8000/docs, health at `/health`.

For API-only serving via Docker instead, use the cognee-docker skill (the
prebuilt `cognee/cognee:main` image or `docker compose up` from the repo).

## Auth posture

`ENABLE_BACKEND_ACCESS_CONTROL` decides everything:

- `true` (default): multi-tenant — auth required on every API call, per
  user+dataset database isolation.
- `false`: single-user local mode — no auth, shared local databases. Right
  choice for a personal dev server; never for anything exposed.

`REQUIRE_AUTHENTICATION=false` is ignored while access control is on; to turn
auth off you must set `ENABLE_BACKEND_ACCESS_CONTROL=false`.

Behind a TLS-terminating proxy set `AUTH_TOKEN_COOKIE_SECURE=true` so the auth cookie
gets the `Secure` attribute; leave it off for plain `http://localhost`, where a browser
refuses to store a Secure cookie.

### URL ingestion

API requests cannot fetch URLs or clone remote repositories unless the server
sets `ALLOW_HTTP_REQUESTS=true`. A blocked attempt raises an error naming that
setting. With the variable unset or blank, SDK, CLI and MCP calls still allow
fetching. Only `true`, `1`, `yes` or `on` enable it; any other value (`false`,
or a misspelling) disables it on every surface. This setting does not disable
LLM or embedding provider calls.

## Connecting clients to the running server

- **SDK / CLI against the server** (instead of embedded local mode):

  ```bash
  cognee-cli serve --url http://localhost:8000        # local instance
  cognee-cli serve --url https://... --api-key ck_... # cognee cloud instance
  cognee-cli serve                                    # reconnect to the saved keyed instance
  cognee-cli serve --logout                           # disconnect
  ```

  In Python: `await cognee.serve(url="http://localhost:8000")`.

- **HTTP**: main routes live under `/api/v1/` — the memory API is `remember`
  (plus `remember/entry`), `recall`, `improve`, `forget`; `sessions` covers
  session memory; `datasets`, `users`, `visualize` handle the rest. The legacy
  `add`, `cognify`, `search`, and `delete` routes still exist and are
  what the memory routes call underneath (see `cognee/api/client.py` for the
  registered routers, or `GET /openapi.json` on a running server).

  Note there is **no `/api/v1/feedback` route** — `feedback` exists as a CLI
  command and in the SDK, but is not exposed over HTTP.

## Graph visualization without the full UI

```python
from cognee.api.v1.visualize import visualization_server

shutdown = visualization_server(port=8080)  # synchronous; returns a shutdown callable
```

## Troubleshooting

- Port 8000 already taken → stop the other service or remap (compose:
  `"8080:8000"`).
- 401/403 on every call → you're in multi-tenant mode; either authenticate or
  set `ENABLE_BACKEND_ACCESS_CONTROL=false` and restart.
- `recall`/`search` returns `[]` instead of erroring → permission-filtered
  result; check dataset access rights for the calling user.
