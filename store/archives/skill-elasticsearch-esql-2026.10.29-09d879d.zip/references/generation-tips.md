# ES|QL Query Generation Tips

Guidelines for generating accurate ES|QL queries from natural language.

> **Cluster detection:** Check `build_flavor` in the `GET /` response. For Serverless (`"serverless"`), **do not**
> version-gate: `version.number` tracks the next minor from main (semver-only clients may see it as “latest”), but
> feature availability is not determined by that string — use `build_flavor` as the signal. For Stack (`"default"`), use
> `version.number` for feature checks (strip `-SNAPSHOT` suffix on pre-release builds).

## Table of Contents

- [Critical Syntax Rules](#critical-syntax-rules)
- [Step-by-Step Generation Process](#step-by-step-generation-process)
- [Field Name Conventions](#field-name-conventions)
- [Query Optimization Tips](#query-optimization-tips)
- [Key Patterns](#key-patterns)
- [Common Query Templates](#common-query-templates)
- [Handling Ambiguity](#handling-ambiguity)
- [Output Formatting Suggestions](#output-formatting-suggestions)
- [9.5 Additions](#95-additions)

## Critical Syntax Rules

### String Literals Use Double Quotes Only

ES|QL uses **double quotes** for string literals — never single quotes. This is the most common source of
`token recognition error at: '` failures. SQL habits lead models to write `'value'` when ES|QL requires `"value"`.

```esql
// WRONG — single quotes cause parse errors
| WHERE status == 'open'
| EVAL priority = CASE(status == 'open', 'high', 'low')

// CORRECT — always double quotes
| WHERE status == "open"
| EVAL priority = CASE(status == "open", "high", "low")
```

This applies everywhere: `WHERE`, `EVAL`, `CASE`, `STATS ... BY`, function arguments, and string constants.

### Reserved Words Need Backticks as Identifiers

A few ES|QL keywords cannot be used bare as column names, aliases, or as a segment of a dotted field name. `first` and
`last` are the most common traps because they read like natural column names for earliest/latest timestamps. Keywords
are case-insensitive, so `first`, `FIRST`, and `First` are the same token.

```esql
// WRONG — `first` is a reserved keyword
| STATS first = MIN(@timestamp) BY service.name

// CORRECT — rename the column (preferred)
| STATS first_seen = MIN(@timestamp) BY service.name

// CORRECT — or backtick-quote it
| STATS `first` = MIN(@timestamp) BY service.name
```

**Prefer renaming the output column over backticking it** — a descriptive alias like `first_seen` or `earliest` reads
better and avoids the quoting entirely. Backticks are the only option when the clash is in a real field name you do not
control, including a reserved word buried in a dotted path:

```esql
// WRONG — `in` is the IN operator, so the dotted name fails to parse
| WHERE host.network.interface.in.utilization IS NOT NULL

// CORRECT — backtick-quote the whole identifier
| WHERE `host.network.interface.in.utilization` IS NOT NULL
```

**Never bare in an expression:** `FIRST`, `LAST`, `BY`, `IN`, `IS`, `ON`, `WITH`, plus the operator and literal words
`AND`, `OR`, `NOT`, `LIKE`, `RLIKE`, `NULL`, `TRUE`, `FALSE`, `ASC`, `DESC`, `NULLS`. They fail in every expression
position: `EVAL`/`STATS` aliases, `BY`, `WHERE`, `SORT`, function arguments, and dotted segments (`x.in.y`). Only the
looser name lists of `KEEP`, `DROP`, and the `RENAME` source accept them bare.

**Keywords only in one context:**

- `AS` fails bare only inside `RENAME`; `METADATA` only inside `FROM`.
- `SCORE`, `KEY`, and `GROUP` fail bare only as the column right after `FUSE ... SCORE BY`, `KEY BY`, or `GROUP BY` —
  write `` FUSE linear SCORE BY `score` ``. Elsewhere they are ordinary column names.
- Command names (`SET`, `SAMPLE`, `DEDUP`, `LIMIT`, `SORT`, `FUSE`, `FORK`, `RERANK`, `COMPLETION`, `CHANGE_POINT`, …)
  are keywords only as the first word of a pipe segment, so `EVAL sample = 1` or `STATS c = COUNT(*) BY score` parse.

Backquoting any identifier always works. If a name causes an unexplained parse error, backquote it.

### CASE Uses Condition-Value Pairs (Not SQL Syntax)

ES|QL `CASE` takes alternating condition-value pairs with an optional default — it does **not** support
`CASE WHEN ... THEN ... ELSE ... END` syntax.

```esql
// WRONG — SQL-style CASE
| EVAL grade = CASE WHEN score > 90 THEN "A" WHEN score > 80 THEN "B" ELSE "C" END

// CORRECT — ES|QL pairs: CASE(cond1, val1, cond2, val2, ..., default)
| EVAL grade = CASE(score > 90, "A", score > 80, "B", "C")
```

Two-branch conditionals use three arguments (condition, true-value, false-value):

```esql
| EVAL priority = CASE(status == "open", "high", "low")
```

### Aggregation Function Names Differ from SQL

ES|QL function names use underscores where SQL does not. The most common mistake is `STDDEV()` — the correct ES|QL name
is `STD_DEV()`.

| SQL Name | ES\|QL Name |
| -------- | ----------- |
| STDDEV   | STD_DEV     |

```esql
// WRONG — SQL function name
| STATS sd = STDDEV(total)

// CORRECT — ES|QL uses underscored name
| STATS sd = STD_DEV(total)
```

### String Concatenation Uses CONCAT (No + Operator)

ES|QL does not support the `+` operator for string concatenation. Use `CONCAT()` instead. ES|QL also does not have
`SUBSTRING`, `STRPOS`, `SPLIT`, or `INSTR` — use `DISSECT` or `GROK` for string extraction.

```esql
// WRONG — + operator does not work on strings
| EVAL full_name = first_name + " " + last_name

// CORRECT
| EVAL full_name = CONCAT(first_name, " ", last_name)
```

### DATE_EXTRACT Part Names Differ from SQL

`DATE_EXTRACT(part, date)` uses ES|QL-specific part name strings — not SQL keywords like `HOUR` or `DAY`. The part
string must be **double-quoted** and is **case-insensitive**.

| SQL Part | ES\|QL Part Name     |
| -------- | -------------------- |
| YEAR     | `"year"`             |
| QUARTER  | `"quarter"`          |
| MONTH    | `"month_of_year"`    |
| WEEK     | `"week"`             |
| DAY      | `"day_of_month"`     |
| DOW      | `"day_of_week"`      |
| DOY      | `"day_of_year"`      |
| HOUR     | `"hour_of_day"`      |
| MINUTE   | `"minute_of_hour"`   |
| SECOND   | `"second_of_minute"` |

```esql
// WRONG — SQL-style part names or single quotes
| EVAL hour = DATE_EXTRACT("hour", @timestamp)
| EVAL hour = DATE_EXTRACT('HOUR_OF_DAY', @timestamp)

// CORRECT — ES|QL part name in double quotes
| EVAL hour = DATE_EXTRACT("hour_of_day", @timestamp)
| STATS count = COUNT(*) BY hour = DATE_EXTRACT("hour_of_day", @timestamp)
```

### Date Arithmetic Uses DATE_DIFF (No Subtraction)

ES|QL does not support the `-` operator between two date values. Use `DATE_DIFF(unit, start, end)` instead.

```esql
// WRONG — subtraction between dates is not supported
| EVAL days = end_date - start_date

// CORRECT — DATE_DIFF computes the difference in the given unit
| EVAL days = DATE_DIFF("day", start_date, end_date)
```

Valid units: `"year"`, `"quarter"`, `"month"`, `"week"`, `"day"`, `"hour"`, `"minute"`, `"second"`, `"millisecond"`.

---

## Step-by-Step Generation Process

### 1. Identify the Data Source

**Question:** What index or data should be queried?

- Look for index names, data types, or subject areas mentioned
- Common patterns: `logs-*`, `metrics-*`, `events-*`, `apm-*`
- If unclear, use wildcards or ask for clarification

```esql
FROM logs-*           // Generic logs
FROM metrics-*        // Metrics data
FROM my-index-2024.*  // Dated indices
```

For time series data streams (TSDS), use `TS` instead of `FROM` to enable time series aggregation functions like `RATE`,
`AVG_OVER_TIME`, etc. (preview from 9.2 to 9.3, **GA since 9.4**):

```esql
TS metrics-*          // Time series source — enables RATE, AVG_OVER_TIME, etc.
```

**When the question asks about rates, throughput, CPU/memory trends, or metric comparisons**, prefer a `metrics-*` or
TSDS index with `TS` over a general log index with `FROM`. Check the schema — if an index has `Index mode: time_series`,
always use `TS`.

### 2. Determine Time Range

**Question:** What time period should be covered?

| User Expression | ES\|QL                                                                                     |
| --------------- | ------------------------------------------------------------------------------------------ |
| "last hour"     | `@timestamp > NOW() - 1 hour`                                                              |
| "last 24 hours" | `@timestamp > NOW() - 24 hours`                                                            |
| "last 7 days"   | `@timestamp > NOW() - 7 days`                                                              |
| "today"         | `@timestamp >= DATE_TRUNC(1 day, NOW())`                                                   |
| "yesterday"     | `@timestamp >= DATE_TRUNC(1 day, NOW()) - 1 day AND @timestamp < DATE_TRUNC(1 day, NOW())` |
| "this week"     | `@timestamp >= DATE_TRUNC(1 week, NOW())`                                                  |
| "this month"    | `@timestamp >= DATE_TRUNC(1 month, NOW())`                                                 |

**Default:** If no time range is specified, add a reasonable default (e.g., last 24 hours) to avoid scanning too much
data.

### 3. Identify Filters

**Question:** What conditions should narrow the results?

Look for:

- Status/level: "errors", "warnings", "successful"
- Environment: "production", "staging", "dev"
- Source/host: specific servers, services, applications
- Values: specific codes, IDs, names

```esql
// Multiple filters
| WHERE level == "error"
| WHERE environment == "production"
| WHERE service.name == "api-gateway"
```

Or combined:

```esql
| WHERE level == "error" AND environment == "production" AND service.name == "api-gateway"
```

**Negation and NULL values:** ES|QL uses three-valued logic. `WHERE field != "value"` silently excludes rows where the
field is `NULL` (missing). When generating negation filters, always add an `IS NULL` guard:

```esql
| WHERE environment != "test" OR environment IS NULL
```

### 4. Determine Output Type

**Question:** Does the user want raw data or aggregated results?

| User Intent                          | Approach                        |
| ------------------------------------ | ------------------------------- |
| "show me", "list", "find"            | Raw data with KEEP, SORT, LIMIT |
| "count", "how many"                  | STATS with COUNT                |
| "average", "total", "sum"            | STATS with aggregation function |
| "by X", "per X", "grouped by"        | STATS ... BY grouping           |
| "top N", "most common"               | STATS + SORT DESC + LIMIT       |
| "distribution", "breakdown"          | STATS COUNT BY category         |
| "over time", "trend"                 | STATS BY DATE_TRUNC             |
| "patterns", "categorize", "types of" | STATS ... BY CATEGORIZE(field)  |
| "spike", "dip", "anomaly", "change"  | CHANGE_POINT value ON key       |
| "patterns over time"                 | CATEGORIZE + BUCKET             |

When combining `CATEGORIZE` with a time bucket, `CATEGORIZE` must be the first `BY` key — see
[CATEGORIZE Must Be the First BY Key](#categorize-must-be-the-first-by-key). To find _when_ a category's count shifted,
add `CHANGE_POINT value ON bucket BY category` — but per-group `CHANGE_POINT` (the `BY` clause) is GA only on 9.5+ /
Serverless. Without `BY`, `CHANGE_POINT` treats the whole input as one series, so differences between categories look
like temporal changes.

**Prefer single advanced queries over multiple basic ones.** When the user asks to "find patterns" or "analyze logs,"
use `CATEGORIZE` in one query rather than running several `STATS ... BY field` queries against different fields.
Similarly, use `CHANGE_POINT` to detect anomalies rather than producing hourly counts for the user to eyeball.

### 5. Select Fields

**Question:** What fields should be shown?

For raw data queries, use KEEP to select relevant fields:

```esql
| KEEP @timestamp, host.name, message, level
```

For aggregations, the output fields are defined by STATS:

```esql
| STATS count = COUNT(*), avg_time = AVG(response_time) BY endpoint
```

### 6. Apply Ordering and Limits

**Question:** How should results be ordered and limited?

- Time-based: `SORT @timestamp DESC`
- By count/value: `SORT count DESC`
- Alphabetical: `SORT name ASC`

**Always add LIMIT** unless the user specifically wants all results:

```esql
| LIMIT 100  // Reasonable default
| LIMIT 1000 // Maximum before considering pagination
```

---

## Field Name Conventions

When generating queries, use common field naming conventions:

### Elastic Common Schema (ECS)

| Category    | Common Fields                                                  |
| ----------- | -------------------------------------------------------------- |
| Timestamp   | `@timestamp`                                                   |
| Message     | `message`                                                      |
| Log level   | `log.level`, `level`                                           |
| Host        | `host.name`, `host.ip`                                         |
| Service     | `service.name`, `service.type`                                 |
| HTTP        | `http.request.method`, `http.response.status_code`, `url.path` |
| User        | `user.name`, `user.id`                                         |
| Source      | `source.ip`, `source.port`                                     |
| Destination | `destination.ip`, `destination.port`                           |
| Error       | `error.message`, `error.type`                                  |
| Event       | `event.action`, `event.category`, `event.outcome`              |

### Default to ECS Dotted Names

When schema discovery is not available and you must guess field names, always prefer ECS dotted notation over flat
names. Flat names like `source_ip` or `service` are common mistakes — most Elastic indices use the dotted ECS form.

| Prefer (ECS)     | Avoid (flat) |
| ---------------- | ------------ |
| `source.ip`      | `source_ip`  |
| `service.name`   | `service`    |
| `event.category` | `event`      |
| `event.outcome`  | `outcome`    |
| `host.name`      | `hostname`   |

### Legacy/Custom Fields

Some indices may use non-ECS field names:

- `status_code` instead of `http.response.status_code`
- `hostname` instead of `host.name`
- `timestamp` instead of `@timestamp`

**Recommendation:** Always discover actual field names with `GET /{index}/_mapping`, listing candidate indices first
with `GET /_cat/indices`, before generating queries (see the Operations table in `SKILL.md` for the `elastic` CLI
invocation). Never guess — index and field names vary across deployments.

---

## Query Optimization Tips

### 1. Filter Early

Put WHERE clauses as early as possible:

```esql
// Good - filter first
FROM logs-*
| WHERE @timestamp > NOW() - 1 hour
| WHERE level == "error"
| STATS count = COUNT(*) BY host.name

// Less efficient - filtering after processing
FROM logs-*
| STATS count = COUNT(*) BY host.name, level
| WHERE level == "error"
```

### 2. Use Appropriate Time Ranges

Smaller time ranges = faster queries:

```esql
// Specific range is faster
| WHERE @timestamp > NOW() - 1 hour

// Than scanning all data
// (no time filter)
```

### 3. Limit Fields

Only keep fields you need:

```esql
// Good - specific fields
| KEEP @timestamp, message, host.name

// Less efficient - all fields
// (no KEEP command)
```

### 4. Use LIMIT

Prevent returning excessive rows:

```esql
| LIMIT 100  // Always include for raw data queries
```

### 5. Check for Pre-Existing Computed Fields

Before computing derived values (distances, durations, rates, etc.) with `EVAL`, check the schema for fields that were
already calculated at ingest time. Many indices pre-compute common values — using them is simpler and avoids
recomputation.

```esql
// Prefer: use the pre-computed field
FROM kibana_sample_data_flights
| STATS avg_distance = AVG(DistanceKilometers)

// Avoid: recomputing what already exists
FROM kibana_sample_data_flights
| EVAL distance_km = ST_DISTANCE(OriginLocation, DestLocation) / 1000
| STATS avg_distance = AVG(distance_km)
```

---

## Key Patterns

### CATEGORIZE Must Be the First BY Key

`CATEGORIZE(field)` is only valid as the **first** grouping key in `STATS ... BY`. Listing any other grouping ahead of
it — a time bucket, a service name, a host — fails to parse. This bites most often when combining categorization with
time bucketing for a "patterns over time" question.

```esql
// WRONG — time bucket listed before CATEGORIZE
FROM logs-*
| STATS c = COUNT(*) BY bucket = BUCKET(@timestamp, 1 minute), category = CATEGORIZE(message)

// CORRECT — CATEGORIZE first, bucket second
FROM logs-*
| STATS c = COUNT(*) BY category = CATEGORIZE(message), bucket = BUCKET(@timestamp, 1 minute)
| SORT category, bucket
```

`CATEGORIZE` is also unsupported as an `INLINE STATS` grouping function.

### Per-Aggregation WHERE (8.16+)

Use `COUNT(*) WHERE condition` instead of CASE-based workarounds to compute conditional metrics in a single pass:

```esql
FROM logs-*
| STATS
    total = COUNT(*),
    errors = COUNT(*) WHERE level == "error",
    warnings = COUNT(*) WHERE level == "warning"
  BY service.name
| EVAL error_rate = ROUND(errors * 100.0 / total, 2)
```

### LOOKUP JOIN and ENRICH

`LOOKUP JOIN` (8.18+) is the preferred way to enrich query results from another index. On clusters **before 8.18**, fall
back to `ENRICH` — it provides similar enrichment capability but requires a pre-configured enrich policy.

**If no enrich policy exists**, suggest the user create one. Example setup:

```bash
# 1. Create the enrich policy
PUT /_enrich/policy/customers_policy
{
  "match": {
    "indices": "customers",
    "match_field": "customer_id",
    "enrich_fields": ["name", "region", "email"]
  }
}

# 2. Execute the policy (builds the enrich index)
POST /_enrich/policy/customers_policy/_execute
```

Then the query uses `ENRICH` instead of `LOOKUP JOIN`:

```esql
// 8.18+ — LOOKUP JOIN (preferred, no policy needed, easier to update)
FROM orders
| LOOKUP JOIN customers_lookup ON customer_id
| KEEP order_id, customer_id, name, region, total

// Pre-8.18 — ENRICH (requires policy setup above)
FROM orders
| ENRICH customers_policy ON customer_id WITH name, region
| KEEP order_id, customer_id, name, region, total
```

**Multi-field joins (9.2+):** Join on multiple fields when the lookup table has a composite key:

```esql
FROM application_logs
| LOOKUP JOIN service_registry ON service_name, environment
| KEEP service_name, environment, owner_team, response_time_ms
```

> Multi-field joins have no ENRICH equivalent — ENRICH only supports a single match field.

**Pre-join checklist:** Before writing any `LOOKUP JOIN`, verify these two things:

1. **Field name match:** Does the join key have the same name in both the source and lookup index? If not, add `RENAME`
   before the join. This is a common source of silent failures.
2. **Composite key:** Does the lookup table require multiple fields to uniquely identify a row? If so, list all key
   fields in the `ON` clause (9.2+).

**Field name mismatches:** When the join key has a different name in the source vs the lookup table, use `RENAME` before
the join:

```esql
FROM support_tickets
| RENAME product AS product_name
| LOOKUP JOIN knowledge_base ON product_name
| KEEP ticket_id, description, resolution
```

### Time Series (TS) Queries

When `GET /{index}/_settings/index.mode` reports `time_series`, use the `TS` source command instead of `FROM`. Critical
syntax rules:

**1. Use the data stream name, not the resolved backing index:**

```esql
// WRONG — resolved backing index
FROM .ds-metrics-tsds-2026.03.09-000001

// CORRECT — data stream name
TS metrics-tsds
```

Read the backing index's `data_stream` from `GET /_resolve/index/{name}` to find the data stream name. Do not derive it
from the backing index name.

**2. TBUCKET takes only a duration — not @timestamp:**

`TBUCKET` is not `DATE_TRUNC`. Do not pass `@timestamp`. Always assign a column alias so you can reference it in `SORT`:

```esql
// WRONG — DATE_TRUNC-style syntax
| STATS avg_cpu = AVG(cpu) BY bucket = TBUCKET(@timestamp, 5 minutes)

// WRONG — no alias makes SORT difficult
| STATS avg_cpu = AVG(cpu) BY TBUCKET(5 minutes)

// CORRECT — duration only with alias for SORT
| STATS avg_cpu = AVG(cpu) BY bucket = TBUCKET(5 minutes)
| SORT bucket
```

**3. Counter fields need RATE() wrapped in an outer aggregation:**

`RATE()` computes per-time-series rates. When grouping by non-time dimensions (e.g., `host`), wrap it in `SUM()`
(counters are additive). Bare `RATE() BY host` fails:

```esql
// WRONG — bare RATE with non-time grouping
TS metrics-tsds
| STATS request_rate = RATE(requests) BY host

// CORRECT — SUM wraps RATE for non-time groupings
TS metrics-tsds
| STATS request_rate = SUM(RATE(requests)) BY TBUCKET(1 hour), host
```

For **gauge** fields, use `AVG()` or `MAX()` as the outer function. Prefer the plain form — the inner `LAST_OVER_TIME`
is implicit and sufficient for most gauge queries. Use explicit `AVG_OVER_TIME` when you need the average of all samples
in the window (not just the last). Do not use `AVG_OVER_TIME` for histogram fields; see the histogram tip below:

```esql
// Preferred — plain aggregation (implicit LAST_OVER_TIME)
TS metrics-tsds
| STATS avg_cpu = AVG(cpu) BY TBUCKET(5 minutes), service.name

// Only use explicit *_OVER_TIME when you need specific window behavior
TS metrics-tsds
| STATS avg_cpu = AVG(AVG_OVER_TIME(cpu)) BY TBUCKET(5 minutes), service.name
```

See [Time Series Queries](time-series-queries.md) for the full inner/outer aggregation model.

**4. Histogram fields:** Check `field_type` with `METRICS_INFO` (`histogram`, `exponential_histogram`, or `tdigest` —
OTel is a common source; `metric_type` is `histogram` for all three). `exponential_histogram` and `tdigest` **merge by
default as inner, per-series aggregation** — use `SUM`/`AVG`/`COUNT`/`PERCENTILE`/…, not `*_OVER_TIME`. Plain
`histogram` is not usable without a cast. “Average over time” on a histogram means `AVG(field)`, not `AVG_OVER_TIME`:

```esql
// WRONG — *_OVER_TIME is the wrong shape for histogram metrics
TS metrics-* | STATS SUM(SUM_OVER_TIME(jvm.gc.duration)) BY TBUCKET(1 hour)

// CORRECT — exponential_histogram / tdigest: merge + standard aggregation (no cast)
TS metrics-tsds
| WHERE TRANGE(1 hour)
| STATS count = COUNT(jvm.gc.duration),
        avg = AVG(jvm.gc.duration),
        p99 = PERCENTILE(jvm.gc.duration, 99)
  BY jvm.gc.action, TBUCKET(5 minutes)
```

Always cast with `::exponential_histogram` when plain `histogram` is present (alone or mixed) or a type error requires
it; omit the cast when the targeted streams are unambiguously `exponential_histogram` or `tdigest`. Prefer `::tdigest`
only when the metric actually stores T-Digest data. Cast table:
[Histogram Metrics](time-series-queries.md#histogram-metrics).

**Version status:** `TS`, `TBUCKET`, the new `WITHOUT(...)` grouping function, the new `METRICS_INFO` / `TS_INFO`
discovery commands, and **all** time series aggregation functions are **GA since 9.4** — including the 9.2-introduced
set (`RATE`, `IRATE`, `INCREASE`, `DELTA`, `IDELTA`, all `*_OVER_TIME`, `PRESENT_OVER_TIME`, `ABSENT_OVER_TIME`) and the
9.3-introduced set (`DERIV`, `PERCENTILE_OVER_TIME`, `STDDEV_OVER_TIME`, `VARIANCE_OVER_TIME`). On clusters in 9.2-9.3
these features are tech preview. `TRANGE` remains in preview.

**Pre-9.2 limitation:** The `TS` command, `RATE()`, `TBUCKET()`, and `AVG_OVER_TIME()` all require Elasticsearch
**9.2+**. On older clusters, counter fields (`counter_long`, `counter_double`) cannot be aggregated meaningfully —
standard aggregation functions like `MAX()`, `SUM()`, and `AVG()` reject counter field types. There is no workaround.
When the cluster is pre-9.2 and the question involves counter rates or time-series-specific aggregations, explain that
the `TS` command and `RATE()` are required (9.2+) and the query cannot be expressed on the current cluster version.

For **gauge** fields in time-series indices on pre-9.2 clusters, `FROM` with standard aggregations (`AVG`, `MAX`, `MIN`)
still works — only counter fields are affected.

**Sliding window restriction (9.2-9.3):** When the user wants a per-time-series aggregation window different from the
`TBUCKET` interval (`RATE(field, 10m) BY TBUCKET(1m)`), the window must be a multiple of the bucket interval on preview
clusters. **9.4+** (GA) accepts arbitrary windows.

### INLINE STATS (9.2+)

`INLINE STATS` is available in **9.2+** only. It computes an aggregation and appends the result as a new column to every
row (like a SQL window function). Use cases that require comparing individual rows to group-level aggregates (e.g.,
"find values above the group average", "percentage of total") depend on `INLINE STATS` and **cannot be expressed in
ES|QL before 9.2**. There is no fallback.

When the cluster is pre-9.2 and the question requires per-row vs. aggregate comparison, explain that `INLINE STATS` is
needed and suggest the user either upgrade or perform the comparison client-side.

### Pipe Commands: URI_PARTS, USER_AGENT, REGISTERED_DOMAIN (preview 9.4)

These are **pipe commands** (like `DISSECT`/`GROK`), not scalar functions. They must appear on their own pipeline stage
with `target = expression` syntax. A target prefix is mandatory.

```esql
// WRONG — function-call syntax does not work
| EVAL parts = URI_PARTS(url.full)

// CORRECT — pipe command syntax with target prefix
| URI_PARTS parts = url.full
| KEEP parts.domain, parts.path, parts.scheme
```

When the user asks to "parse URLs", "extract domains", or "parse user agents", reach for these commands instead of
`DISSECT`/`GROK`:

| User Request              | Command             |
| ------------------------- | ------------------- |
| Parse/decompose a URL     | `URI_PARTS`         |
| Parse a user agent string | `USER_AGENT`        |
| Extract registered domain | `REGISTERED_DOMAIN` |

### Grouped Top-N with LIMIT BY (preview 9.4)

`LIMIT n BY field` keeps the top N rows per group after sorting. The number comes **before** `BY`.

```esql
// Top 3 error-producing hosts per service
FROM logs-*
| WHERE level == "error"
| STATS cnt = COUNT(*) BY service.name, host.name
| SORT cnt DESC
| LIMIT 3 BY service.name
```

This replaces the common `INLINE STATS` + rank-and-filter pattern for simple grouped top-N.

### Unique Combinations (Deduplicating Rows)

For "unique combinations, no duplicates", produce one row per combination of the columns that define a duplicate:

- **Serverless:** `| KEEP host.name, service.name | DEDUP` (preview). Stack 9.5 and earlier reject `DEDUP`.
- **Stack 9.4+:** `| LIMIT 1 BY host.name, service.name`; `SORT` first to choose which row each group keeps.
- **Any version:** `| STATS BY host.name, service.name` (add `COUNT(*)` to count each combination).

### Subqueries in FROM vs FORK

**Subqueries** (preview 9.4, GA 9.5) combine results from **different** data sources (UNION ALL semantics). **FORK**
runs **different analyses** on the **same** data source.

| Scenario                              | Use        |
| ------------------------------------- | ---------- |
| Combine errors from two index sets    | Subqueries |
| Run multiple aggregations on one set  | FORK       |
| Compare time windows of the same data | FORK       |
| Union independent pipelines           | Subqueries |

```esql
// Subqueries — different sources
FROM
  (FROM web_logs | WHERE status >= 500 | KEEP @timestamp, message, service.name),
  (FROM app_logs | WHERE level == "error" | KEEP @timestamp, message, service.name)
| SORT @timestamp DESC

// FORK — same source, different analyses
FROM logs-*
| FORK
    ( WHERE level == "error" | STATS errors = COUNT(*) BY service.name )
    ( WHERE level == "warning" | STATS warnings = COUNT(*) BY service.name )
```

### External IPs — CIDR_MATCH with RFC 1918

When the user asks about "external IPs" or "public IPs", exclude private (RFC 1918) ranges with `NOT CIDR_MATCH`:

```esql
FROM security-events
| WHERE event.outcome == "failure"
  AND NOT CIDR_MATCH(source.ip, "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")
```

When the IP field is mapped as `keyword`, convert it first: `EVAL ip = TO_IP(client_ip)`, then use `ip` in `CIDR_MATCH`,
comparisons, `IN (FROM …)`, and `LOOKUP JOIN` (the last two reject an expression on the left).

---

## Common Query Templates

### Error Investigation

```esql
FROM logs-*
| WHERE @timestamp > NOW() - 1 hour
| WHERE level == "error"
| KEEP @timestamp, message, host.name, service.name, error.message
| SORT @timestamp DESC
| LIMIT 100
```

### Service Health Overview

```esql
FROM metrics-*
| WHERE @timestamp > NOW() - 15 minutes
| STATS
    avg_cpu = AVG(system.cpu.percent),
    avg_mem = AVG(system.memory.used.pct),
    host_count = COUNT_DISTINCT(host.name)
  BY service.name
| SORT avg_cpu DESC
```

### API Performance Analysis

```esql
FROM apm-*
| WHERE @timestamp > NOW() - 1 hour
| STATS
    count = COUNT(*),
    avg_duration = AVG(transaction.duration.us),
    p95_duration = PERCENTILE(transaction.duration.us, 95),
    error_count = COUNT(CASE(transaction.result != "success", 1, null))
  BY transaction.name
| EVAL error_rate = ROUND(error_count * 100.0 / count, 2)
| SORT count DESC
| LIMIT 20
```

### Traffic Analysis

```esql
FROM web-logs
| WHERE @timestamp > NOW() - 24 hours
| STATS
    requests = COUNT(*),
    unique_ips = COUNT_DISTINCT(client.ip)
  BY hour = DATE_TRUNC(1 hour, @timestamp)
| SORT hour DESC
```

### Security Event Review

```esql
FROM security-*
| WHERE @timestamp > NOW() - 24 hours
| WHERE event.category == "authentication"
| WHERE event.outcome == "failure"
| STATS
    failures = COUNT(*)
  BY user.name, source.ip
| WHERE failures > 5
| SORT failures DESC
```

---

## Handling Ambiguity

When the user request is ambiguous:

### Missing Index

If no index specified, make a reasonable assumption:

- "show errors" → `FROM logs-*`
- "show CPU usage" → `FROM metrics-*`
- "show requests" → `FROM web-logs` or `FROM access-*`

Or output the query with a placeholder and note:

```esql
FROM <index-pattern>  // Specify your index
| WHERE ...
```

### Missing Time Range

Add a sensible default:

```esql
| WHERE @timestamp > NOW() - 24 hours  // Default: last 24 hours
```

### Unclear Aggregation

When "show X" could mean list or count:

- If followed by "by Y" → aggregation
- If asking for specifics → raw data
- If asking "how many" → count
- Default to raw data with limit

### Unknown Field Names

If field names are uncertain:

1. Use common ECS names as first guess
2. Suggest running schema discovery
3. Note the assumption in output

---

## Output Formatting Suggestions

When presenting generated queries:

```text
=== ES|QL Query ===

FROM logs-*
| WHERE @timestamp > NOW() - 1 hour
| WHERE level == "error"
| STATS count = COUNT(*) BY host.name
| SORT count DESC
| LIMIT 10

=== Explanation ===
- Queries all log indices
- Filters to the last hour
- Counts errors per host
- Returns top 10 hosts by error count

=== To Execute ===
POST /_query  (see the Operations table in SKILL.md for the elastic CLI invocation)
```

---

## 9.5 Additions

Use these on 9.5+ Stack and on Serverless (all preview unless noted). Full syntax is in
[esql-reference.md](esql-reference.md).

- **Allow/deny lists:** `WHERE source.ip NOT IN (FROM allowed_ips | KEEP ip)` — the subquery returns one column. Use
  `LOOKUP JOIN` instead when you also need columns from the reference index.
- **GeoIP at query time:** `| IP_LOCATION geo = source.ip` is a pipe command; calling it as a function inside `EVAL`
  fails. Default columns are `geo.country_name`, `geo.city_name`, `geo.location`, and the ISO/region fields; use
  `WITH {"database_file": "GeoLite2-ASN.mmdb"}` for ASN/organization.
- **Data Federation** (external sources such as S3) is experimental and not for production use, and available on ECH and
  self-managed only (not Serverless) — do not generate it unless the user asks, and then warn about that status. Never
  create data sources or datasets to answer a question about data already in an index. When the user names a dataset,
  query it with `FROM <dataset>`; it is not listed by `GET /_cat/indices` or `GET /{index}/_mapping`, so read its
  columns with `FROM <dataset> | LIMIT 0`. Use it only as the source of a `LOOKUP JOIN`, never as the lookup target, and
  never with `TS`. See [Data Federation](esql-reference.md#data-federation-95-experimental--not-for-production-use).
