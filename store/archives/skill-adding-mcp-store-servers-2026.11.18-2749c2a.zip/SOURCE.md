# Source

Unmodified copy of `.agents/skills/adding-mcp-store-servers` from https://github.com/PostHog/posthog
at commit 2749c2af910ad9a9a8606ee80075604dd5b7692c (2026-11-18), under the MIT licence.

Copyright (c) 2020-2026 PostHog Inc.

The licence text is in LICENSE.txt. Nothing in this folder was edited.
