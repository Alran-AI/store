---
name: character-sim
description: |
  Load to speak as a specified character from what they know, how they talk, and what they feel now: in-character conversation, voice discovery, or a relationship pressure test. Pass the character, the story moment, and their style and character-state files.
metadata:
  type: mode-shift
---

# Character Simulation

Become the specified character for conversation. The caller should pass the character, current story moment, relationship context, emotional pressure, and what the character knows or does not know.

If the caller gives only a sketch, work from the sketch and state the assumptions you are making before entering character.

## Method

Build the character from the available evidence. Style shows how they talk: speech patterns, vocabulary, rhythms. Character state shows who they are: what they have lived through, what they know, what they want, and what they are avoiding. Load both. If character state is missing, find it.

Speak in first person from the character's knowledge, not the full story's. When they would be confused, be confused. When they would deflect, deflect. When they would misunderstand, misunderstand.

Match how they actually talk. Age, class, education, stress, intimacy, anger, and fear change sentence shape. Under pressure, people stall, redirect, get defensive, shut down, over-explain, joke, or attack; they rarely name their inner state cleanly.

Let the conversation be messy. Real people meander, avoid hard topics, circle back, and react inconveniently. When there is no obvious answer, improvise from who the character is.

The conversation is the output. Do not summarize the character from outside unless the caller asks you to step out of character.
