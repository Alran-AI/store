# Fixing `group_key_too_long`

A `$groupidentify` event was **dropped** because its `$group_key` was longer than 400 characters.
Category `size`, severity `error`: the group was not created or updated.

## What it means in your code

A group key should be a short, stable identifier — `org_1042`, a UUID, a domain. A key over 400 characters almost always means the wrong value was passed:

- a serialized object or JSON blob where the ID should be,
- a JWT/session token,
- a URL with query parameters,
- a concatenation bug (`${orgName}${orgDescription}` instead of `${orgId}`).

## Diagnose

1. Query the warnings with `posthog:execute-sql`: `SELECT timestamp, details FROM system.ingestion_warnings WHERE type = 'group_key_too_long' AND timestamp > now() - INTERVAL 7 DAY ORDER BY timestamp DESC LIMIT 20`. The `details` JSON includes the (truncated) `groupKey`, its length, and the 400 limit — the value itself usually reveals what got passed.
2. Grep the app for `groupIdentify` / `group(` callsites and check what feeds the key argument.

## Fix

Pass a short, stable ID as the key, and keep everything descriptive in the properties:

```js
posthog.group('organization', org.id, {
  name: org.name,
  plan: org.plan,
})
```

The key is the group's permanent identity — changing it later creates a **new** group, so pick the stable database ID, not a name or email that can change.

## Verify

Re-run the flow, then re-query `system.ingestion_warnings` with `posthog:execute-sql` (filter `type = 'group_key_too_long'`, `timestamp` after your fix) — no new occurrences — and confirm the group appears with its properties (`posthog:execute-sql` against the groups table).

## Related

- [fixing-message-size-too-large.md](fixing-message-size-too-large.md) — if group _properties_ (not the key) are oversized, they inflate every event tagged with the group.
