---
name: frontier-digest-detail
description: Detail reference for frontier-digest — collection bash per source, synthesis prompt, video-harvest tier detail, output/save/signal formats. Load when executing a specific step.
load: on-demand
---

# frontier-digest — Detail Reference

> Load when executing a specific step. SKILL.md contains triggers, engine priority, operator intake rules, mode selection, chaining logic, guards, and Done When.

---

## §Collection-Bash

> **Execution form — canonical (revised 2026-08-10, operator decision ⓑ).** The default runtime path
> is **WebFetch (+WebSearch) against the endpoints below** — not `curl`. Measured: **13 consecutive
> unattended runs** executed via WebFetch while this section documented only the curl form (the digest
> reported the mismatch on every run — spec debt N=13). `curl` requires an allowlist entry that a
> default install does not carry; the bash blocks below are kept as the **endpoint/parameter spec**
> (query shapes, filters, item caps, refresh rules — all still authoritative), and a run applies them
> through WebFetch on the same URLs. If an environment *does* allow the curl form, it is equivalent —
> the transport is not the contract, the endpoints and criteria are.
>
> 🟥 **A refused or empty response is a result, never a reason to change who you say you are
> (2026-10-31, AQ-20261030-4 — the slow leg already had this rule; the daily legs did not).** The
> 10-30 unattended run got 0 B from GeekNews, retried with a User-Agent it made up, and succeeded —
> and which UA it sent was not logged, so whether that was a browser disguise is `UNMEASURED`. The
> rule for every daily leg: a block, a 403/429, a captcha page or 0 B is written into the digest as
> `UNREACHABLE(<code or reason>)`, and a page that came back but parsed to nothing as `PARSE-ZERO` —
> both are `not found ≠ 0`, never «0 items». **Do not retry with a different client identity**
> (another browser's User-Agent, a spoofed referrer, a headless-browser fetch to get past a bot
> check). An honest identifying UA (`forge-harness-digest/<version>`) on the first request is fine;
> swapping it after a refusal is not. If a refused source matters that day, it goes to Step 0.5 as an
> operator hand-in. When the curl form is used, the progress line names the UA the leg sent.
>
> **arXiv HTTP 429 — fallback is a TRANSPORT change, never a channel change (revised 2026-09-04).**
> The export API rate-limits this runner (N=11 consecutive by 08-10; 3 consecutive days 09-02·03·04
> = past the `N≥3` mechanization bar). The 08-10 prescription («fall back to per-item `abs/{id}`
> reads») was unrunnable in practice — a 429 on the *query* leaves you with no IDs to read — so runs
> fell back to **WebSearch**, and the 09-04 run measured what that does: 5/5 papers it returned were
> REPEATs. Search sorts by *canonicity*, the export API by *submission date* — a search fallback is
> a **recall channel, not a discovery channel**, and swapping it in silently converts «unrun» into
> «nothing new» (`not found ≠ 0`).
>
> 🟢 **TRANSPORT ORDER INVERTED 2026-09-12 (operator decision) — the listing is now PRIMARY.**
> Condition stated by the operator was *«if the errors keep coming»*, and they did, measurably:
> `429` appears in the digest record on **09-09 · 09-10 · 09-11 · 09-12 — four consecutive days**,
> past the `N≥3` bar twice over. Paying two failed calls plus a backoff every single day to reach
> items that the listing reaches anyway is not a fallback, it is a toll. New order:
> 1. **PRIMARY — WebFetch the date-sorted HTML listing** `https://arxiv.org/list/cs.SE/recent`
>    (and `https://arxiv.org/list/cs.AI/recent` if the first is empty of agent/harness items), keep
>    items whose title/abstract match the three query phrases, cap 6. **Same sort axis as the API**
>    (submission date) — that property is *why* this one is promotable and WebSearch is not.
> 2. **FALLBACK — the export API query** (back off ≥30s between attempts). Kept on the ladder on
>    purpose: if arXiv redesigns the listing markup, the channel must not disappear with it.
> 3. only if both fail → HN-only, and the progress line says `arxiv FAILED (<which transports, why>)`,
>    never `0 items`.
>
> 🟥 **What this costs, stated rather than discovered later.** The listing path has the **weaker
> instrument** — its ID↔title pairing is the defect documented immediately below, and promoting it
> moves that defect from the fallback onto the **main** path. Therefore the two rules below are no
> longer conditional-on-being-in-fallback: **per-item `abs/{id}` re-resolution is a PRIMARY-path
> requirement**, one fetch per shipped ID, and a title mismatch drops the item. That is a real
> per-run cost increase (≈N extra fetches for N shipped items) and it is the price of the promotion,
> not an oversight. The old order paid 2 failed calls + a backoff instead; this pays N verified reads.
> 🟥 The progress line must now name **which transport produced the items** (`arxiv via listing` /
> `arxiv via export-api`) — otherwise a reader cannot tell which instrument's limits apply to the run.
> 🟥 WebSearch is **not** on this ladder. If a run used it anyway, the arxiv leg is reported as
> `RECALL-ONLY (WebSearch)` and its items are excluded from the NEW/REPEAT count.
>
> 🟥 **On the listing path, do NOT pair ID and title by position — pair them inside one block
> (measured 2026-09-12, this runner, and it is the phantom class this skill already has on record).**
> The listing yielded **51 IDs and 50 titles**, so two parallel extractions drift partway down and
> every pair after the drift point is wrong *while looking well-formed*. Concretely measured that run:
> `2609.10550` was attached to *"When Passing Tests Hides Vulnerabilities"* by the positional parse,
> but its own `abs` page is *"Optimizing AI Inference Across the Deployment Stack"* (2026-07-01);
> `2609.11060` and `2609.11008` mispaired the same way. 3 items dropped, 7 verified, **0 shipped
> unverified** — it was caught only because every shipped ID was re-resolved.
> **Two rules, and the second is the floor:**
> ① read each entry as **one unit** (the ID and the title that sit in the *same* list item), never as
>   two ordered lists zipped together. A count mismatch between the lists is not a warning to
>   reconcile — it is proof the zip is already wrong.
> ② until ① is demonstrably what happened, **per-item `abs/{id}` re-resolution is MANDATORY on this
>   path**, not optional — one fetch per shipped ID, confirming the title. Any ID whose `abs` title
>   disagrees is **dropped**, never shipped with a note.
> ⚠️ There is no hook here and none is possible: the parse happens inside the session that read the
> page, so this is salience over a manual floor. The floor that actually held on 2026-09-12 was ② —
> keep it even after ① looks solved (`[[feedback_anchor_can_be_decorative]]`).

### HackerNews (Algolia API)

```bash
for KW in "AI agent" "LLM harness" "Claude" "multi-agent" "context engineering"; do
  curl -s --max-time 8 \
    "https://hn.algolia.com/api/v1/search_by_date?query=$(echo $KW | tr ' ' '+')&tags=story&hitsPerPage=5&numericFilters=points>30"
done
```

Collection criteria: score > 30, keyword-relevant items only. Max 15 items.

> **`/search_by_date`, not `/search` (revised 2026-09-04; prescribed 2026-09-01, unapplied for 3 runs).**
> `/search` ranks by relevance and returned items dated 2025-11→2026-06 on 2026-09-01 — a *relevant-but-stale*
> leg, the mirror image of the 2026-07-26 arXiv *fresh-but-off-axis* failure, and the HN leg carried neither
> refresh trigger. `/search_by_date` sorts by submission time; the points floor rises 10→30 to keep the
> date-sorted window from filling with noise (measured 2026-09-01: `points>30` gave a clean 08-27→08-31
> window). Same rule as the arXiv leg: a leg that silently falls back to a relevance/recall channel converts
> «unrun» into «nothing new».

### arxiv

```bash
# Category-scoped since 2026-07-26. Unscoped `all:` full-text matching drifted off-axis: the 07-26 run
# returned 6/6 fresh-but-irrelevant papers (diffusion world models, embodied QA, medical-education
# gamification, RF fingerprinting). Freshness was fine; relevance was not — so the staleness rule below
# could not catch it.
for Q in "LLM agent" "agent harness" "context engineering"; do
  curl -s --max-time 8 \
    "https://export.arxiv.org/api/query?search_query=cat:cs.SE+AND+all:%22${Q// /+}%22&max_results=2&sortBy=submittedDate&sortOrder=descending"
done
```

Max 6 items.

**Refresh rule — two independent triggers (both required, neither sufficient alone):**
- **Staleness**: a query's newest hit is >6 months old, two runs in a row → replace the query.
- **Relevance** (added 2026-07-26): ≥4 of 6 returned items are off-axis (not about LLM agents /
  harnesses / agent evaluation / context engineering) → the query is drifting even though it is fresh.
  Staleness and relevance fail independently; a fresh-but-irrelevant query passes the staleness check.

**Before adopting a replacement query, calibrate it on a known pair** (`measurement-integrity-checklist.md
§Instrument-Calibration`): pick one paper FH would clearly want and one it clearly would not, and confirm
the new query returns the first and excludes the second. A query that cannot separate a pair you already
know the answer to is not filtering — it is generating.

> Calibration on record (2026-07-26, for the `cat:cs.SE` scoping above):
> **positive** = *"Understanding Agent-Reactive Bugs at the Model-Harness Boundary"* → `cs.SE`, returned.
> **negative** = *"MedGame: Storytelling Gamification … Medical Education"* → `cs.CL`/`cs.HC`, excluded.
> `cat:cs.MA` was tested against the same pair and **rejected** — it kept roughly half the off-axis items.

### TLDR AI (RSS)

```bash
curl -s --max-time 8 "https://tldr.tech/api/rss/ai"
```

Parse `<item>` → title + link. Max 5 items.

### The Batch — deeplearning.ai (HTML scraping)

```bash
curl -s --max-time 10 -L "https://www.deeplearning.ai/the-batch"
```

⚠️ **No trailing slash.** `…/the-batch/` returns **HTTP 308** redirecting to the slash-less path (verified
2026-07-26); the 07-26 automated run read that 308 as a dead endpoint and skipped the leg. The slash-less
URL returns 200 directly, so the leg no longer depends on redirect-following at all — which matters
because the fetch path is not always `curl -L` (a WebFetch-based run does not follow redirects the same
way). Second collection endpoint to churn, after GeekNews `/rss/news` (2026-06-20).

🟥 **Pattern churned again (2026-09-11).** The page no longer embeds `"title":"..."`/`"slug":"issue-N"` JSON —
HTTP 200, ~186 KB, **0 matches**, and the `/the-batch/issue-N` anchors carry no text. Third endpoint churn
(GeekNews `/rss/news` 2026-06-20 · trailing-slash 308 2026-07-26 · this). Current shape, verified live:

```bash
curl -s --max-time 15 -L "https://www.deeplearning.ai/the-batch" \
  | /usr/bin/grep -oE '<a [^>]*aria-label="[^"]+"[^>]*href="/the-batch/issue-[0-9]+"' \
  | sed -E 's/.*aria-label="([^"]+)".*href="(\/the-batch\/issue-[0-9]+)".*/\1\t\2/' | head -5
```

`aria-label` = title · `href` = `/the-batch/issue-NNN` → URL `https://www.deeplearning.ai{href}`. Max 5 items.
⚠️ **Count with `grep -o … | wc -l`, never `grep -c`.** The page is minified, so every anchor sits on
one line and `-c` (which counts LINES) reports **1** where there are 5. Measured 2026-09-16 while
re-verifying this very block — a leg that trusts `-c` silently caps the Batch count at one.
🟥 **0 matches on a 200 is INSTRUMENT MISMATCH, never «Batch 0 items»** — report it as
`Batch: UNMEASURED (pattern mismatch — HTTP 200, N bytes, 0 anchors)` and leave the leg out of the
counts ([[feedback_not_found_is_not_zero_family]]). Calibrate: known-positive = the live page yields ≥1
row today; known-negative = an empty body yields the UNMEASURED line, not `0`.

### GeekNews — news.hada.io (RSS)

```bash
curl -sL --max-time 8 "https://news.hada.io/rss/news"
```

🟥 **`-L` is load-bearing (2026-11-04).** `/rss/news` now answers `302 → feeds.feedburner.com/geeknews-feed`;
without `-L` the body is **0 bytes**, with `-L` it was 28,635 B / 20 `<entry>` (same run). A 0-byte body is
`UNMEASURED (empty body)`, never `0 items`.

Korean dev-news aggregator (HN-equivalent), AI-heavy. **The `/rss/news` path serves an Atom feed** (`<feed>`/`<entry>`, NOT RSS `<item>` — verified 2026-06-20: 50 `<entry>` elements, 0 `<item>`; 2026-11-04 after the redirect: 20 `<entry>`, 0 `<item>`). Parse `<entry>` → `<title>` + `<link href>`; keep AI/agent/LLM/harness-relevant items only. `/rss/news` is a *general* dev-news feed, so if 0 AI-relevant items remain after filtering, **drop GeekNews from this run's progress line rather than padding to 5**. Endpoint verified HTTP 200 (2026-06-20); `/rss/new` and `/rss/topics` 404 — use `/rss/news`. Max 5 items.

### Launch channels and vendor feeds (added 2026-10-17; ids match SKILL.md Step 1)

Why: the digest missed «Aside» (YC-backed agent browser) because HN/arXiv/GitHub-style legs do not carry
launch announcements. Official pages/feeds only, no scraping that bypasses a site's terms; endpoints below
were live-checked once on 2026-10-17 (HTTP status · entries counted by `<entry`/`<item`/`objectID`).
🟥 **Unreadable-leg rule**: a non-200, a challenge/consent page, a JS-only shell, or an empty parse is
`UNMEASURED (<reason>)` in the progress line — never `0 items`.

- **Launch YC (`launch-yc`)**: `https://www.ycombinator.com/launches` — newest launches; keep AI/agent/dev-tool ones. Cite the launch URL. ⚠️ 2026-10-17: HTTP 200 but a 16 KB JS-rendered shell, 0 entries via curl → read it with WebFetch (rendered) or report `UNMEASURED (js shell)`.
- **Product Hunt (`product-hunt`)**: official Atom feed `https://www.producthunt.com/feed` (2026-10-17: 200, 50 `<entry>`). ⚠️ the `?category=` parameter returned a byte-near-identical feed, so it is not shown to filter — filter by keyword yourself. Parse `<entry>` title + link.
- **Show HN (`show-hn`)**: `'https://hn.algolia.com/api/v1/search_by_date?tags=show_hn&query=<KW>&hitsPerPage=8&numericFilters=points%3E10'` (quoted; 2026-10-17: 200, 8 hits for «agent») for the same keywords as the HN leg. Cite the HN item id.
- **GeekNews (`geeknews`)**: unchanged section above (still wired).
- **Vendor changelogs/blogs (`vendor-changelogs`)**: Feeds: OpenAI `https://openai.com/news/rss.xml` (200, RSS) · Google DeepMind `https://deepmind.google/blog/rss.xml` (200, RSS). HTML pages, no feed found (200, parse with WebFetch): Anthropic `https://www.anthropic.com/news` · Gemini API changelog `https://ai.google.dev/gemini-api/docs/changelog` (⚠️ 2026-11-04: `301 → https://aistudio.google.com/docs/changelog`, a JS shell to curl — read it with WebFetch or report `UNMEASURED (js shell)`) · Meta AI `https://ai.meta.com/blog/` · Cursor `https://cursor.com/changelog`. Keep entries newer than the previous digest; cite the entry URL.

Recall regression: `scripts/test_frontier_digest_recall.sh` against `scripts/fixtures/frontier_digest_recall.tsv` (structural only: each known item must have a channel in the Step 1 list; the channel assignments are expectations, not announcement evidence — do not cite the lane as measured recall).

Report progress: `📡 HN 15 items · arxiv 5 items · TLDR 5 items · Batch 5 items · GeekNews 5 items · LaunchYC n · PH n · ShowHN n · Vendors n collected` (a leg that could not be read is `UNMEASURED`, never `0`)

---

## §Video-Harvest — Tier Detail (Step 0.5)

Resolve a *video-harvest* capability via the Sidecar Engine Resolution Protocol (`multi_model_sidecar_strategy.md`) — probe by **capability, not engine name**. A CLI that is a valid sidecar for other tasks is not automatically a video-harvest engine.

- **Tier 1 — a natively multimodal CLI that ingests the URL directly**: probe for one, then route to it (pre-EOL example invocation: `gemini --skip-trust -p "{URL}"` → timestamped summary). ⚠️ **the direct `gemini` CLI is being sunset (vendor EOL 2026-06-18)** — after that probe `agy` (the Antigravity router-shell successor, same class) or the Gemini API; see `multi_model_sidecar_strategy.md §Binary names churn`. A coding-agent CLI with **no native video/transcript access** (e.g. `codex`) cannot do this — it burns tokens, recovers only metadata (title), then asks for a pasted transcript; do not route video to it. Agentic router-shells (`agy`) get approval-mode first.
- **Tier 2** = router-shell / Gemini API (see the protocol).
- **Tier 3 — conditional fallback (not guaranteed)**: `yt-dlp --write-auto-subs --skip-download` then summarize the transcript — fine for talk-style content. **Probe the environment first**: `yt-dlp --version && python3 -c "import curl_cffi" && command -v ffmpeg` — Tier 3 needs all three (`yt-dlp`, `curl_cffi` impersonation target, `ffmpeg`), and the timedtext endpoint may return HTTP 429; if the probe fails, fall through rather than assuming it works.
- Unresolvable (cloud, no sidecar; or all tiers blocked) → operator summary remains the path, as today.

---

## §Synthesis-Prompt

> Angle-rule provenance: added 2026-07-24 (fh_signal 07-24 #3 — Bun-Rust methodology-angle silent
> drop; scope limited to collection-filtered items per Axis-2 challenger cost finding). Provenance
> lives here, outside the fenced prompt — the synthesis model gets only the bare rule.

### With Anthropic API

```
You are an AI harness engineering expert.
Analyze the collected external data below and extract insights
directly relevant to forge-harness (FH) operations and improvement.

FH Context:
- FH = AI collaboration meta-harness (skill · plugin · agent system)
- Core skills: steel-quench, harness-doctor, sim-conductor,
               agent-composer, apex-review
- Areas of interest: multi-agent orchestration, context engineering,
                     self-check gate, frontier cross-diagnosis

[Insert collected data]

Angle rule: an item you reject on its primary angle (e.g. substrate/model/runtime news),
if it passed collection filtering, gets ONE explicit second look before discarding: does it
carry a separate methodology/harness angle (orchestration pattern, workflow scale,
operational practice)? If yes, judge that angle on its own merits; if no, discard silently —
no output line about the discard, and never force an angle that isn't there.

Output format:
## This Week's Frontier Highlights (max 3)
**[Title]** `<source-id>` — FH connection point in one sentence
<!-- source-id is MANDATORY (SKILL.md §Citation anchors): arXiv:NNNN.NNNNN | HN:<item-id> | <url>.
     No id → drop the item and count the drop. A recognized title is not a citation. -->


## FH Immediate Application Candidates
2-3 specific ideas

## Warning Signals
Noise or excessive complexity alerts (if any)

Length: within 400 characters. Start directly with content, no preamble.
```

### WebSearch Mode (no API key)

Search directly with WebSearch tool, then synthesize in context:

```
Search: "AI agent harness 2025 site:news.ycombinator.com"
Search: "multi-agent LLM orchestration latest"
```

---

## §Output-Formats

### Step 3 — Conversation output

```markdown
## 🔭 FH Frontier Digest — YYYY-MM-DD

🔑 [Engine used: Claude Sonnet / WebSearch]

## This Week's Frontier Highlights
...

## FH Immediate Application Candidates
...

## Warning Signals
...

---
📊 Collected: HN N items · arxiv N items · TLDR N items · Batch N items | [View sources →]
```

### --save path priority

```python
# Filename is FIXED — the cadence detector in CLAUDE.md globs
# tracks/_meta/frontier_digest_*.md, and scripts/frontier_digest_daily.sh writes this
# exact name. Underscores in the date; `date +%Y_%m_%d`, not %Y-%m-%d.
today = datetime.date.today().strftime("%Y_%m_%d")
name  = f"frontier_digest_{today}.md"

# Directory priority (the filename above does not change between them)
# 1. resolved FH install root  -> {FH}/tracks/_meta/
# 2. ~/.claude/forge-harness/tracks/_meta/
# 3. cwd                       -> ./tracks/_meta/
path = os.path.join(fh_root, "tracks", "_meta", name)
```

After saving: `✅ Saved: {path}`

> **Do not "simplify" this back to `digests/frontier_{today}.md`.** That was the documented path until
> 2026-08-11 and it produced **0** files (measured: `digests/` absent, `~/.claude/frontier-digest`
> absent, `frontier_2*.md` = 0 matches repo-wide) while 53 real digests sat in `tracks/_meta/` written
> by the daily runner. A digest saved outside this glob never satisfies the 7-day cadence check.

### Step 4 [3] — fh_signal file format

```markdown
---
date: YYYY-MM-DD
source: frontier-digest
engine: [Claude Sonnet / WebSearch]
---

# FH Improvement Signal — YYYY-MM-DD

## Sources
HN N items + arxiv N items collected

## Immediate Application Candidates
[Copy Step 2 "FH Immediate Application Candidates" items here]

## Processing Status
- [ ] Pending review
```

### Environment setup guide (first run, no API key)

```
🔑 No API key detected — running in WebSearch mode.

For more precise synthesis:
  Anthropic: export ANTHROPIC_API_KEY=sk-ant-xxx

To save key permanently (~/.cc_secrets pattern):
  echo 'export ANTHROPIC_API_KEY=sk-ant-xxx' > ~/.cc_secrets
  chmod 600 ~/.cc_secrets
```
