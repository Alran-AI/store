---
name: scenario-brand-kit
description: "Use when building a visual identity or brand kit with Scenario: a logo, wordmark, or icon as editable SVG, a color palette and typography spec, logo variants (mono, reversed, favicon), and brand applications like social templates, avatars, banners, or merchandise mockups. Also for a rebrand or refreshing an existing mark. Keywords: brandkit, brand kit, visual identity, logo, monogram, wordmark, SVG, vectorize, color palette, typography, brand guidelines, brand board, launch kit."
license: MIT
---

# Scenario Brand Kit

## Overview

An identity is decided, then rendered. Palette and typography are choices written into a spec before
any run; the logo is generated once as a real vector and reused everywhere; every application
references the approved mark instead of re-imagining it. Connection and the core loop: see the
`scenario` skill. Finding the direction when nothing is decided: `scenario-inspiration`. Image runs
and reference wiring: `scenario-image`. Exact taglines and CTAs on applications:
`scenario-text-overlay`. Per-placement sizes: `scenario-formats`. Gating contract:
`scenario-asset-analysis`. If a sibling skill named here is missing from your available skills, load
it with `skill_get` (Scenario MCP) or ask the user to install it
(https://github.com/scenario-labs/skills#install); unattended, proceed from tool schemas and flag
the gap.

## Quick reference

| Need         | Route                                                                                                                                                                                                                                                                                                                                                                                                          |
| ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| The spec     | Written first, by you with the user, before any generation: contents under The spec sheet                                                                                                                                                                                                                                                                                                                      |
| Logo, native | `recommend` `capability="txt2img"`, the prompt demanding a real editable SVG and not a raster: that clause, not the capability, is what surfaces the vector generator; skip a style member ranked first (it refuses a run without style inputs, see Icon strip) for the plain SVG sibling, found by `search` on the same name                                                                                  |
| Logo, traced | An existing raster mark: `recommend` `capability="img2img"`, the prompt saying trace to editable SVG, do not regenerate                                                                                                                                                                                                                                                                                        |
| Gate         | `asset_analyze` the mark with the spec via `text_inputs`; a drifted wordmark is re-run, never patched                                                                                                                                                                                                                                                                                                          |
| Variants     | `asset_get` the mark, save its `url` (`curl -L`) for the stored SVG, recolor locally, `upload_asset` each variant                                                                                                                                                                                                                                                                                              |
| Applications | `recommend` with `capability="img2img"`, approved mark as reference, spec hex values in the prompt, one placement per run                                                                                                                                                                                                                                                                                      |
| Icon strip   | The vector generator's style members (`search`, `filters={"tags": ["style-consistency", "svg"]}`; its plain SVG members expose no image field): raster renders of the mark (`asset_download` with `format` `png` returns a raster of the stored SVG) as `styleReferenceImages` on the first icon, then that job's `style_id` (`job_get`, `verbose=true`, output metadata) as `styleId` on the rest, never both |
| The board    | `model_scenario-compose-image` (first-party compositor, id fixed): mark, swatches, specimen, applications as positioned layers, labels via `scenario-text-overlay`                                                                                                                                                                                                                                             |
| File the kit | `collection_create` before the first run, `collection_add_assets` each keeper as it lands, `asset_update` for each one's role and rule                                                                                                                                                                                                                                                                         |

## The spec sheet

One short document anchors every run and every gate: four to six hex values, each with a role
(primary, ink, paper, accent), the accent recurring on every asset because a second accent reads as
none; two type families with weights and their jobs (display, body); one voice line, short and
specific rather than a slogan; the logo's clear space and minimum size; three "never" rules (never
stretch, never recolor outside the palette, never set the wordmark in another face). Prompts name
hex values from it verbatim, and every gate hands its full text to `asset_analyze` through
`text_inputs` (a paraphrase drops exact spelling and hex roles). Type comes from families the
destination can load (widely available or licensed): a generated "font" is a picture of one, so real
text is set by `scenario-text-overlay` in the spec's family. The wordmark is the exception: it is
drawn once into the mark, gated letter by letter, and reused as artwork from then on.

## Worked example: an identity for a new game studio

1. Spec first. Name the category, the audience, the promise and the core metaphor before anything is
   written down, since step 2's mark comes out of that metaphor. The brief names a mood;
   `scenario-inspiration` turns it into a chosen direction when it names nothing. Write palette,
   type, and rules down before any generation and confirm with the user (unattended: take the
   brief's constraints, decide the rest, mark it provisional). Create this run's collection before
   the first generation (`collection_create`, catalog write lane, `name` only), then
   `collection_add_assets` each keeper as it lands; its returned `itemCount` is the receipt.
2. Mark: `recommend` with `capability="txt2img"` and a prompt demanding a real editable SVG and not
   a raster; `model_schema_get` the pick. Prompt one idea about what the studio makes, reduced until
   it still reads in one color at favicon size: flat closed geometry, few colors, the spec's hex
   values, the studio name for the wordmark. Say what to avoid or the model reaches for its defaults
   (gradient mesh, sparkles, an unmotivated bolt, a globe). A pick that rejects a schema-conformant
   call is spent: take the next option rather than debugging it, since a schema can mark a field
   optional that the model requires. Three candidates, each on a different construction method and
   combining no more than two of them, so the set spans an axis rather than reseeding one idea:
   monogram fused with the metaphor, the product's verb as a symbol, two ideas reduced to one,
   negative space carrying a second reading, geometry on a stated grid. Pass `priority="cost"` on
   this round, since two of the three are discarded and `recommend` otherwise defaults to the
   quality pick. One `model_run` per candidate, `jobs_wait`, `asset_display`, and let the user pick
   (unattended: gate all, keep the best pass).
3. Gate the pick with `asset_analyze` (write lane, contract in `scenario-asset-analysis`), the spec
   via `text_inputs`: name read letter by letter, geometry closed and centered, no resemblance to an
   existing mark. It gates the render, not the file (`scenario-asset-analysis`), so the palette
   check is a local parse of the SVG's fills. Fail means re-run with the prompt tightened
   (`jobs_wait` the new job before re-gating), never an edit of the drifted output.
4. Variants: `asset_get` the winning mark and save its `url` with `curl -L`, which serves the stored
   SVG verbatim (`asset_download` converts to raster, `format` defaulting to `png`). Recolor fills
   to make mono, reversed, and paper-background variants; `upload_asset` each (`kind` `image`). One
   mark, colorways as data.
5. Applications: `recommend` with `capability="img2img"`, skipping a pick whose
   `when_general_better` or `caveats` name the placement at hand; wire the approved mark as
   reference exactly as the schema says (an array only under `array: true`; a pick whose schema has
   no image field cannot hold the mark, so take the next option). One `model_run` per placement
   (avatar, banner, printed card or badge), each prompt subordinating the scene to the mark and
   barring lettering or fake UI from the frame (a plate shows the mark in place, not the product
   working): "the exact logo from the reference, unaltered, centered on...". `jobs_wait` the runs,
   then gate each against the spec; text the gate cannot resolve at output size is unverified, not
   passed (upscale and re-gate, or flag it), and a scene that mangled the mark goes back through the
   same `img2img` call, the prompt naming the defect with the approved mark as ground truth.
6. Exact text (tagline, handle, URL) is composited by `scenario-text-overlay` in the spec's type,
   never prompted into the plate. Placement sizes derive per `scenario-formats`.
7. Board: the kit is judged as one picture. `model_scenario-compose-image` takes the mark, palette
   swatches, a type specimen, the voice line set large, an image-direction plate (one more run), an
   icon and badge strip and two applications as layers placed by `x`, `y`, `anchor` and `zIndex` on
   a `canvasMode: "custom"` canvas, plus a construction panel drawn locally from the master SVG,
   never generated (a generated diagram shows geometry the mark does not have), panel labels
   rendered by `scenario-text-overlay` (layer fields and traps: `scenario-video-assembly`). Give
   every layer an explicit `width` and `height`, the mark's larger than any other, each with
   `fit: "contain"`: empty is documented as native size and is not reliable, and setting both
   dimensions activates the default `fill`, which stretches and breaks the spec's own never-stretch
   rule. Size the canvas for the smallest caption rather than for a screen (it takes up to
   7680x4320, and a 1920x1080 board left palette captions near ten pixels tall), and render each
   layer from the master SVG at the pixel size that layer occupies instead of reusing one raster
   everywhere: the vector master exists so that no layer is ever upscaled. `upload_asset` each
   render before composing, since a layer `source` takes an asset, not a local file.
8. The collection, filled as the run went, is the kit: the SVG master, every variant, every
   application, the board. Write each asset's role and rule into its `asset_update` description, and
   deliver the spec sheet as the kit's usage page.

## Common mistakes

- Generating applications before a spec exists: without written hex values and rules there is
  nothing to gate against, and the kit drifts apart asset by asset.
- Re-imagining the logo per application instead of referencing it: ten cousins, no identity. The
  mark is generated once, then reused.
- Upscaling a raster of the logo: the vector already scales; the SVG stays the master.
- Recoloring by regenerating: fills and strokes in an SVG are text edits; a regeneration changes the
  geometry too.
- Passing a wordmark that looks right at thumbnail size: letterform drift hides there; the gate
  reads it back letter by letter.
- Treating palette hex values as a vibe: unnamed colors drift warm or cool per run; every prompt
  names them from the spec.
- Uploading a variant that is byte-identical to the master: the platform returns the master's own
  asset id, so two kit entries silently collapse into one and the collection count is wrong. A
  variant that changes nothing is not a variant; edit a fill, or drop the baked ground path, before
  uploading.
- Deriving a variant from a mockup instead of the master: derivative-of-derivative compounds
  artifacts (`scenario-formats` has the order of operations).
