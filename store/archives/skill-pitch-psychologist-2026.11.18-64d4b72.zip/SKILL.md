---
name: pitch-psychologist
description: "Structure pitches, decks, and talk tracks around audience beliefs, proof, and a clear decision when presentations need stronger progression."
risk: safe
source: community
date_added: "2026-04-04"
---
Use a marketing planning and audience-research lens. Your task is to structure sales pitches, decks, and presentations using psychological sequencing that builds desire before introducing the solution and makes the choice and its tradeoffs clear.

## When to Use
- Use when a sales, investor, or product pitch needs stronger belief progression and audience alignment.
- Use when the pitch must move from attention to trust to commitment with less resistance.

## Evidence and scope

Use observed audience research and verified product facts. Psychological interpretations and the author-year references below are inherited conceptual context, not validated evidence for this exact workflow or a guaranteed conversion effect. Before using a scientific claim externally, verify the actual publication, method and applicability; omit unsupported claims. This is marketing planning, not clinical diagnosis. Do not infer sensitive traits or exploit vulnerabilities.

Original contribution: [PR 451](https://github.com/sickn33/agentic-awesome-skills/pull/451) by MMEHDI0606; [immutable source snapshot](https://github.com/MMEHDI0606/antigravity-awesome-skills/blob/9c61357e3e6bb167946036f52ac1e28fc82e04d0/skills/pitch-psychologist/SKILL.md). This identifies the contributed instructions, not scientific validation or a new upstream endorsement.

## CONTEXT GATHERING

Before building a pitch, establish:

1. **The Target Human** - psychographic profile, trust stage, and awareness level.
2. **The Objective** - the decision or commitment the pitch must produce.
3. **The Output** - deck, talk track, one-pager, or demo script.
4. **Constraints** - audience type, time limit, and ethical boundaries.

If the decision context is unclear, ask before proceeding.

## PSYCHOLOGICAL FRAMEWORK: DESIRE-THEN-SOLUTION ARC

### Mechanism
People are more persuadable when they first feel the problem, the aspiration, and the cost of staying put, then receive the solution as the natural resolution. Narrative transportation, contrast, anchoring, and memory sequencing all matter more than raw feature density (Green & Brock, 2000; Chen & Bell, 2022; Bagozzi et al., 2021; peak-end research; motivated sequence theory).

### Execution Steps

**Step 1 - Open with the audience's world**
Start from the customer's current reality and stakes.
*Planning hypothesis (verify before presenting as research): self-relevance and narrative transportation increase receptivity (Green & Brock, 2000; Dragojevic et al., 2024).*

**Step 2 - Build desire before solution**
Show the better future and the cost of not getting there.
*Planning hypothesis (verify before presenting as research): desire-first sequencing reduces defensive processing and improves belief change (Monroe's motivated sequence; narrative persuasion studies).*

**Step 3 - Frame the contrast**
Make the current state and proposed state visibly different.
*Planning hypothesis (verify before presenting as research): contrast and anchoring shape evaluation by shifting the reference point (Ariely et al., 2003; Houdek, 2016).*

**Step 4 - Introduce the solution as the bridge**
Position the offer as the path through the tension you already established.
*Planning hypothesis (verify before presenting as research): people accept solutions more readily when the problem has been emotionally and cognitively prepared (Bagozzi et al., 2021).*

**Step 5 - End with remembered clarity**
Close on the key idea, proof, and next step.
*Planning hypothesis (verify before presenting as research): the peak-end rule shapes what audiences recall after the pitch (memory and decision research; Chen & Bell, 2022).*

## DECISION MATRIX

### Variable: audience type
- If technical -> lead with evidence, then implications, then demo.
- If executive -> lead with risk, opportunity, then business outcome.
- If consumer -> lead with desire, identity, then ease of action.
- If skeptical -> lead with proof, then only enough story to connect it.

### Variable: awareness stage
- If unaware -> start with the problem and the cost of delay.
- If problem aware -> sharpen the problem and show a believable alternative.
- If solution aware -> show why your approach fits best.
- If product aware -> reduce hesitation with proof and clarity.

### Variable: pitch length
- If short -> compress into problem, tension, bridge, ask.
- If medium -> add proof and comparison.
- If long -> add case logic, objections, and decision support.

## FAILURE MODES - DO NOT DO THESE

**Failure Mode 1**
- Agents typically: open with features.
- Why it fails psychologically: the audience has no emotional reason to care yet.
- Instead: open with the world and tension.

**Failure Mode 2**
- Agents typically: pack the pitch with details before desire is built.
- Why it fails psychologically: cognitive load increases and persuasion drops.
- Instead: sequence desire before explanation.

**Failure Mode 3**
- Agents typically: end weakly.
- Why it fails psychologically: people remember the ending and the peak more than the middle.
- Instead: end on the key idea and next step.

## ETHICAL GUARDRAILS

This skill must:
- Be truthful about capabilities and tradeoffs.
- Avoid theatrical pressure or fake inevitability.
- Respect the audience's right to decline.

The line between persuasion and manipulation is sequencing ideas to help a person evaluate a real offer versus engineering a narrative that hides material facts. Never cross it.

## SKILL CHAINING

Optional context from related skills (equivalent supplied research is sufficient; do not create a prerequisite cycle):
- [ ] `@customer-psychographic-profiler`
- [ ] `@jobs-to-be-done-analyst`
- [ ] `@awareness-stage-mapper`
- [ ] `@trust-calibrator`

This skill's output feeds into:
- [ ] a deck outline
- [ ] a sales-page draft
- [ ] a presentation script

## OUTPUT QUALITY CHECK

Before finalizing output, the agent asks:
- [ ] Did I build desire before explaining the solution?
- [ ] Did I use contrast effectively?
- [ ] Did I choose the right pitch sequence for the audience?
- [ ] Did I end with remembered clarity?
- [ ] Would the pitch still feel honest if challenged?

## Example

**User request:**

> Rewrite this sales pitch with a clearer belief progression and stronger alignment to the audience.

**Illustrative output:** Build an outline from a supplied problem, verified result and proposed next step; attach the source to each number and include a limitations slide when it changes the decision.

## Limitations
- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.
