---
name: implementing-identity-governance-with-sailpoint
description: Deploys SailPoint IdentityNow or IdentityIQ for identity governance and
  administration, covering identity lifecycle management, access request workflows,
  certification campaigns, role mining, separation-of-duties (SOD) policy enforcement,
  and compliance reporting. Use when standing up or tuning an identity governance
  program, automating access certifications, or enforcing SOD policies across
  enterprise IAM.
domain: cybersecurity
subdomain: identity-access-management
tags:
- iam
- identity
- access-control
- governance
- sailpoint
- iga
- lifecycle
version: '1.0'
author: mahipal
license: Apache-2.0
nist_csf:
- PR.AA-01
- PR.AA-02
- PR.AA-05
- PR.AA-06
mitre_attack:
- T1078
- T1110
- T1556
- T1098
mitre_f3:
  version: '1.1'
  tactics:
  - positioning
  - initial-access
  - defense-impairment
  techniques:
  - id: F1005
    name: Account Manipulation
    tactic: positioning
    source: f3
  - id: F1005.002
    name: 'Account Manipulation: Add Authorized User'
    tactic: positioning
    source: f3
  - id: F1033
    name: Insider Access Abuse
    tactic: initial-access
    source: f3
  - id: F1042
    name: Reactivate Account
    tactic: positioning
    source: f3
  - id: F1006
    name: Account Takeover
    tactic: initial-access
    source: f3
---
# Implementing Identity Governance with SailPoint

## Overview
Deploy SailPoint IdentityNow or IdentityIQ for identity governance and administration. Covers identity lifecycle management, access request workflows, certification campaigns, role mining, SOD policy enforcement, and compliance reporting for enterprise IAM.


## When to Use

- When deploying or configuring implementing identity governance with sailpoint capabilities in your environment
- When establishing security controls aligned to compliance requirements
- When building or improving security architecture for this domain
- When conducting security assessments that require this implementation

## Prerequisites

- Familiarity with identity access management concepts and tools
- Access to a test or lab environment for safe execution
- Python 3.8+ with required dependencies installed
- Appropriate authorization for any testing activities

## Objectives
- Implement comprehensive implementing identity governance with sailpoint capability
- Establish automated discovery and monitoring processes
- Integrate with enterprise IAM and security tools
- Generate compliance-ready documentation and reports
- Align with NIST 800-53 access control requirements

## Security Controls
| Control | NIST 800-53 | Description |
|---------|-------------|-------------|
| Account Management | AC-2 | Lifecycle management |
| Access Enforcement | AC-3 | Policy-based access control |
| Least Privilege | AC-6 | Minimum necessary permissions |
| Audit Logging | AU-3 | Authentication and access events |
| Identification | IA-2 | User and service identification |

## Verification
- [ ] Implementation tested in non-production environment
- [ ] Security policies configured and enforced
- [ ] Audit logging enabled and forwarding to SIEM
- [ ] Documentation and runbooks complete
- [ ] Compliance evidence generated
