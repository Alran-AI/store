# Source

Unmodified copy of `products/replay_vision/skills/designing-replay-vision-scanners` from https://github.com/PostHog/posthog
at commit 7917ace4699acf8c1be743e25eb767df41627c3b (2026-11-18), under the MIT licence.

Copyright (c) 2020-2026 PostHog Inc.

The licence text is in LICENSE.txt. Nothing in this folder was edited.
