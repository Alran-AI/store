---
name: mental-health-analyzer
description: 分析心理健康数据、识别心理模式、评估心理健康状况、提供个性化心理健康建议。支持与睡眠、运动、营养等其他健康数据的关联分析。
allowed-tools: Read, Grep, Glob, Write, Edit
risk: critical
source: community
date_added: "2026-03-06"
---

# 心理健康分析技能

## Detailed Guide

本技能仅用于整理用户授权的症状记录，不诊断、不预测自杀/自伤或提供危机风险分层。发生即时危险时应立即联系当地急救/急诊及可信赖的人，不等待数据分析。详见修订后的指南与 NICE 来源。

Read [the detailed guide](references/detailed-guide.md) before executing this skill. It retains the complete procedure and reference material. Treat its safety, prerequisites, and validation requirements as mandatory. For focused work, load the relevant sections; for end-to-end work, read the guide completely.

## When to Use
- 需要分析情绪、焦虑、抑郁评分、治疗进展或危机风险时使用。
- 任务涉及心理健康趋势、情绪模式识别或与睡眠/运动/营养的关联分析。
- 用户请求心理健康报告、风险预警或治疗进展追踪时使用。

## Limitations
- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.
