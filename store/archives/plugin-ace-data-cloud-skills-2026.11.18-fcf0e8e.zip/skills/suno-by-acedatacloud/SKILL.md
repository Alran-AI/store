---
name: suno-by-acedatacloud
description: Create songs or instrumental music with Suno, provided by Ace Data Cloud; retrieve the same task until its final audio is ready.
license: Apache-2.0
metadata:
  author: Ace Data Cloud
  version: "1.0.0"
  category: music
---

# Suno by Ace Data Cloud

Create songs or instrumental music with Suno, provided by Ace Data Cloud; retrieve the same task until its final audio is ready.
This is an Ace Data Cloud integration, not an official Suno or Amp plugin endorsement.

## Setup and tool scope

Requires Amp native Skill MCP support, an existing Amp login, and `ACEDATACLOUD_API_TOKEN` in the environment that starts Amp.

Read [README.md](README.md) for installation, illustrated API-key setup, and troubleshooting.
The sibling `mcp.json` connects only `suno-ace` at `https://suno.mcp.acedata.cloud/mcp` and limits tools to this service.
Reuse an existing matching connection; do not add a second server or alter unrelated settings.
Keep the API key in `ACEDATACLOUD_API_TOKEN`; never request it in the conversation, put it in a command argument, or print it.
Load this Skill to expose its MCP tools. Use `suno_list_models` once to inspect the supported choices; this is informational and does not prove API permissions or balance.

## Generation and retrieval

1. Confirm the user wants this music operation and accepts its [current pricing](https://platform.acedata.cloud/models?utm_source=amp&utm_medium=integration&utm_campaign=evergreen&utm_content=suno_amp_pricing), parameters and output count. Choose a currently supported model and parameters with the user; do not silently substitute models, providers, prices, or resolution tiers.
2. Call `suno_generate_music` exactly once for that requested operation. Use an edit tool only when the user provides authorized reference media and asks to edit it.
3. Save the returned task ID. Call `suno_get_task(task_id="<original task ID>")` to retrieve the same task after pending results, disconnects or timeouts. Never submit generation again merely to poll.
4. Require an explicit terminal success (`state=complete` with success, or the returned finished timestamp and successful response). Failure is terminal too. A pending task or an early media URL is not completion. Do not invent IDs, output links, media availability, completion or billing. Report the final status and returned media links; preserve upstream errors (including rate limit and moderation meaning).
5. On an uncertain submission, inspect its original task/request before any new paid request. A failed result is not permission to retry, change the model, or use a fallback.

## Section replacement and billing

For `/suno/audios` `replace_section`, inspect the connected edit schema before calling. Supply the source song's `audio_id` and a nonnegative start/end interval within its duration, with end greater than start. Put local new lyrics for that interval in `lyric` and preferably the same text in `prompt`, not full-song lyrics or a style description. Default `replace_section_result_mode="full_song"` returns two assembled songs without another `concat`; `"candidates"` returns unassembled candidates that need selection and `concat`.

Poll the same task to terminal success, then audition both results for new words, transitions and actual duration. Full-song output does not guarantee equal length; `duration` cannot lock a replacement interval. Returned `lyric` is metadata, not an audio transcript or proof of a successful lyric change. For another edit, use the selected complete result's audio ID and recheck its timing, not the prior task ID or original timestamps. Do not automatically submit another paid replacement to repair an unsatisfactory result.

Check current pricing before these auxiliary operations: successful `/suno/lyrics` costs **0.08 Credits per request**, `/suno/voices` creation **0.15 Credits per request**, and `/suno/audios` `action=stems` **0.56 Credits per request**. Multiple lyric candidates or the vocal/accompaniment pair count as one request, not per output. Failed requests are not charged; applicable discounts follow the actual bill. These rates do not apply to `all_stems`, `extract_stem`, or other actions.

## Custom inputs and processing failures

When the connected tool supports `negative_tags`, use it for generation with `custom: true` or for `replace_section`. The audio endpoint currently enforces no fixed character limit for this field; keep it concise because overly long input may still fail.

A downloadable audio file does not guarantee its `audio_id` remains usable for covers, extension or stem separation. Preserve the public HTTP 500 codes `suno_processing_unavailable` (processing unavailable), `suno_model_unavailable` (selected model unavailable for this operation), and `suno_processing_failed` (processing returned no audio). Also preserve HTTP 500 `api_error` with the message `the account may have been offline` when returned by `/suno/audios`. Retain `task_id` and `trace_id` when returned and contact support with those IDs, never the API key. Query the existing task if submission is uncertain; do not automatically retry a paid operation or silently switch models.

Amp reasoning can have its own usage charge. Installation/tool discovery and API metadata are distinct from inference, generation, terminal media, and the account's usage record.
