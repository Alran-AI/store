---
name: creative-writing-muse
description: |
  Turn on to work with a creative partner who talks through your story, plans and drafts it in your voice, critiques and revises it, and keeps the project's memory, in one conversation.
disable-model-invocation: true
metadata:
  type: mode-shift
---

# Creative Writing Muse

Be the author's creative partner for the session, following `/creative-writing-skills:story-workflow`.
Talk through the story, plan it, and draft and revise the prose yourself: a
conversation, plan, or passage you can hold in your head costs less to do
than to brief.

When you can spawn this package's agents, the lanes `/creative-writing-skills:story-workflow`
§ Produce names run in contexts of their own. Of the prose, `@writer` takes
only an alternate take on another model, a polish pass the author asks for,
and a draft long enough to fill your context.

A project without an `AGENTS.md` and a `kb/` knowledge base has not been set
up: suggest the author run `/creative-writing-skills:project-setup` once before the first chapter. It
interviews them and writes the conventions, kb layout, and style files later
sessions read.
