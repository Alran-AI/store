---
name: decision-helper
description: "Help me decide between options with a weighted pros/cons that actually reaches a recommendation — not just two lists. Use when asked should I take job A or B, which one should I buy, help me decide, or make a pro/con list. Produces the criteria that matter (weighted by what you care about), the options scored against them, a clear recommendation with its confidence, and the single question that would flip the decision if you're still torn."
---

# Decision Helper

Pro/con lists fail because they treat every point as equal and stop before deciding. This does the honest version: it pulls out the criteria that actually matter to *you*, weights them, scores each option, and then commits to a recommendation — while naming the one unknown that, if resolved, would change the answer. It helps you decide, not just organise the agonising.

## What This Skill Produces

- **The criteria, weighted** — what actually matters here, and how much (not a flat list)
- **The scored comparison** — each option against each criterion
- **A recommendation** — a clear lean, with how confident and why
- **The tiebreaker question** — the one unknown that would flip it, so you know what to go find out
- **The gut-check** — a prompt to notice if the "winner" makes you uneasy (that's data too)

## Required Inputs

Ask for these if not provided:
- **The options** — what you're choosing between (2+ concrete choices)
- **What matters to you** — money, growth, stress, location, values… (or the skill will propose criteria and ask you to weight them)
- **The stakes & reversibility** — one-way door or easily undone? (changes how much rigor is worth)
- **Any hard constraints** — deal-breakers that filter options before scoring

## Framework: Decide, Don't Just List

1. **Criteria before options.** Name what a good outcome depends on *before* looking at the choices, so scoring isn't rationalised.
2. **Weight honestly.** If money is 3× more important than commute, say so — equal weights are a hidden lie.
3. **Score, then total.** Each option × each criterion; the math surfaces where a "close call" actually isn't.
4. **Commit to a lean.** State the recommendation and its confidence — "narrowly A" is more useful than "it depends."
5. **Name the tiebreaker.** The one fact that would change the answer tells you what to research next.
6. **Respect the gut.** If the math says A but your stomach sinks, that mismatch is a criterion you haven't named yet.

## Output Format

### Deciding: [option A] vs [option B] · reversibility: [one-way / easy]

### Weighted criteria
| Criterion | Weight | A | B |
|---|---|---|---|
| … | high/med/low | score | score |

### Recommendation
> Lean: **[option]** — confidence [high/medium/low]. Why: …

**Tiebreaker:** the one thing to find out — [question].
**Gut-check:** does the winner sit right? If not, what's the unnamed criterion?

## Quality Checks
- [ ] Criteria were drawn from what the user cares about, then weighted (not equal by default)
- [ ] Each option is scored against each criterion
- [ ] A clear recommendation is given, with confidence — not "it depends"
- [ ] The single decision-flipping unknown is named
- [ ] Reversibility is factored into how much certainty is worth chasing
- [ ] The gut-check prompt is included

## Anti-Patterns
- **A flat pro/con list** with no weights and no decision.
- **False precision** — inventing exact scores for things you can't know; use ranges and label assumptions.
- **Refusing to recommend** — "both have merits" is the one thing the user came to avoid.
- **Ignoring reversibility** — agonising over an easily-undone choice, or rushing a one-way door.

## Example Trigger Phrases
- "Help me decide between two job offers."
- "Which laptop should I buy — here are three?"
- "Should I move cities for this role? Make it a weighted decision."
- "I'm torn between two apartments — help me choose."
- "Make a real pro/con list and actually tell me what to pick."

Run this skill in your browser: https://mohitagw15856.github.io/pm-claude-skills/skill/decision-helper.html
