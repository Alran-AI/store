# Developer Onboarding - Detailed Guide

> This file contains the detailed procedure and reference material extracted from `SKILL.md` for focused loading. The root skill defines activation, examples, safety constraints, and limitations.

## Overview

Developer onboarding is the critical window between "I signed up" and "I understand how to use this." Use a short, task-specific first-value goal rather than assuming a universal attention limit. Every second of confusion, every error message without guidance, every "it should work but doesn't" moment costs you users.

Great onboarding feels like pair programming with someone who anticipated every question. Bad onboarding feels like being dropped in a foreign city without a map.


## Before You Start

Resolve the installed `developer-audience-context` skill, if available, and review it to understand your target developers. A hobbyist building side projects needs different onboarding than an enterprise architect evaluating tools for production. Resolve and review the installed `developer-signup-flow` skill if available to ensure signup flows smoothly into onboarding.


## Time-to-First-Value Optimization

### Defining "First Value"

First value isn't "made an API call." First value is when the developer sees your tool doing something useful for them.

| Tool Type | First Value Moment |
|-----------|-------------------|
| API | Response returns meaningful data |
| SDK | Library performs expected function |
| Database | Query returns results |
| Hosting | App is live and accessible |
| Auth | User successfully logs in |
| Payment | Test charge processes |

### Measuring Time to First Value (TTFV)

Track timestamps at each stage:

```
signup_completed: 2024-01-15T10:00:00Z
dashboard_loaded: 2024-01-15T10:00:05Z
api_key_copied: 2024-01-15T10:01:30Z
first_api_call: 2024-01-15T10:04:45Z
first_successful_response: 2024-01-15T10:04:46Z  # TTFV = 4:46
```

**Illustrative targets by category (not measured benchmarks):**
- Simple APIs: <5 minutes
- SDKs requiring installation: <10 minutes
- Complex infrastructure: <30 minutes
- Self-hosted: <60 minutes

### Removing TTFV Obstacles

Map every step and eliminate blockers:

**Common TTFV killers:**
1. Email verification before dashboard access
2. API keys hidden in account settings
3. Quickstart assumes dependencies already installed
4. First example requires paid features
5. Error messages without resolution guidance
6. Docs search finds outdated tutorials

**TTFV audit process:**
1. Create new account (fresh browser, no cookies)
2. Screen record your first 30 minutes
3. Note every moment of confusion or friction
4. Time each step
5. Repeat with 5 different developer personas


## Quickstart Checklist Design

### The Ideal Quickstart Structure

```markdown
# Quickstart: [Specific Goal] in 5 Minutes

What you'll build: [Screenshot or description of end result]

Prerequisites:
- A currently supported Node.js version matching the selected SDK (check: node --version)
- npm or yarn

## Step 1: Install the SDK
[One command, copy button]

## Step 2: Initialize with your API key
[Code with placeholder, copy button]

## Step 3: Make your first request
[Complete working example, copy button]

## Step 4: See the result
[Expected output shown]

## Next steps
- [Link to common second task]
- [Link to full documentation]
```

### Checklist Patterns That Work

**Progress indicators (Stripe style):**
```
Your integration progress:
[x] Create account
[x] Get API keys
[ ] Install SDK
[ ] Make first API call
[ ] Handle webhooks
```

**Contextual next steps (Vercel style):**
```
You've deployed your first site.

What's next?
[ ] Add a custom domain
[ ] Set up environment variables
[ ] Enable analytics
```

### Common Quickstart Failures

**Too much context upfront:**
```
# Bad: The history of authentication
Before we begin, let's understand OAuth 2.0...
[500 words of background]

# Good: Jump to action
Install the SDK and make your first authenticated request.
```

**Assuming environment:**
```
# Bad
Run `npm install` to install dependencies.

# Good
npm install our-sdk
# Or with yarn: yarn add our-sdk
# Or with pnpm: pnpm add our-sdk
```

**Hidden prerequisites:**
```
# Bad (prerequisite discovered in Step 3)
Step 3: Connect to Redis
First, make sure Redis is running...

# Good (prerequisites listed upfront)
Prerequisites:
- A supported Redis release in a disposable local environment (bind any published port to 127.0.0.1; pin the image version)
```


## Interactive vs Static Tutorials

### When to Use Interactive Tutorials

**Interactive tutorials work for:**
- Complex setup sequences
- Concepts that benefit from immediate feedback
- Onboarding flows where you control the environment
- Features requiring API keys or credentials

**Interactive tutorial tools:**
- Embedded code editors (CodeSandbox, StackBlitz)
- Terminal emulators (Instruqt, Killercoda)
- In-dashboard walkthroughs (Appcues, Pendo)
- Interactive notebooks (Jupyter, Observable)

### When Static Documentation Wins

**Static docs work better for:**
- Reference documentation
- Copy-paste code snippets
- Steps involving local development
- Content that changes frequently

### Hybrid Approach

**Best practice: Offer both**

```
# Make Your First API Request

## Quick version (copy-paste)
[Code block with copy button]

## Interactive version
[Launch in StackBlitz] [Try in CodeSandbox]

## Video walkthrough
[5-minute embedded video]
```

### Interactive Tutorial UX Guidelines

**Do:**
- Save progress automatically
- Allow skipping ahead
- Show estimated time remaining
- Provide escape hatch to static docs
- Work in mobile browsers (at least for viewing)

**Don't:**
- Require account creation for tutorials
- Auto-play videos
- Lock content behind completed steps
- Time out idle sessions without warning
- Require specific IDE or browser


## Sample Apps and Templates

### Template Strategy

**Tiered approach:**

1. **Minimal example** (Hello World)
   - Single file
   - Zero dependencies beyond your SDK
   - Works in 30 seconds
   - Purpose: Prove the SDK works

2. **Starter template** (Basic app)
   - Simple folder structure
   - Common patterns demonstrated
   - Works in 5 minutes
   - Purpose: Starting point for real projects

3. **Production template** (Full app)
   - Production-ready architecture
   - Auth, error handling, testing included
   - Works in 30 minutes
   - Purpose: Reference implementation

### Template Organization

```
github.com/your-org/
├── examples/
│   ├── minimal/
│   │   ├── node/
│   │   ├── python/
│   │   └── go/
│   ├── starter/
│   │   ├── nextjs/
│   │   ├── express/
│   │   └── fastapi/
│   └── production/
│       ├── saas-starter/
│       └── internal-tool/
```

### Template Maintenance

Templates that don't work are worse than no templates.

**Template health checklist:**
- [ ] CI runs against all templates weekly
- [ ] Dependencies updated monthly
- [ ] SDK version pinned and updated with releases
- [ ] README tested by new contributor quarterly
- [ ] Deprecation notices added before removal

### Real Examples

**Excellent templates: Supabase**
- Templates for multiple frameworks
- One-click deploy to Vercel/Netlify
- Include auth, database, and storage patterns
- Actively maintained

**Excellent templates: Clerk**
- Framework-specific quickstarts
- Complete with authentication flows
- Progressive complexity (minimal → full-featured)


## Handling Onboarding Failures Gracefully

### Common Failure Points

1. **Installation failures**
   - Dependency conflicts
   - Version mismatches
   - Platform-specific issues

2. **Authentication failures**
   - Invalid API key
   - Expired token
   - Wrong environment (test vs production)

3. **First request failures**
   - Network issues
   - CORS problems
   - Rate limiting
   - Invalid request format

### Error Message Design

**Bad error message:**
```
Error: Request failed with status 401
```

**Good error message:**
```
Authentication failed: Invalid API key

The configured key is not accepted for this sandbox environment.

To fix:
1. Verify the product’s documented sandbox key type and endpoint.
2. Check permissions, expiry and rotation without displaying the key.
3. Retry the documented test request; do not switch to live credentials merely to bypass the error.

Docs: https://docs.example.com/auth#environments
```

### Proactive Failure Prevention

Validate key/environment compatibility using the selected provider’s documented metadata or SDK, not generic key-prefix or URL-substring guesses. Different environments may share an API hostname. Record only redacted error categories and test-mode identifiers in analytics.

### Recovery Flows

**In-dashboard error recovery:**

```
Something went wrong with your integration.

We detected:
- Last API call: 2 hours ago
- Status: 401 Unauthorized
- Likely cause: API key rotated

[Regenerate API Key] [View Error Logs] [Contact Support]
```


## Measuring Activation Metrics

### Defining Activation

Activation = the moment a developer has enough success to keep using your product.

Different products, different activation definitions:

| Product | Activation Definition |
|---------|----------------------|
| Stripe | First successful test charge |
| Twilio | First SMS sent and delivered |
| Auth0 | First user authenticated |
| Vercel | First deploy accessible via URL |
| Algolia | First search returns results |

### Core Activation Metrics

**Activation rate**
```
Activated users / Signed up users × 100
```
Illustrative target: 20–40%; define the cohort, eligibility and observation window before comparing.

**Time to activation**
```
Median time from signup to activation event
```
Illustrative internal target: <10 minutes for APIs, <1 hour for infrastructure; validate with actual setup requirements.

**Activation by cohort**
Track weekly or monthly cohorts to identify improvements:
```
Week 1 cohort: 25% activation
Week 2 cohort: 28% activation (added better error messages)
Week 3 cohort: 35% activation (added interactive tutorial)
```

### Leading Indicators

Track behaviors that predict activation:

| Leading Indicator | Illustrative hypothesis (validate locally) |
|-------------------|---------------------------|
| Copied API key | 2x more likely |
| Viewed quickstart | 1.5x more likely |
| Installed SDK | 3x more likely |
| Joined Discord | 2.5x more likely |

### Lagging Indicators

Confirm activation led to value:

| Lagging Indicator | Meaning |
|-------------------|---------|
| Day 7 retention | Still using after a week |
| API calls in week 2 | Continued development |
| Upgrade to paid | Perceived enough value |
| Invited team member | Expanding usage |

### Activation Funnel Example

```
Signed up: 1,000
├── Visited dashboard: 950 (95%)
├── Viewed quickstart: 700 (74%)
├── Copied API key: 500 (71%)
├── Made first API call: 350 (70%)
├── Got successful response: 300 (86%)  ← Activation
├── Made 10+ API calls: 150 (50%)
└── Day 7 return: 100 (67%)
```


Obtain appropriate analytics consent and minimize captured identifiers. Never record API keys, request secrets or full sensitive responses in screen recordings, logs or funnel events. Use a sandbox account and synthetic data; do not remove essential authentication or anti-abuse controls to lower friction. Product examples and tool lists are illustrative, not verified current capabilities.

## Onboarding Email Sequences

Drafting a sequence does not authorize sending it. Use the actual consent, suppression, unsubscribe and user-authorized audience rules. The illustrative schedule below has both a welcome and +1-hour message; choose a cadence consistent with the stated daily limit.

### Email Timing

| Email | Timing | Purpose |
|-------|--------|---------|
| Welcome | Immediate | Confirm signup, provide key links |
| Getting started | +1 hour | Drive first API call if not done |
| Tips | +1 day | Share common patterns |
| Check-in | +3 days | Ask if stuck, offer help |
| Activation push | +7 days | Final nudge if not activated |

### Email Content Principles

**Do:**
- Include code snippets (syntax highlighted)
- Link to specific docs pages
- Offer direct reply for help
- Stop sequence once activated

**Don't:**
- Send marketing content during onboarding
- Require clicks to view content
- Send more than one email per day
- Continue sequence after activation


## Tools

### Onboarding Platforms

- **Appcues** - In-app walkthroughs and checklists
- **Pendo** - Product analytics with onboarding features
- **Userflow** - No-code onboarding flows
- **CommandBar** - Developer-focused command palette with onboarding

### Interactive Documentation

- **CodeSandbox/StackBlitz** - Browser-based code environments
- **Killercoda** - Interactive terminal scenarios
- **ReadMe** - API documentation with "Try It" features
- **Mintlify** - Modern docs with embedded code runners

### Email and Lifecycle

- **Customer.io** - Behavior-triggered emails
- **Loops** - Email for SaaS
- **Intercom** - Chat + email onboarding

### Analytics

- **Amplitude** - Onboarding funnel analysis
- **PostHog** - Open source alternative
- **Heap** - Auto-capture for retroactive analysis


## Related Skills

- `/devmarketing-skills/skills/developer-signup-flow` - Getting to the onboarding start
- `/devmarketing-skills/skills/developer-audience-context` - Who you're onboarding
- `/devmarketing-skills/skills/free-tier-strategy` - What they can do without paying
