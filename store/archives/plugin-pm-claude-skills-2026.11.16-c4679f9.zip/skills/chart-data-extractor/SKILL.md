---
name: chart-data-extractor
description: "Extract pixel-level data from an image of a chart or graph and produce a structured data table. Use when asked to extract data from a chart image, transcribe numbers from a graph, digitise a chart, or turn a screenshot of data into a table. Produces a structured table with extracted values, confidence levels, and a reconstructed chart source. Needs a model that can read images at high resolution."
---

# Chart Data Extractor Skill

Extracts data from images of charts and graphs — bar charts, line charts, pie charts, scatter plots, and tables in images — producing a structured data table that can be used in spreadsheets or rebuilt in any charting tool.

## Required Inputs

Work from what is given. If any of these is missing, still produce the complete output: fill each gap with a reasonable assumption marked *(assumed, confirm)* and list those assumptions at the end. Ask a question first only when the core subject itself is missing (there is nothing to write about).
- **The chart image** (upload a screenshot or image file)
- **Chart type** (if ambiguous — bar / line / pie / scatter / other)
- **What matters most** (approximate trends / precise values / specific data points / categorisation)
- **Known axis values** (optional — if the user knows the max/min values to anchor the extraction)

## Output Structure

### 1. Chart Identification

| Attribute | Value |
|---|---|
| Chart type | [Bar / Line / Pie / Scatter / Area / Other] |
| Chart title (if visible) | [Title text] |
| X-axis label | [Label + unit] |
| Y-axis label | [Label + unit] |
| Number of series | N |
| Legend categories | [List] |
| Data period (if time-based) | [Start — End] |

### 2. Extracted Data Table

| [X axis] | [Series 1] | [Series 2] | ... |
|---|---|---|---|
| [Value] | [Value] | [Value] | |

### 3. Confidence Levels

For each data point or series, flag confidence:

- **High confidence:** data points where the value is clearly readable against gridlines or labels
- **Medium confidence:** data points where the value is interpolated between gridlines
- **Low confidence:** data points where the value is ambiguous or overlaps with other elements

Low-confidence points should be explicitly listed — not silently included in the main table.

### 4. Notable Observations

Observations that the data itself reveals:
- Peak value: [Value, when, in which series]
- Lowest value: [Value, when, in which series]
- Largest delta between series: [Details]
- Any anomalies or outliers visible in the chart

### 5. Reconstructed Source

CSV format for direct use:

```csv
[x_axis],[series_1],[series_2]
[value],[value],[value]
```

### 6. Assumptions and Caveats

- Grid resolution: [How precisely values could be read — e.g. "Y-axis has major gridlines every 10 units, minor every 2"]
- Interpolation used: [Any values that required estimating between gridlines]
- Unclear data: [Anything in the chart that could not be read reliably]
- Axis scale: [Linear/logarithmic/etc — note if not obvious]

### 7. Follow-up Options

Ask the user which of these they want:
- Rebuild the chart in a specified format (Excel formula, Python matplotlib, D3, etc.)
- Produce a narrative description of what the chart shows
- Compare this data against another chart or source
- Flag potentially misleading visual choices in the original (truncated axes, misleading scales, etc.)

## Quality Checks
- [ ] Every extracted number specifies which series it belongs to
- [ ] Confidence levels are explicit for ambiguous points
- [ ] Low-confidence values are flagged separately, not silently included
- [ ] Assumptions about axis scale and interpolation are stated
- [ ] CSV output is clean and directly usable

## Anti-Patterns

- [ ] Do not silently include low-confidence data points in the main table — flag them separately so the user knows which values to verify
- [ ] Do not assume a linear scale without confirming it — logarithmic axes make extracted values incorrect by orders of magnitude if misread
- [ ] Do not report extracted values with false precision — if the chart's Y-axis only shows gridlines every 10 units, a reported value of 37 is invented, not extracted
- [ ] Do not omit the assumptions and caveats section — partial image quality, overlapping bars, or unlabelled axes must be disclosed

## Example Trigger Phrases
- "Extract the data from this chart"
- "Transcribe the numbers in this graph"
- "Turn this chart image into a spreadsheet"
- "Digitise this chart so I can rebuild it"
- "What are the exact values in this bar chart?"

## Model Requirements
Reading values off a chart depends on image resolution: a model that sees the chart at low resolution will misread gridlines and invent values. Use a model with high-resolution vision, and keep the confidence column honest. Where the image is small or compressed, say so and ask for a larger copy or the source data.

Run this skill in your browser: https://mohitagw15856.github.io/pm-claude-skills/skill/chart-data-extractor.html
