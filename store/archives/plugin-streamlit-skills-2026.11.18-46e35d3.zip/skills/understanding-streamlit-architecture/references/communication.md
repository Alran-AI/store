# Communication protocol

Deep dive into Streamlit's protobuf communication layer.

## Proto file location

`proto/streamlit/proto/` contains all `.proto` files.

Compile with: `make protobuf`

**Generated code**:
- Python: `lib/streamlit/proto/*_pb2.py` and `*_pb2.pyi`
- TypeScript: `frontend/protobuf/proto.js` + `frontend/protobuf/proto.d.ts` (package: `@streamlit/protobuf`)

## ForwardMsg (server to client)

`ForwardMsg.proto` - Root message sent from backend to frontend.

```protobuf
message ForwardMsg {
  string hash = 1;                    // Unique hash for caching
  ForwardMsgMetadata metadata = 2;    // delta_path, active_script_hash, agent_props, run

  oneof type {
    NewSession new_session = 4;
    Delta delta = 5;
    ScriptFinishedStatus script_finished = 6;
    SessionStatus session_status_changed = 9;
    Navigation navigation = 23;
    string ref_hash = 11;             // Reference to cached message
    // ... more types
  }
}
```

**Key types**:
- `delta`: UI updates (new elements, blocks, transients)
- `new_session`: Initial session setup, config, pages
- `script_finished`: Signals script completion
- `ref_hash`: Reference to cached message (bandwidth optimization)

## ForwardMsg metadata (`active_script_hash`)

`ForwardMsgMetadata` carries routing/context fields that are not part of hashed payload content:

```protobuf
message ForwardMsgMetadata {
  bool cacheable = 1;
  repeated uint32 delta_path = 2;
  string active_script_hash = 4;
  optional string agent_props = 5;    // JSON command description
  RunIdentity run = 6;                // script_run_id, fragment_ids
  // ... more fields
}
```

**Run identity** (`metadata.run`: run ID + fragment IDs):
- Set on `new_session` and `script_finished`; a `script_finished` omits it when the backend can't tell which run finished.
- `ScriptRunner` creates one `RunDescriptor` (`lib/streamlit/runtime/scriptrunner_utils/run_descriptor.py`) per run and sends it on the run's start and finish events; `AppSession` copies it onto the messages.
- The frontend reads it via `frontend/app/src/util/runIdentity.ts`.
- Deltas carry none: they belong to the most recent `new_session`.

**Semantics**:
- Backend sets `metadata.active_script_hash` from `ScriptRunContext.active_script_hash`
- On run reset, active hash is initialized to the main script hash
- In MPA v2, page execution runs under page hash context (`run_with_active_hash(page_hash)`)
- Fragment reruns restore the fragment's initialized active hash for stable element/widget identity
- Frontend stores this as `activeScriptHash` on render-tree nodes and uses it in page filtering (`FilterMainScriptElementsVisitor`)

## Agent command descriptions

Agent sessions store a command description on `ForwardMsg.metadata.agent_props` for the snapshot described in `specs/2026-08-28-agent-app-interface/product-spec.md`.

`ForwardMsgMetadata.agent_props` is a JSON description of the command that emitted the delta: public command name, parameter-named `props`, and for widgets `action` and `value_schema`. The command builds it with `agent_spec.element(...)` or `agent_spec.block(...)` in the same function that fills its proto. Prop values are encoded in `lib/streamlit/runtime/agent/json_encoding.py`. A table, chart, or map also adds `data`, built while recording with `elements/lib/agent_data.py`: a schema and a bounded preview, or the chart's specification, and for one eager Arrow dataset a `url`, the media-storage URL of an Arrow copy registered for agent sessions only. Lazy, oversized, multi-dataset, and URL-loaded data get no `url`. The snapshot copies `data` from the description; only a table replayed without a description is summarized from its payload. Cache replay registers the Arrow copies again only when an agent session replays the element.

`element` and `block` return `None` unless `agent_spec.register_agent_session` has marked the current session. `agent_spec.is_recording()` is that check: a marked session is recording, meaning each command attaches its description. A browser session on the same server is not recording, so its messages carry none.

The field is metadata, so `populate_hash_if_needed` leaves it out of the ForwardMsg hash. A `ref_hash` message copies the source metadata, so a cache hit still carries the description. How to write a description is in `lib/streamlit/AGENTS.md` under "Agent API element descriptions".

## BackMsg (client to server)

`BackMsg.proto` - Messages from frontend to backend.

```protobuf
message BackMsg {
  oneof type {
    ClientState rerun_script = 11;    // Main rerun trigger
    bool stop_script = 7;
    // ... more types
  }
}
```

**ClientState** (key field):
```protobuf
message ClientState {
  WidgetStates widget_states = 2;    // Current frontend-tracked widget values
  string page_script_hash = 3;
  string fragment_id = 5;
  // ... more fields
}
```

## Delta (UI changes)

`Delta.proto` - Incremental UI updates.

```protobuf
message Delta {
  oneof type {
    Element new_element = 3;          // Add UI element
    Block add_block = 6;              // Add container
    // ... more types
  }
  string fragment_id = 8;
}
```

**Delta path**: Array in metadata like `[0, 2, 3]` specifying tree position.

The frontend (`frontend/lib/src/render-tree/AppRoot.ts`) and the agent snapshot (`lib/streamlit/runtime/agent/tree.py`, `merge_deltas`) both apply these paths. A block of the same type keeps its children; a different block type or dialog identity replaces them. A change to those rules has to land in both places.

The trees still diverge after placement. The frontend merges messages as they arrive and keeps transient nodes. The snapshot merges the settled run, then drops nodes and props that have no semantic value. Do not fold the two mergers into one implementation or require the JSON tree to match the render tree node for node.

## Element types

`Element.proto` - ~50+ element types in `oneof type` union.

**Categories**:
- Text: `alert`, `markdown`, `text`, `heading`, `code`
- Data: `dataframe`, `table`, `json`, `metric`
- Charts: `vega_lite_chart`, `plotly_chart`, `deck_gl_json_chart`
- Input widgets: `button`, `checkbox`, `slider`, `text_input`, `selectbox`, `multiselect`
- Date/time: `date_input`, `time_input`, `date_time_input`
- Media: `audio`, `video`, `imgs`
- Special: `spinner`, `progress`, `toast`, `exception`
- Components: `component_instance`, `bidi_component`

## Component resource routes

Component deltas are transported over protobuf, but frontend assets are served over HTTP routes:
- `component_instance` (v1) assets: `/component/*`
- `bidi_component` (v2) assets: `/_stcore/bidi-components/*`
- These routes complement, not replace, WebSocket protobuf messaging

## Block types

`proto/streamlit/proto/Block.proto` defines layout containers (`st.container`, `st.expander`, `st.form`, `st.tabs`, `st.columns`, `st.chat_message`, `st.popover`, `st.dialog`). Modern column/container layouts use `FlexContainer`.

## WidgetStates

`proto/streamlit/proto/WidgetStates.proto` defines widget value transport. Each `WidgetState` has an `id` and a `oneof value` union supporting various types (bool, double, int, string, arrays, JSON, Arrow tables, file uploader state, etc.).

**Important**: `trigger_value` and `json_trigger_value` auto-reset to default after script run (used for buttons and similar transient interactions).

## Message flow diagrams

### Script execution to browser update

```mermaid
sequenceDiagram
    participant Script as User Script
    participant Mixin as ButtonMixin
    participant DG as DeltaGenerator
    participant Ctx as ScriptRunContext
    participant Queue as ForwardMsgQueue
    participant RT as Runtime
    participant WS as WebSocket
    participant App as App.tsx
    participant Tree as AppRoot
    participant Render as ElementNodeRenderer

    Script->>Mixin: st.button("Click")
    Mixin->>DG: _enqueue("button", proto)
    DG->>Ctx: enqueue(ForwardMsg)
    Ctx->>Queue: enqueue()
    RT->>Queue: flush()
    Queue->>WS: send(binary)
    WS->>App: handleMessage()
    App->>Tree: applyDelta()
    Tree->>Render: render
    Render-->>App: <Button> component
```

### Widget interaction to script rerun

```mermaid
sequenceDiagram
    participant User
    participant Button as Button Component
    participant WSM as WidgetStateManager
    participant Conn as ConnectionManager
    participant WS as WebSocket
    participant RT as Runtime
    participant Session as AppSession
    participant Runner as ScriptRunner
    participant State as SessionState

    User->>Button: click
    Button->>WSM: setTriggerValue(element)
    WSM->>WSM: Create WidgetState proto
    WSM->>Conn: sendBackMsg()
    Conn->>WS: BackMsg with ClientState
    WS->>RT: handle_backmsg()
    RT->>Session: handle_backmsg()
    Session->>State: update widget states
    Session->>Runner: request_rerun()
    Runner->>Runner: raise RerunException
    State->>State: run on_change callbacks
    Runner->>Runner: Execute script
    Note over Runner: st.button() returns True
    Runner->>Runner: After run: reset trigger_value
```

## Message caching

ForwardMsgs include `hash` for deduplication:

1. Backend computes hash of message content
2. Frontend maintains `ForwardMsgCache`
3. For unchanged content, backend sends `ref_hash` instead of full message
4. Frontend retrieves from cache using hash

**Benefit**: Reduces bandwidth for large/unchanged elements.

See [Agent command descriptions](#agent-command-descriptions) for how `agent_props` interacts with hashing.

## Key design decisions

| Decision | Problem | Solution |
|----------|---------|----------|
| Delta paths | Efficient tree updates | Array-based paths like `[0, 2, 3]` |
| Message caching | Bandwidth for large elements | Hash-based deduplication |
| Oneof unions | Type-safe variants | Protobuf `oneof` for Element, Block, Delta |
| Trigger vs persistent | Buttons should fire once | `trigger_value` auto-resets |
| Arrow format | Slow dataframe serialization | Apache Arrow columnar format |
