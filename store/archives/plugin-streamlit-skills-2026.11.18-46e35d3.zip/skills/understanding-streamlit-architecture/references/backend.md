# Backend architecture

Deep dive into Streamlit's Python backend.

## Execution hierarchy

```mermaid
flowchart TB
    Runtime["Runtime (singleton)"]
    SM[SessionManager]
    AS1[AppSession 1]
    AS2[AppSession 2]

    Runtime --> SM
    SM --> AS1
    SM --> AS2

    subgraph Session["Per Browser Tab"]
        SR[ScriptRunner]
        SS[SessionState]
        FMQ[ForwardMsgQueue]
        FS[FragmentStorage]
        PM[PagesManager]
    end

    AS1 --> SR
    AS1 --> SS
    AS1 --> FMQ
    AS1 --> FS
    AS1 --> PM
```

## Runtime (`lib/streamlit/runtime/runtime.py`)

Singleton managing the application lifecycle. Access via `Runtime.instance()`.

**Core responsibilities**:
- Runs the main asyncio event loop (`_loop_coroutine`) that flushes ForwardMsg queues to clients
- Manages subsystems: SessionManager, MediaFileManager, UploadedFileManager, ScriptCache, ComponentRegistry
- Coordinates thread-safe communication between script threads and the event loop via `asyncio.call_soon_threadsafe()`

**Message flush cycle**: Script threads enqueue ForwardMsgs and signal via `_enqueued_some_message()` callback → main loop wakes, iterates sessions, calls `flush_browser_queue()` → sends to clients via `SessionClient`

## AppSession (`lib/streamlit/runtime/app_session.py`)

Represents a single browser tab or agent API session.

**Lifecycle (browser)**:
1. WebSocket connects -> `Runtime.connect_session()`
2. Creates `AppSession` (ScriptRunner starts when the first `rerun_script` BackMsg arrives)
3. Widget interaction -> `handle_backmsg()` -> `request_rerun()`
4. Script produces ForwardMsgs -> queued -> flushed to browser
5. WebSocket disconnects -> cleanup

An agent API session uses the same `AppSession`. Its client buffers messages instead of sending them, and `POST /_stcore/agent/interact` calls `request_rerun()` directly and waits for the settle signal below. The rerun's client state carries the request's widget states, which `runtime/agent/widget_writes.py` validates against the session's last snapshot. When every widget the request sets is in one fragment, it reruns only that fragment, as the browser would. The session's copies of its table and chart data live in media storage beside its images, so they are released the same way: at the end of a full run that no longer renders them, and on shutdown.

**File watchers**: Monitors script, config.toml, secrets.toml, pages/ for changes.

**Script event loop**: Owns one non-running asyncio loop for the script thread, reused across `ScriptRunner` instances and closed on session shutdown.

**Settle signal**: `is_settled` is true when no `ScriptRunner` exists or is queued and every message of the last run chain has been sent to the client. A run chain is one `ScriptRunner`'s work: callback reruns, `st.rerun()`, `st.switch_page`, and queued fragment runs. Only sessions that call `track_settling()` (agent sessions) keep it.

- Creating a runner clears the signal.
- The runner's `SHUTDOWN` marks a settle as pending and requests a flush cycle. After sending a session's flushed batch, the Runtime loop calls `on_flushed_messages_sent()`, which settles the session once its queue is empty.
- `await wait_until_settled()` has no timeout of its own, so callers wrap it in `asyncio.timeout`.

## Session bootstrap ordering

Initial session creation and first script run are intentionally decoupled:

1. Backend WebSocket handler accepts connection and calls `Runtime.connect_session()`
2. Runtime/SessionManager creates (or reconnects) `AppSession`
3. Frontend transitions to `CONNECTED` and immediately sends `BackMsg.rerun_script` via `WidgetStateManager.sendUpdateWidgetsMessage()`
4. `AppSession.request_rerun()` creates/starts `ScriptRunner` for the first script execution

This ordering explains why `connect_session()` alone does not start user code execution.

## ScriptRunner (`lib/streamlit/runtime/scriptrunner/script_runner.py`)

Executes user scripts in isolated thread.

**Execution flow**:
1. Compile script to bytecode (cached via ScriptCache)
2. Create fake `__main__` module
3. Attach `ScriptRunContext` to thread
4. Execute with `exec()` in modified sys.path
5. Process widget callbacks before execution
6. Handle fragments for partial reruns

**Script events**:
- `SCRIPT_STARTED`
- `SCRIPT_STOPPED_WITH_SUCCESS`
- `SCRIPT_STOPPED_WITH_COMPILE_ERROR`
- `SCRIPT_STOPPED_FOR_RERUN` (st.rerun() called)
- `FRAGMENT_STOPPED_WITH_SUCCESS`
- `SHUTDOWN` (the ScriptRunner is exiting)

**Interrupt points**: Most `st.*` commands check for stop/rerun requests and raise `RerunException` or `StopException`.

## ScriptRunContext (`lib/streamlit/runtime/scriptrunner_utils/script_run_context.py`)

Thread-local context during script execution.

**Key fields**:
- `session_id`: Unique session identifier
- `session_state`: SafeSessionState wrapper
- `query_string`: URL query parameters
- `page_script_hash`: Current page identifier
- `widget_ids_this_run`: Widgets seen in current run
- `cursors`: Delta path cursors for element positioning
- `fragment_storage`: Storage for @st.fragment functions

**Access**: `get_script_run_ctx()` from any code during script execution.

## DeltaGenerator (`lib/streamlit/delta_generator.py`)

The `st` object users interact with.

**Mixin pattern**: Composes many mixins (one per element category) for all `st.*` API methods. See `lib/streamlit/delta_generator.py` for the full list.

**Cursor system**:
- `RunningCursor`: Moves forward as elements added
- `LockedCursor`: Fixed position for updating elements
- Delta path: `[0, 2, 3]` uniquely identifies element position

**Block delta paths**: `_block()` does not always write to the position that the parent cursor points to.

- It can redirect the write into one or more outside-container wrapper blocks, so the new block lands deeper in the tree (see the fragment system section below).
- Blocks that re-send their own proto later, such as `st.status` and `st.dialog`, must read `DeltaGenerator._block_delta_path` after `_block()` returns. Do not read `delta_path` from the parent cursor.
- A stored path that points at a wrapper instead of the block makes the update overwrite the wrapper and blank the app.

**Element creation**:
```
st.button("Click")
  -> ButtonMixin.button()
  -> _enqueue("button", ButtonProto(...), agent_props=...)
  -> ForwardMsg with delta path; agent_props on metadata when set
  -> ScriptRunContext.enqueue()
```

`agent_props` is JSON describing the command that emitted the delta: the public command name, its parameters, and a widget's value schema. Only a session the agent API created attaches it (`agent_spec.is_recording()`); a browser session passes `None`. See [communication.md](communication.md#agent-command-descriptions).

## SessionState (`lib/streamlit/runtime/state/session_state.py`)

Dictionary-like object for state persistence.

**Contents**:
- Widget values (automatic via `register_widget()`)
- User variables (`st.session_state.my_var = 123`)
- Query params integration (`st.query_params`)

**Widget registration**:
```python
register_widget(
    element_id,
    on_change_handler=callback,
    deserializer=serde.deserialize,
    serializer=serde.serialize,
    value_type="trigger_value",  # Maps to WidgetState proto field
)
```

**Lifecycle hooks**:
- `on_script_will_rerun()`: Process widget states from browser, run callbacks
- `on_script_finished()`: Reset trigger widgets. Drop stale widgets not seen this run, except on `SCRIPT_STOPPED_FOR_RERUN`: `st.rerun()` can interrupt before later widgets register, so stale cleanup is deferred until the next completed run.

**Disabled widget enforcement**: `WidgetMetadata` carries a `disabled` flag (set via `register_widget(..., disabled=...)`). Because a disabled widget cannot be interacted with in the browser, this is enforced server-side to guard against a stale UI or a forged `BackMsg`: `SessionState.register_widget()` discards any incoming frontend value for a disabled widget (falling back to its previous value, or its default on first registration), and `_call_callbacks()` suppresses its `on_change`/`on_click` callback. Programmatic `st.session_state` assignments are still honored.

## Caching (`lib/streamlit/runtime/caching/`)

**@st.cache_data** (`cache_data_api.py`):
- Pickle-based caching for data (DataFrames, lists)
- In-memory + optional disk persistence
- TTL support, max entries limit

**@st.cache_resource** (`cache_resource_api.py`):
- Stores singleton resources (DB connections, ML models)
- No serialization (stores objects directly)
- Cleanup hooks on cache clear

Replay of a cached element or block message copies its stored `agent_props` only when the replaying session is recording. The stored value is the description from the session that filled the entry. Media recorded with an element is registered again on replay. A replayed description whose `data` has a `url` registers its Arrow copy again from the element's payload, under the replayed element's delta path; the entry stores no copy of its own.

## Web server (`lib/streamlit/web/server/`)

**Key endpoints**:
- `/_stcore/stream`: WebSocket for bidirectional messages
- `/_stcore/health`: Health check
- `/_stcore/upload_file/<session>/<file>`: File uploads
- `/media/*`: Media files (images, videos)
- `/component/*`: Custom component v1 resources
- `/_stcore/bidi-components/*`: v2 bidi component resources
- `/_stcore/agent/interact`: Agent API (POST only; off unless `server.enableAgentApi` is set)
- `/_stcore/agent/openapi.json`: The agent API's OpenAPI document (GET; always served, and with the API off it only reports that the API is disabled, via `info.x-streamlit-agent-api`)
- `/_stcore/agent/mcp`: The agent API as a remote MCP server (POST only, JSON-RPC; same switch and checks as the interact route, but answers 400 rather than 403 while the API is off)

**WebSocket handler** (`starlette/starlette_websocket.py`):
```
Browser connects -> Runtime.connect_session()
                 -> Create AppSession
                 -> Browser sends first rerun request
                 -> Start ScriptRunner
                 -> Messages flow bidirectionally
                 -> Browser disconnects -> Runtime.disconnect_session()
```

**Agent sessions** (`runtime/agent/interaction.py`, `starlette/starlette_agent_routes.py`): `POST /_stcore/agent/interact` drives the app without a browser. An agent session is an ordinary `AppSession` whose `AgentSessionClient` buffers ForwardMsgs instead of sending them. Each request becomes a `request_rerun()` call, made directly rather than through `handle_backmsg()` so a failure to start the run surfaces as `internal_error`; the route then waits for `wait_until_settled()` up to `server.agentWaitTimeout` and builds the snapshot JSON off the event loop. A run past the timeout answers 202 `wait_timed_out` and keeps going, so a retry with only `session_id` collects it. `AgentSessionRegistry` hands out opaque `s_<hex>` handles, allows one interaction in flight per session, caps sessions at `server.agentMaxSessions`, and reclaims them after `server.agentSessionTTL` idle. The route applies the WebSocket's Host allow-list and trusted identity headers, refuses any `Origin` not in `server.corsAllowedOrigins`, and never reads cookies. `GET /_stcore/agent/openapi.json` serves the OpenAPI document `runtime/agent/protocol.py` builds from the error catalog and the request validator; with the API off, it only reports that.

`POST /_stcore/agent/mcp` (`runtime/agent/mcp.py`) serves the same protocol over MCP's Streamable HTTP transport, with no MCP session. Its `interact` tool runs the interact route's code path and returns that route's response body as the tool result's text. Its `get_data` tool reads stored media files (table pages as JSON rows) through `MediaFileManager.read_file` after the registry's identity check, and does not take the in-flight lock. `protocol.py` holds both tool descriptions and the inlined input schema. While `browser.gatherUsageStats` is on, `runtime/agent/usage.py` counts each `interact()` call on the counter of the route it came from, HTTP or MCP, each session created, and, with the API off, each POST to either route that passes the Host, Origin, and content-type checks. The next page profile a browser session reports carries the counts. Every response from any of the three routes carries `Link: <openapi.json>; rel="service-desc"`, and the app's `index.html` links the document too.

## Key abstractions

| Interface | Purpose | Default Implementation |
|-----------|---------|------------------------|
| SessionManager | Session lifecycle | WebsocketSessionManager |
| SessionStorage | Session persistence | MemorySessionStorage |
| UploadedFileManager | File uploads | MemoryUploadedFileManager |
| MediaFileStorage | Media files | MemoryMediaFileStorage |
| CacheStorageManager | Cache backend | LocalDiskCacheStorageManager |

## Fragment system (`@st.fragment`)

Fragments enable partial reruns of specific UI sections without re-executing the entire script.

**Key files**:
- `lib/streamlit/runtime/fragment.py`: Fragment decorator and execution logic
- `lib/streamlit/runtime/scriptrunner/script_runner.py`: Fragment-aware execution

**How fragments work**:

```mermaid
sequenceDiagram
    participant User
    participant Widget as Widget in Fragment
    participant WSM as WidgetStateManager
    participant Session as AppSession
    participant Runner as ScriptRunner
    participant Fragment as @st.fragment function

    User->>Widget: Interaction
    Widget->>WSM: setXxxValue(element, value, { fragmentId })
    WSM->>Session: BackMsg with fragment_id
    Session->>Runner: request_rerun(fragment_id)
    Note over Runner: Only executes the fragment function
    Runner->>Fragment: Execute fragment code
    Note over Fragment: Only this section re-renders
    Fragment-->>User: Updated UI (fragment only)
```

**Fragment storage** (`FragmentStorage`):
- Each `AppSession` has a `FragmentStorage` instance
- Stores registered fragment functions by `fragment_id`
- Preserves fragment state across partial reruns

**Fragment identification**:
- Each fragment gets a unique `fragment_id` (hash of function identity + delta-path context)
- Frontend tracks `fragmentIdsThisRun` to know which fragments are active
- Delta messages include `fragment_id` for proper tree updates
- `@st.fragment(key=...)` also indexes that `fragment_id` under the user-facing name in `FragmentStorage` (`"app"` and `"fragment"` are reserved and cannot be used as keys)

**Keyed / event-scoped reruns**:
- `st.rerun("<key>")` or `st.rerun(["k1", "k2"])` from a widget callback (`on_click` / `on_change`) resolves those names to fragment ids and reruns only those fragments, replacing the interaction's default rerun.
- This form is only valid from a callback. Calling it from the main script body or a fragment body raises `StreamlitAPIException`.
- When the interaction's default rerun is app-wide (the widget lives in the main script, not inside a fragment), a sibling callback that returns normally or calls `st.rerun()` escalates the result to a full-app rerun. Interactions originating inside a fragment keep the targeted scope unless a sibling explicitly calls plain `st.rerun()`; a pending `st.switch_page()` is exempt.
- A full-app run prunes `FragmentStorage` down to the fragments that actually executed during it, so a fragment skipped by a `False` conditional loses its key.

**Staleness with fragments**:
- Elements track both `scriptRunId` and `fragmentId`
- During fragment reruns, stale cleanup uses `scriptRunId` + `fragmentIdsThisRun` to prune affected subtrees while preserving unrelated nodes
- Main script elements are preserved during fragment-only reruns

**Outside-container writes**:
- A fragment can write into a container that the script declares outside the fragment body.
- The first such write creates a layout-transparent wrapper block inside that container. See `_needs_outside_wrapper()` and `_get_or_create_outside_wrapper()` in `lib/streamlit/delta_generator.py`.
- The wrapper isolates the writes of one fragment, so repeated fragment reruns overwrite in place instead of appending past the end of the outside container.
- `FragmentStorage` caches each wrapper as an `OutsideContainerWrapper` (`lib/streamlit/runtime/outside_container_wrapper.py`), keyed by fragment and container.
- Before a fragment reruns, the runtime evicts the wrappers whose outside containers this fragment rebuilds, then re-emits and resets the wrappers that survive (`_reset_outside_wrappers()` in `lib/streamlit/runtime/fragment.py`). A full script run clears all wrappers.
- Each wrapper adds a level to the delta path. Code that stores a delta path for a later update must use the path that the write actually reached. See `_block_delta_path` in the `DeltaGenerator` section above.

**Script events for fragments**:
- `FRAGMENT_STOPPED_WITH_SUCCESS`: Fragment completed successfully
- Interrupted fragment runs can still emit `SCRIPT_STOPPED_FOR_RERUN`

## Session reconnection

Sessions can survive temporary disconnections via `SessionStorage`.

**Disconnect vs close**:
- **Disconnect**: WebSocket closes but session preserved in storage (default 2 min TTL)
- **Close**: Session explicitly terminated and cleaned up

**Reconnection flow**:

```mermaid
sequenceDiagram
    participant Browser
    participant WS as WebSocket
    participant SM as SessionManager
    participant Storage as SessionStorage
    participant Session as AppSession

    Note over Browser,Session: Initial connection
    Browser->>WS: Connect
    WS->>SM: connect_session()
    SM->>Session: Create new AppSession
    Session-->>Browser: Session established

    Note over Browser,Session: Temporary disconnect
    Browser->>WS: Disconnect (network issue)
    WS->>SM: disconnect_session()
    SM->>Storage: Mark session inactive
    Note over Storage: Session preserved (TTL: 2 min default)

    Note over Browser,Session: Reconnection
    Browser->>WS: Reconnect with session token
    WS->>SM: connect_session(existing_session_id)
    SM->>Storage: get(existing_session_id)
    Storage-->>SM: Return existing AppSession
    SM-->>Browser: Session restored (state intact)

    Note over Browser,Session: TTL expiration
    Note over Storage: After 2 min without reconnect
    Storage-->>SM: Session entry expires (next connect creates a new AppSession)
```

**Reconnecting to a still-active session**:

An unclean WebSocket close can leave a session still marked active when a new
connection arrives reusing the same `existing_session_id` (before the previous
connection's cleanup runs). In this case `WebsocketSessionManager.connect_session()`
disconnects the stale active session first (moving it to storage) and then
reconnects the new client to it, preserving state instead of creating a brand-new
session and discarding the previous state.

To keep the old and new connections from interfering during this handoff,
`Runtime.disconnect_session()`, `Runtime.handle_backmsg()`, and
`Runtime.handle_backmsg_deserialization_exception()` accept an optional `client`.
When provided, the call is a no-op if the session's current client is no longer
that client, so the old connection's late cleanup or in-flight BackMsgs cannot
disrupt the newly reconnected client.

**Key components**:
- `WebsocketSessionManager` (`lib/streamlit/runtime/websocket_session_manager.py`): Manages session lifecycle
- `MemorySessionStorage` (`lib/streamlit/runtime/memory_session_storage.py`): Default in-memory storage with TTL
- `SessionStorage` interface: Allows custom storage backends

**What's preserved on reconnect**:
- `SessionState` (all user variables and widget values)
- `FragmentStorage` (registered fragments)
- Uploaded files (via `UploadedFileManager`)
- Media files (via `MediaFileManager`)

**What's NOT preserved**:
- WebSocket connection state
- Transport-level delivery guarantees during the disconnect window
- Script execution state (script restarts from beginning)

**Configuration**:
- TTL is controlled by `MemorySessionStorage` (default 120 seconds)
- `MemorySessionStorage` uses `cachetools.TTLCache`; expiry removes stored `SessionInfo` entries and does not invoke an explicit `AppSession.shutdown()` callback path
- Custom `SessionStorage` implementations can use alternative storage strategies

## Media file management (`lib/streamlit/runtime/media_file_manager.py`)

Media files (images, audio, video, and an agent session's Arrow data copies from `elements/lib/agent_data.py`) are managed separately from the protobuf element tree.

**Flow**:
1. `st.image(data)` -> `MediaFileManager.add()` registers file with unique ID
2. File stored in `MediaFileStorage` (default: in-memory)
3. Element proto contains URL: `/media/<file_id>.<ext>`
4. Frontend fetches media via HTTP GET (not WebSocket)
5. Garbage collection removes unused files after script runs

**Key concepts**:
- **Coordinates**: Each file tracks its location in the app (delta path) to handle replacements (e.g., animation frames)
- **Session tracking**: Files are associated with sessions; removed when no sessions reference them
- **Deferred callables**: `st.download_button` with callable data uses `DeferredCallableEntry` for lazy evaluation
- **Reads**: `read_file` returns a stored file for the agent API's MCP `get_data` tool. Only the built-in `MemoryMediaFileStorage` supports it (`can_read_files`); `MediaFileStorage` has no read method, so a host-provided storage serves its files itself

**Multi-server considerations**:
- Media requests may hit different servers than the WebSocket connection
- Solutions: session affinity (sticky sessions) or base64-encode media into element protos

## Custom components (`lib/streamlit/components/`)

Custom components extend Streamlit via iframe-isolated React apps.

**Two API versions**:
- **v1 (legacy)** (`lib/streamlit/components/v1/`): Original `declare_component()` API, assets served via `/component/*`
- **v2 (current)** (`lib/streamlit/components/v2/`): Bidirectional components with improved state management, assets via `/_stcore/bidi-components/*`

**Communication flow**:
```mermaid
sequenceDiagram
    participant Script as User Script
    participant ST as Streamlit Backend
    participant WS as WebSocket
    participant FE as Frontend
    participant IFrame as Component IFrame

    Script->>ST: component_instance(args)
    ST->>WS: ForwardMsg with ComponentInstance proto
    WS->>FE: Render iframe
    FE->>IFrame: postMessage(args)
    Note over IFrame: Component renders with args
    IFrame->>FE: Streamlit.setComponentValue(data)
    FE->>WS: BackMsg with component value
    WS->>ST: Update widget state
    ST->>Script: Trigger rerun, return new value
```

**Key files**:
- `lib/streamlit/components/v1/custom_component.py`: v1 component registration
- `lib/streamlit/components/v2/bidi_component/`: v2 bidirectional implementation
- `component-lib/`: NPM package for building components (`streamlit-component-lib`)
