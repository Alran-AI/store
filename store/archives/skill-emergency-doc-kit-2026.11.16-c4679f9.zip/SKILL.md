---
name: emergency-doc-kit
description: "Summarise what Emergency Doc Kit does in one line. Use when asked to [trigger phrases the user would say]. Produces [the concrete artifact]."
---

# Emergency Doc Kit Skill

One-line summary of the value this skill delivers. <!-- TODO: rewrite -->

## Working from a brief

Deliver the full artifact even from a thin brief — infer and label assumptions, never refuse for missing context. <!-- TODO: tailor -->

## Required Inputs

Ask for (if not already provided), else infer and label:
- <!-- TODO: the inputs to gather -->

## Output Format

<!-- TODO: a concrete template (headings/tables) of the final artifact -->

## Quality Checks

- [ ] <!-- TODO: a check the output must pass before hand-off -->

## Anti-Patterns

- [ ] Do not <!-- TODO: the mistake this skill prevents -->

## Example Trigger Phrases

- "What documents do I need for an emergency?"
- "What would I need if my house burned down?"
- "Build a grab-and-go document kit."
- "Back up our important papers before a disaster."

Run this skill in your browser: https://mohitagw15856.github.io/pm-claude-skills/skill/emergency-doc-kit.html
