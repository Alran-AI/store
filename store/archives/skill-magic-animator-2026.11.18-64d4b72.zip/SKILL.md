---
name: magic-animator
description: AI-powered animation tool for creating motion in logos, UI, icons, and social media assets.
risk: safe
source: community
date_added: "2026-03-07"
---

# Magic Animator Skill

[Magic Animator](https://magicanimator.com/) enables designers to add life to static designs in seconds using AI-driven motion, transforming flat UX into premium, dynamic experiences.

## Context

This skill is essential for improving UX and engagement through high-quality motion. It works best for animating brand assets, interface elements, and micro-interactions.

## When to Use
Trigger this skill when:

- Adding life to a static logo or brand mark to make it memorable.
- Enhancing website/app UI with loaders, animated widgets, or smooth transitions.
- Animating icons or micro-interactions to guide user behavior with flair.

## Execution Workflow

1. **Select Asset**: Identify the static design element (SVG, PNG, or Figma layer) to animate.
2. **Choose Preset/Category**: Select the appropriate domain (Logos, UI, Icons, Social Media) to ensure the motion curves match the context.
3. **Animate**: Use the **AI Animation Assistant** via chat-based prompts to request specific, premium motion (e.g., "Make it feel like a high-end luxury brand reveal" or "Give it a kinetic, elastic pop").
4. **Refine**: If available, edit keyframes for further polish, ensuring easing curves feel natural and high-end.
5. **Export & Integrate**: Export the final animation as **Lottie (JSON)** for web/mobile performance, or **GIF/MP4** for social.

## Strict Rules

- Use only when motion serves the requested product and chosen tools; respect existing design conventions and reduced-motion preferences. Do not force hosted generation, effects or new packages.
- **Purposeful Motion**: Every animation must feel deliberate and premium. Avoid chaotic or overly fast motion that distracts from the core UX.
- **Format Discipline**: Choose a supported format based on measured size, renderer compatibility and accessibility; Lottie is not always smaller or fully compatible.

## Example

**User request:**

> Add life to a static logo or brand mark to make it memorable.

## Limitations
- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.

Verify current product/tool/export availability, asset licenses and provider data/cost authorization. Inspect generated SVG/Lottie content, bound asset size, and test fallback, keyboard interaction and reduced motion. An animation service is not bundled here and output quality is not guaranteed by the guide.
