# Usage-Based Pricing - Detailed Guide

> This file contains the detailed procedure and reference material extracted from `SKILL.md` for focused loading. The root skill defines activation, examples, safety constraints, and limitations.

## Overview

Developers are uniquely sensitive to pricing. They'll calculate unit economics, compare alternatives, and write blog posts about surprise bills. Usage-based pricing works well for developer tools because it aligns cost with value, but it can also create anxiety about unpredictable costs.

The best developer pricing is predictable, transparent, and obviously fair. Developers should be able to estimate their bill before they commit.


## Before You Start

Read the product's existing plan, free-tier rules, usage meters and constraints. The related `free-tier-strategy` guidance is optional and may not be installed; do not assume an upstream absolute directory exists.


## Pricing Page Clarity

All monetary examples and provider comparisons below are illustrative, not current quotes or promised savings. Use supplied evidence, verified current prices and explicit units; unknown inputs remain unknown. No calculation authorizes changing a plan, charging a customer or making a compliance claim.

### Essential Pricing Page Elements

1. **Price per unit, clearly stated**
```
$0.01 per 1,000 API calls
$0.10 per GB stored
$5 per team member
```

2. **Usage calculator**
```
Estimate your monthly cost:
API calls per month: [____]
Storage (GB): [____]

Estimated cost: $XX/month
```

3. **Tier comparison table**
```
                Free        Pro         Enterprise
API calls       10,000/mo   100,000/mo  Unlimited
Storage         1GB         50GB        500GB
Support         Community   Email       Priority
Price           $0          $29/mo      $299/mo
```

4. **FAQ answering real questions**
- "What happens if I exceed my limit?"
- "How do I monitor my usage?"
- "Are there any hidden fees?"
- "Can I set spending limits?"

### Pricing Page Examples

**Excellent: Stripe**
- Simple percentage per transaction
- Clear calculator
- All fees visible
- Volume discounts transparent

**Excellent: Cloudflare**
- Free tier generous
- Paid features clearly differentiated
- Per-feature pricing available
- Enterprise custom pricing framed simply

**Poor patterns:**
- "Contact sales" for any pricing information
- Prices hidden until signup
- Complex unit definitions
- Multiple interdependent metrics

### Price Communication Principles

1. **Lead with simple cases** - Show the "typical" cost first
2. **Reveal complexity gradually** - Edge cases in FAQ, not main pricing
3. **Use real numbers** - "$47/month for a typical SaaS app" beats "$0.001 per request"
4. **Compare to alternatives** - "50% less than AWS" (if true and provable)


## Cost Predictability and Caps

### Why Predictability Matters

Developers fear:
- Unexpected month-end bills
- Usage spikes from bugs or attacks
- Being unable to explain costs to managers
- Services that punish success

### Providing Predictability

**Usage dashboards:**
```
Current billing period: March 1-31

API calls:     45,000 / 100,000 (45%)
Storage:       12GB / 50GB (24%)
Bandwidth:     89GB / 100GB (89%) ⚠️

Projected bill: $47 (current: $38)
```

**Usage alerts:**
```
Alert settings:
[ ] 50% of monthly limit
[x] 75% of monthly limit
[x] 90% of monthly limit
[x] 100% of monthly limit
[ ] Daily usage spike (>2x average)
```

**Spending caps:**
```
Monthly spending cap: $100

When reached:
( ) Hard stop - service pauses
(x) Soft stop - alert and require approval
( ) No stop - continue and alert
```

### Cap Implementation Considerations

**Hard caps:**
- Service stops at limit
- Best for: Development, non-critical
- Risk: Production outages

**Soft caps:**
- Service continues, alerts sent
- Best for: Production, alert required
- Risk: Unexpected overages

**Burst allowance:**
- Short-term overage allowed
- Best for: Handling legitimate spikes
- Risk: Abuse potential

**Automatic scaling:**
- Auto-upgrade tier temporarily
- Best for: Predictable growth
- Risk: Confusion about costs


## Billing Transparency

### The Bill Should Tell a Story

**Bad invoice:**
```
Usage charges: $147.00
Total: $147.00
```

**Good invoice:**
```
API Usage
- Requests: 245,000 @ $0.01/1,000 = $2.45
- Bandwidth: 150GB @ $0.10/GB = $15.00

Compute
- Function invocations: 50,000 @ $0.0001 = $5.00
- Compute time: 10,000 GB-sec @ $0.0000166 = $0.17

Storage
- Database: 25GB @ $0.50/GB = $12.50

Platform fee: $29.00 (Pro plan base)

Subtotal: $64.12
Credits applied: -$10.00 (new user credit)

Total: $54.12
```

### Usage Visibility

**Dashboard requirements:**
- Real-time or near-real-time usage
- Daily/weekly/monthly views
- Breakdown by resource/project
- Comparison to previous periods
- Export for internal analysis

**API for usage data:**
```bash
curl https://api.example.com/usage \
  -H "Authorization: Bearer $API_TOKEN"

{
  "period": "2024-03-01/2024-03-31",
  "api_calls": 245000,
  "bandwidth_gb": 150,
  "cost_to_date": 54.12,
  "projected_cost": 62.00
}
```

### Billing Cycle Best Practices

- **Monthly billing** - Standard, predictable
- **Prepaid credits** - Discount for commitment, reduces uncertainty
- **Annual contracts** - For enterprise, discount for commitment
- **Billing date choice** - Let customers align with their accounting


## Communicating Value vs Cost

### The Value Conversation

Don't just communicate price—communicate value relative to alternatives.

**Alternative cost comparisons:**
```
Running this yourself:
- Server costs: $200/mo
- Engineer time: $5,000/mo
- Maintenance: $500/mo
Total: $5,700/mo

Our service: $99/mo
You save: $5,601/mo
```

**Time savings:**
```
Without [Product]:
- 2 weeks to build
- 4 hours/month to maintain

With [Product]:
- 30 minutes to integrate
- Zero maintenance

Developer time saved: 120+ hours/year
```

### ROI Calculators

For enterprise sales, provide ROI tools:

```
Your company:
- Developers: [10]
- Hours/week on auth per developer: [5]
- Fully-loaded cost/hour: [$150]

Current cost: 10 × 5 × $150 = $7,500/week = $390,000/year (52 weeks)

With [Product]:
- Integration: 20 hours one-time = $3,000
- Annual cost: $12,000
- Maintenance: Near zero

Illustrative first year savings: $390,000 - $3,000 - $12,000 = $375,000
```

### Pricing Justification

When prices seem high, justify with:
1. **Feature completeness** - "Includes what others charge extra for"
2. **Reliability** - "99.99% uptime saves you from outages"
3. **Support** - "Engineering support, not offshore scripts"
4. **Scale** - "Handles 10x traffic without config changes"
5. **Security** - Cite the actual control evidence and the scope/date of any independent assessment; do not call legal compliance "included"


## Competitive Pricing Research

### Understanding the Landscape

**Map competitors by:**
1. Direct competitors (same solution)
2. Adjacent competitors (different approach, same problem)
3. Build-it-yourself (internal development cost)
4. Status quo (doing nothing)

**Pricing model analysis:**
```
Competitor A: $0.015/request, no free tier, 99.9% SLA
Competitor B: $0.008/request, generous free tier, 99.5% SLA
Open source: $0 + hosting costs (~$0.005/request) + maintenance
```

### Pricing Position Options

**Premium pricing:**
- Higher price, higher perceived value
- Works with: Superior product, enterprise focus
- Requires: Clear differentiation

**Value pricing:**
- Comparable price, more features
- Works with: Feature-rich products
- Requires: Clear comparison

**Penetration pricing:**
- Lower price, gain market share
- Works with: Commoditized features
- Requires: Path to profitability

**Usage-aligned pricing:**
- Aligned with customer value
- Works with: Variable usage patterns
- Requires: Clear value correlation

### Competitive Analysis Template

For each competitor:
```
[Competitor Name]
Pricing model: [Per-seat / usage-based / flat]
Free tier: [Yes/No, limits]
Starting price: [$X/mo or $/unit]
Enterprise: [Custom / listed price]
Key differentiator: [Feature/price/market]
Developer sentiment: [From Twitter, HN, Reddit]
```

### Price Testing

**A/B testing considerations:**
- Test different price points (carefully, ethically)
- Test different packaging (bundles vs. à la carte)
- Test annual vs. monthly emphasis
- Test value framing ("save $X" vs. "costs $Y")

**Qualitative research:**
- Win/loss analysis: Why did they choose us/competitor?
- Price sensitivity interviews: What would change their decision?
- Value perception: What do they think is fair?


## Pricing Anti-Patterns

### The Surprise Bill

Developers share horror stories:
- "My $20/month bill became $2,000"
- "A bug caused infinite loops and I owe $500"
- No warning, no cap, no mercy

**Solution:** Spending caps, usage alerts, anomaly detection

### The Pricing Maze

- Requires spreadsheet to calculate
- Different metrics for different features
- Hidden fees discovered later
- Changes frequently without notice

**Solution:** Simple, clear, stable pricing

### The Negotiation Game

- "Contact sales" for all meaningful tiers
- List price is 10x actual price
- Every customer gets different deal
- Penalizes customers who don't negotiate

**Solution:** Transparent pricing, volume discounts listed

### The Bait and Switch

- Free tier gets worse over time
- Prices increase without grandfathering
- Features move from free to paid
- "New pricing" disadvantages existing customers

**Solution:** Grandfathering, clear migration paths, community communication


## Tools

### Billing Platforms

- **Stripe Billing** - Subscription and usage-based billing
- **Orb** - Usage-based billing infrastructure
- **Lago** - Open source billing platform
- **Metronome** - Usage metering and billing
- **Chargebee** - Subscription management

### Usage Metering

- **Segment** - Event tracking for usage
- **Rudderstack** - Open source alternative
- **Custom** - Most companies build their own metering

### Pricing Pages

- **PricingPage.io** - Templates and inspiration
- **ProfitWell** - Pricing analytics
- **Baremetrics** - SaaS metrics and pricing tools

### Competitive Intelligence

- **Competitors.app** - Track competitor pricing changes
- **Manual monitoring** - Sign up for competitor newsletters
- **Community research** - Reddit, HN, Twitter sentiment


## Related Skills

- `@free-tier-strategy` - Free tier design
- `@developer-signup-flow` - Getting to the pricing page
- `@developer-onboarding` - Demonstrating value before price
