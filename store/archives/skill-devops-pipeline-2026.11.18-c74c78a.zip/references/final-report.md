# Final Report — devops-pipeline

Print the final report once per run, after the last Step Completion Report. The step reports score each check; the final report tells the user what changed, what proves it, what is still unknown, and what they must decide.

A **repository write** is any of: writing or merging `.pre-commit-config.yaml`, a workflow file, or `scripts/e2e_test.sh`; creating a `<file>.bak`; running `pre-commit install`; or, in CI minutes optimization, creating its branch, committing a change, writing `.github/CI-BUDGET.md`, or opening its pull request.

## Four required parts, in this order

1. **`Result:`** — the status word first, then one line on what changed or was found.
   - `COMPLETE` — every requested file was written or merged with the user's confirmation, both hook types are installed, and every Step 4 command exited 0. An audit-only run that writes nothing is `COMPLETE` when every Acceptance Criteria item was checked against the existing files. A CI speed audit is `COMPLETE` when the per-job split comes from real runs, or when the static review is done and the report states why no runs were measured; it writes nothing and runs no hooks. A CI minutes optimization is `COMPLETE` when every approved finding was measured and kept or reverted and the pull request is open; with no finding approved yet, it ends after the audit, `COMPLETE` with the findings under `Decision:`.
   - `PARTIAL — <reason>` — the run made at least one repository write, and then one of these happened: `pre-commit validate-config` failed, a Step 4 command exited non-zero, or the user declined a merge or a new file. A check demoted to a later lane under the 60-second rule does not make the run partial; list it under `Uncertainty:`.
   - `BLOCKED — <reason>` — the run stopped before its first repository write: `pre-commit` is not installed, the stack is undetected and the user gave no answer, `origin` is missing and the user did not approve a local-only setup, Repo Sync hit a conflict, or the request needs a paid option the skill declines (`BLOCKED — out of scope: paid runner`, with the free alternatives under `Decision:`).
2. **`Evidence:`** — only checks that ran, each with its command or file and the observed result: the detected stack, each file written or merged (with its `.bak` path), the `validate-config` exit code, the exit code of each `pre-commit run` stage, the two `pre-commit install` calls, and the `scripts/e2e_test.sh` exit code for a CLI project. In an audit-only run, list each Acceptance Criteria item with pass or fail and the file that shows it. A CI speed audit also lists the audit command with the number of runs it read, the per-job queue/setup/work table, the cache check, and one row per finding with its free fix; under `Uncertainty:`, note that the setup/work split matches step names. A CI minutes optimization lists billed minutes per runner SKU and the monthly estimate, the critical path, and for each applied change its commit, the before and after medians of billed minutes and wall time over the runs measured, and whether it was kept or reverted; under `Uncertainty:`, note that the estimate covers one workflow, counts each run's re-run attempts (a job carried over unchanged into a "Re-run failed jobs" attempt counts once), takes medians without cancelled runs but counts cancelled runs at the full median, and leaves out any `unsampled_events`. Never list a check that did not run.
3. **`Uncertainty:`** — what is unknown or untested, labeled apart from verified facts. Always state that the GitHub Actions workflow was not run: the bypass guard, matrix, and deploy jobs first run on the next pull request or push. Also list each foreign hook moved to `<hook>.legacy`, each check demoted with its measured time, each failing hook left open, and each tool or stack choice the user did not confirm.
4. **`Decision:`** — the action that needs the user's approval, or `No approval needed.` Pending approvals include: confirming a merge diff, deleting a `<file>.bak`, deleting a `<hook>.legacy`, and deciding how to fix a failing hook, and, in CI minutes optimization, each named finding awaiting approval and merging the pull request, which the skill never does. Name each other remaining user action on its own line, such as committing the new files and opening a pull request to exercise CI.

Map the step report to the status: `Result: PASS` → `COMPLETE`; `PARTIAL` → `PARTIAL`; `FAIL` → `BLOCKED` when no repository write happened, otherwise `PARTIAL`.

## Example: a complete setup

```text
Result: COMPLETE — pre-commit hooks and a lean CI workflow added for a Python CLI
Evidence:
  Stack: Python 3.12, uv, ruff + mypy + pytest; CLI with 4 subcommands (from --help)
  Wrote: .pre-commit-config.yaml (new), .github/workflows/ci.yml (new), scripts/e2e_test.sh (new)
  pre-commit validate-config: exit 0
  pre-commit run --all-files: exit 0 (ruff-check, ruff-format, mypy, pytest-fast)
  pre-commit run --all-files --hook-stage pre-push: exit 0 (pytest-full, e2e-cli)
  pre-commit install; pre-commit install --hook-type pre-push: both hooks installed
  bash scripts/e2e_test.sh: exit 0
Uncertainty:
  ci.yml has not run on GitHub; the bypass guard and matrix first run on the next pull request.
Decision: No approval needed.
  Remaining action: commit the three files and open a pull request to exercise CI.
```

## Example: a run that stopped before any write

```text
Result: BLOCKED — pre-commit is not installed; no file was written
Evidence:
  command -v pre-commit: not found
  Stack: Node 24, pnpm, eslint + prettier + vitest (from package.json)
Uncertainty: none
Decision: No approval needed.
  Remaining action: install pre-commit (pip install pre-commit or brew install pre-commit), then re-run.
```

## Reader checks

A run's final report passes review when a reader can:

1. **Find the main result** — the first line gives the status and what changed, without reading hook output.
2. **Separate facts from assumptions** — verified claims name the command that ran; untested behavior, such as the CI workflow, is under `Uncertainty:`.
3. **Trace each claim** — each file and check under `Evidence:` names its path or command and its exit code. A passing commit stage does not imply the push stage passed.
4. **See the next decision** — `Decision:` names the approval needed, or states `No approval needed.`, and lists each remaining user action.

Human understanding stays unconfirmed until a user answers these checks. Agent inspection alone cannot confirm it.

## Step report checks per phase

The check names each Step Completion Report prints, per phase:

**Phase: Project Analysis** — checks: `Project detection`, `Existing tooling scan`, `Visibility`, `CLI detection`, `Command enumeration`

**Phase: Pre-commit Configuration** — checks: `Pre-commit setup`, `Commit-stage hooks installed`, `Push-stage hooks installed`, `Modern stage names used`, `E2E script created (if CLI)`

**Phase: GitHub Actions Setup** — checks: `GitHub Actions config`, `CI limited to the four responsibilities`, `Bypass guard runs both stages`, `Matrix off the per-commit path`, `Speed techniques`, `No paid speedups`

**Phase: CI Speed Audit** — checks: `Runs analysed`, `Queue/setup/work split`, `Cache scope checked`, `Free fixes only`

**Phase: CI Minutes Optimization** — checks: `Billed minutes computed`, `Critical path identified`, `Changes approved per finding`, `Before/after measured`, `Kept only above noise`, `No paid runners`, `Nothing merged`

**Phase: Pipeline Verification** — checks: `Commit-stage hooks pass`, `Push-stage hooks pass`, `E2E tests pass (if CLI)`, `Workflow lint`, `No check duplicated across lanes`
