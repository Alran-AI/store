---
name: team-discover
description: Use when explicit manual re-discovery of team context modules is wanted beyond the injected CDR index (/team-discover) — produces a structured match table with relevance assessments.
---

# team-discover

## Overview

The CDR index is injected into the system prompt at session start by
team-boot. The LLM natively matches CDR descriptors against the current
task and reads full module bodies on demand. This native matching happens
per prompt without invoking this skill.

Use `/team-discover` when you want a structured discovery table with
explicit relevance assessments — for example, when starting a complex
feature or verifying which directives apply.

## Relationship to team-boot

`team-boot` is the session bootstrap: it injects the CDR index into the
system prompt via the `session_start` event hook. Per-prompt discovery
matching is **native** — the LLM matches the injected CDR index against the
current message on its own, so `team-boot` does **not** invoke this skill
as part of its bootstrap loop.

`/team-discover` is **user-invoked**: run it when you want an explicit,
structured re-scan with a relevance-rated table (complex features, audits, or
verifying which directives apply). It is not required for normal operation.

## Process

1. Extract domain, technology, patterns, and actions from the task.
2. Scan the CDR index for matching entries.
3. Assess relevance: High / Medium / Low.
4. Read full module bodies for High-relevance entries.
5. Output:

| ID | Module | Type | Descriptor | Relevance |
|----|--------|------|------------|-----------|
| CDR-2026-003 | context_modules/personas/admin.md | Persona | Admin persona | High |

6. Include PDR/ADR/ChDR matches from project indexes if relevant.
7. Include: `_Searched N CDRs, M PDRs, K ADRs, C ChDRs, J matches found._`

## Absent Context

If no CDR index was injected at session start: report `Searched 0 CDRs — index not injected (unconfigured project or hook failure), reading workspace memory directly`, proceed against `docs/adlc/memory/` on disk, and continue the task. Never present on-disk fallback rows as injected context. Recovery: run `/team-diagnose`.

## Unconfigured projects

If team AI directives are not configured, invoke `team-setup`.
