# 完整性检查

本文件保留 v3.0 完整性检查作为历史对照，不是当前运行时路由。当前权威版本为 v5.0；运行时先读 `runtime-read-policy.md`、`read-routing-map.md`、`continuity-closure-map.md`，再读取命中的 v5 包及其必须同读闭包。不能只读本文件就声称完整性检查完成。

以下 v3 包 ID、五闸、章节顺序及“三项”等阈值均是历史框架约定，不是经过验证的评分或当前包文件路径；不得用于替代 v5 七闸、证据核验和安全判断。版本审计可保留以下表格，当前调用按上述 v5 路由查找对应包。

## §1 规则（两条）

1. **高风险概念承担判断作用 → 必须读对应概念卡**：概念不能只按日常词义理解；一旦它在判断中承担解释或行动指导作用，必须读取 `references/concept-cards/` 中的完整卡片。
2. **概念卡触发联读包 → 必须确认同读材料**：如果某个概念属于 v3.0 连续板块（见 §4 联读包表），不能只读单张概念卡，必须确认同读材料完整。

## §2 自检三问

每项输出前内部自问：

1. 我用了哪个概念承担判断作用？我读了它的完整概念卡（含边界、误用、证据要求、修复动作）吗？
2. 如果这个概念属于联读板块，我读了相邻约束吗？我知道前后章节在保护什么吗？
3. 如果来不及读全 → 必须降为开放断言或轻量观察，不能维持强判断。

## §2.1 主题敏感度自检

每次输出先标注 `topic_sensitivity`：

- `low`：抽象概念、低风险思想实验。
- `normal`：普通关系、团队、组织、制度分析。
- `vulnerable`：痛苦、绝望、创伤、无法退出、亲密伤害、求助暗示或主体安全。
- `high-stakes`：法律、医疗、金融、处分、名誉、资源分配、公共记忆、真实机构强判断。

`vulnerable` 主题必须先接住人，再进入框架；不得把痛苦当纯逻辑材料。`high-stakes` 主题默认审计型处理，必须完成证据边界、判断责任、反证/申诉入口和必要查源。二者叠加时，先承接处境，再进入审计。

## §3 快速检查表 —— 概念→概念卡→联读包

| 触发词或判断动作 | 必读概念卡 | 必须联读包 | 降档条件 |
| --- | --- | --- | --- |
| 如何解释反复问题 | `mechanism-candidates.md` | `diagnosis-mainline-pack` | 只有一个候选→降为开放断言 |
| 判断能否做强判断/处置/公开 | `judgment-grades.md` | `judgment-responsibility-pack` | 写不出撤回条件→不得开放断言以上 |
| 给出接受/拒绝、支持/反对、该不该做等方向性判断 | `open-assertion.md` + `judgment-grades.md` | `judgment-responsibility-pack` | 无替代解释、反向条件或行动边界→降为轻量观察 |
| 证据、材料、弱信号、AI 合规 | `evidence-cost.md` | `v3-evidence-visibility-pack` | AI 缺失材料>3项→只能轻量观察 |
| 谁吸收成本/反馈是否写回 | `chengjie-huiliu.md` | `diagnosis-mainline-pack` | 未读完整链→不能判断"回流断裂" |
| 证据不足但必须给方向 | `open-assertion.md` | `judgment-responsibility-pack` + `v3-procedural-judgment-pack` | 若可能被处置化→必须先读退场规则 |
| 换层解释（个人→组织→制度→历史） | `scale-transfer.md` | `framework-use-discipline-pack` + `diagnosis-mainline-pack` | 不得用高尺度取消低尺度责任 |
| 诊断可能改变对象 | `reflexivity.md` | `diagnosis-mainline-pack` | 三层后无新增证据→必须收束 |
| 高权力/申诉/处分/名誉 | `power-closure.md` | `public-power-governance-pack` + `judgment-responsibility-pack` | 缺申诉保护→暂停强判断 |
| 风险紧急但证据不足 | `low-condition-action.md` | `judgment-responsibility-pack` | 只做低风险可撤回动作 |
| 爱/牺牲/照护/开放行动 | `love-open-action.md` | `intimate-love-care-pack` | 不得把爱写成忍耐命令 |
| 谁能改变条件/谁承担成本 | `responsibility-chain.md` | `diagnosis-mainline-pack` | 责任链不完整→降为轻量观察 |
| 退出/转移/外部承接 | `exit-transfer.md` | `intimate-love-care-pack` 或 `public-power-governance-pack` | 无法退出主体→不得要求理想退出 |
| 修复/复盘/道歉/承诺 | `repair-byproduct.md` | `diagnosis-mainline-pack` | 未见真实修复→不得判定"已修复" |
| 锚点/多层锚/跨域互操作 | `anchor-group.md` | `long-evolution-deep-pack` | — |
| 启动/转译/让渡/支撑通道 | `dynamics-group.md` | `long-evolution-deep-pack` | — |
| 行动承接/中层耗竭/结构负荷 | `structure-process-group.md` | `long-evolution-deep-pack` | — |
| 框架失效/证伪/良性消亡 | `framework-governance-falsification.md` | `v3-framework-governance-falsification-pack` | 不得用框架自证框架安全 |
| 共识程序/强判断/开放断言退场 | `procedural-judgment-responsibility.md` | `v3-procedural-judgment-pack` | 开放断言被处置化→立即退场 |
| 沉默/缺席/不透明/弱信号 | `visibility-opacity-weak-signals.md` | `v3-evidence-visibility-pack` | 不得把缺席当不存在 |
| 漂亮报告/AI 合规/选择性证据 | `malicious-compliance-ai-validation.md` | `v3-power-capture-malicious-compliance-pack` + `v3-evidence-visibility-pack` | 3项以上恶意合规信号→停止强判断 |
| 家庭/小团队/非正式关系+持续伤害 | `no-institution-middle-path.md` | `v3-no-institution-middle-path-pack` | 不模拟不存在的制度，不因无制度而停止判断 |
| 无法退出/复杂创伤/无健康基准 | `trapped-subject-trauma-baseline.md` | `v3-trapped-trauma-baseline-pack` | 安全优先，不得要求高风险对抗 |
| 痛苦/绝望/求助暗示/主体安全 | `trapped-subject-trauma-baseline.md` 或相应关系/疗愈卡 | `v3-trapped-trauma-baseline-pack` + `intimate-love-care-pack`（按题材） | 先接住人；不得把问题当纯逻辑题 |
| 爱作为生成事件 | `love-generative-action.md` | `v3-love-generative-action-pack` + `intimate-love-care-pack` | 两条线并行：结构解释线+生成事件线 |
| 隐喻/引经据典/来源透明 | `metaphor-source-transparency.md` | `v3-concept-migration-metaphor-pack` | 直接引用必须可核验，隐喻只负责打开视角 |
| 课程/咨询/AI 工具/认证/商业化 | `accessibility-toolization-split.md` | `v3-toolization-accessibility-pack` | 检查使用门槛债和解释权不平等 |
| 阶段6/熵增/观测递归 | `observation-entropy-contraction.md` | `v3-observation-entropy-contraction-pack` | 写清扩张/收束/停止条件 |
| 表达翻译/文章成文 | 表达翻译协议 | `expression-article-pack` | 术语必须翻译成人话 |

## §4 连续联读包（完整索引）

| 联读包 ID | 中文名 | 触发场景 | 必须同读材料 | 硬失败 |
| --- | --- | --- | --- | --- |
| `framework-use-discipline-pack` | 框架使用纪律包 | 约束 CrossFrame 如何使用：防概念武器化、防教条化、防万能化、防 AI 文本替代证据。 | 使用准则、输出禁忌、本体保护、AI 输出分离和适用性分级。 | 把框架当万能审判、专业替代或人格定性工具。 |
| `judgment-responsibility-pack` | 判断责任包 | 约束开放断言、强判断、命题验证和高责任处置，防止可撤回判断被当成终局裁决。 | 证据成本、判断档位、命题验证、申诉/反证入口、弱信号保护和反俘获。 | 用开放断言绕过强判断验证，或把判断用于处置却没有撤回条件。 |
| `diagnosis-mainline-pack` | 诊断主线包 | 保持对象、事实、尺度、机制候选、五闸、工具箱和诊断维度的连续主线。 | 有限干预、观测登记、诊断档位、主流程、五闸、机制候选和诊断维度。 | 只套机制标签，跳过对象、证据、尺度、责任和观测影响。 |
| `intimate-love-care-pack` | 亲密关系/爱/照护包 | 处理关系、照护、爱、解释劳动和疗愈时，先保护痛苦、安全和边界。 | 亲密关系轻量入口、爱诊断红线、开放行动、修复副产品、责任链和疗愈/转移。 | 把爱写成忍耐命令，把修复责任压回受伤者，或用结构词抹掉痛苦。 |
| `public-power-governance-pack` | 公共制度与权力包 | 处理平台、制度、公共承诺、程序有效性、权力封闭和低权力主体保护。 | 反俘获、程序有效性、弱信号安全、退出转移、公共承诺、偿付和多中心治理。 | 把程序外观当有效程序，把 AI 文本当强证据，或忽略弱信号安全。 |
| `long-evolution-deep-pack` | 长期演化深水区包 | 处理根假设、生命周期、递进、势场、自主解离、治理连续性和文明尺度压力测试。 | 根假设/核心推论、生命周期、递进、势场、解离、调节预警偿付、多中心治理和超大规模压力测试。 | 把阶段写成宿命，把势场写成氛围，把文明尺度写成绝对结论。 |
| `expression-article-pack` | 表达与文章输出包 | 把后台概念翻译成人话、管理/制度/技术语境或文章输出，避免术语墙。 | 对外表达翻译、用户语言闸、推理提纲和文章底稿/正文规则。 | 后台推理存在但前台变成术语墙，或文章只剩概念姿态没有现实入口。 |
| `v3-framework-governance-falsification-pack` | 框架治理与证伪包 | 处理框架自诊、版本治理、根假设暂停、案例库偏差、框架良性消亡和替代框架接口。 | 自诊对象、版本治理、反例登记、暂停使用、案例库失败样本、良性消亡和替代接口。 | 用框架自己的语言证明框架安全，或为了保住框架无限加补丁。 |
| `v3-procedural-judgment-pack` | 程序与判断责任包 | 处理共识程序、概念有效性分级、强判断升级和开放断言被权力捕获后的退场。 | 共识七环节、E0-E4 概念有效性、判断责任、开放断言退场和修复/补偿入口。 | 把名义共识当有效共识，或让开放断言实际进入处置和公共记忆。 |
| `v3-evidence-visibility-pack` | 证据可见性包 | 处理可见性偏误、缺席信号、正当/压制性不透明、弱信号保护和 AI 现实验证边界。 | 缺席信号类别、不透明三分、弱信号六件套、AI 缺失材料清单和证据降档。 | 把沉默当不存在，把不透明当天然合理，或把 AI 报告格式当现实核验。 |
| `v3-power-capture-malicious-compliance-pack` | 权力捕获与恶意合规包 | 处理选择性证据、表演性合规、AI 合规幻觉和结构语言被用来洗白不作为。 | 恶意合规信号、证据选择性、申诉是否改变结果、复核独立性和责任转嫁检查。 | 规则表面被遵守，但弱信号被过滤、申诉无效、责任被结构语言转移。 |
| `v3-no-institution-middle-path-pack` | 无制度基础设施包 | 处理家庭、小团队、亲密关系、临时项目和非正式社群中没有正式复核但风险持续的场景。 | 中间路径原则、保护性开放断言、低暴露记录、外部视角和升级/撤回条件。 | 强行模拟不存在的制度，或因为不能复核就完全不判断。 |
| `v3-trapped-trauma-baseline-pack` | 无法退出与复杂创伤包 | 处理无法退出主体、复杂创伤、无健康基准、初建型修复和创伤建材型结构。 | 安全优先、代理保护、最小自主、低暴露记录、替代出口和首次建立健康基准。 | 要求无法退出者承担理想退出，或把创伤性生存策略误判为偏离健康锚点。 |
| `v3-love-generative-action-pack` | 爱与开放行动生成包 | 把爱定位为不能由既有结构充分推出、但出现后可被追踪的生成事件，而不是解释失败的剩余。 | 结构解释线、生成事件线、真实成本、新通道、新记忆、新责任分配和新承接者。 | 把爱神化为不可分析，或还原成利益/依附/恐惧解释后的剩余垃圾桶。 |
| `v3-concept-migration-metaphor-pack` | 概念迁移与隐喻控制包 | 处理跨尺度迁移前概念闸、隐喻漂移、规范性前提声明和知识谱系透明。 | 六个白话前概念问题、隐喻身份标注、规范性前提公开和来源透明。 | 用跨域隐喻证明因果，或把框架的价值选择伪装成纯经验结论。 |
| `v3-toolization-accessibility-pack` | 工具化与可及性包 | 处理使用门槛债、可及性审计、商业化工具化风险、认证垄断和分支分裂协议。 | 学习债、翻译债、证据债、复核债、退出债、身份债、工具化红线和分裂说明。 | 让框架变成专家垄断、商业交付压力或新的解释权不平等。 |
| `v3-observation-entropy-contraction-pack` | 观测收束与熵增边界包 | 处理阶段 6、熵增操作边界、观测递归扩张条件和必须收束的元规则。 | 发现滞后、修复滞后、复发率、修复副产品、负荷分布、观测扩张/收束条件。 | 无限追踪反应，或把阶段/熵增写成不作为的托词。 |

## §4.1 联读包前置依赖标注

以下三个联读包跨越 v3.0 源文档的不同部分，读取前需确认已有对应的基础概念：

| 联读包 | 跨越源部分 | 前置依赖 |
| --- | --- | --- |
| `intimate-love-care-pack` | Part 1（导读）+ Part 3（边界元假设/爱）+ Part 5（三十二/爱） | 必须先读 Part 1 的 9 个入口概念 + Part 2 的使用准则（2.1 概念武器化防范），再读 Part 5 的三十二（爱与开放性承担行动）时不得跳过三十（无法退出）和三十一（复杂创伤）的前置保护条件 |
| `public-power-governance-pack` | Part 2（反俘获/退出）+ Part 4（十五/公共承诺）+ Part 3（十三/偿付、十四/多中心） | 必须先读 Part 2 的 2.9（诊断可行性与反俘获协议），再读 Part 3 的十三、十四，最后读 Part 4 的十五 |
| `judgment-responsibility-pack` | Part 1（强判断10问）+ Part 2（证据/档位/反俘获）+ Part 5（十七/共识、二十一/概念有效性、三十八/退场） | 必须先读 Part 1 的强判断 10 问和 Part 2 的使用准则（尤其是 2.9 反俘获），再读 Part 5 的程序与退场模块 |

## §4.2 Part 5 连续依赖链

v3.0 第五部分（十六—四十）内部存在精确的前后依赖链，后一节总是在前一节建立的保护机制上追加更具体的条件：

```
十六、框架自诊 ──→ 十七、共识程序 ──→ 十八、根假设证伪 ──→ 十九、案例库登记
                                                                ↓
二十、前概念闸（六个白话问题）←──────────────────────────────────┘
        ↓
二十一、概念有效性分级（E0-E4）
        ↓
二十二、可见性偏误 ──→ 二十三、不透明区分 ──→ 二十四、阶段6熵增边界
        ↓                                            ↓
二十五、观测递归收束 ←────────────────────────────────┘
        ↓
二十六、恶意合规审计 ──→ 二十七、AI 现实验证边界
        ↓
二十八、弱信号保护六件套
        ↓
二十九、无制度中间路径 ──→ 三十、无法退出主体保护
                                ↓
                            三十一、复杂创伤与无健康基准
                                ↓
                            三十二、爱与开放性承担行动
                                ↓
                            三十三、规范性前提声明
                                ↓
三十四、隐喻漂移 ──→ 三十五、知识谱系与来源透明
        ↓
三十六、使用门槛债 ──→ 三十七、工具化与分裂风险
        ↓
三十八、开放断言退场 ──→ 三十九、框架良性消亡 ──→ 四十、总原则
```

使用时不得跳过前置节点直接读取后置节点——例如读三十二（爱）前必须确认已理解三十（无法退出）和三十一（复杂创伤）的保护优先级。

## §5 v3.0 必须联读的高风险组合

- 方向性开放断言 + 接受/拒绝/支持/反对/该不该做：读 `judgment-responsibility-pack`，写清条件、替代解释、撤回条件和行动边界。
- 题设拆分/改良版选项 + 原题二选一：读 `framework-use-discipline-pack`，声明原题设判断与改写题设判断，避免偷换问题。
- 痛苦/绝望/创伤/求助暗示 + 哲学或思想实验：读 `v3-trapped-trauma-baseline-pack`，先承接主体处境，不把痛苦抽象成纯逻辑。
- 开放断言 + 组织处置/名誉/资源/档案：读 `v3-procedural-judgment-pack`，确认是否已经被权力捕获并需要退场。
- AI 报告/合规材料 + 公共或组织判断：读 `v3-evidence-visibility-pack` 与 `v3-power-capture-malicious-compliance-pack`，确认缺失材料和恶意合规风险。
- 弱信号/沉默/无人反对：读 `v3-evidence-visibility-pack`，不得把缺席当成不存在。
- 家庭/小团队/非正式关系 + 持续伤害：读 `v3-no-institution-middle-path-pack`，不要强行模拟制度，也不要完全停止判断。
- 无法退出/依赖/被控制：读 `v3-trapped-trauma-baseline-pack`，优先安全、代理保护和最小自主。
- 爱/照护/牺牲 + 结构解释：读 `v3-love-generative-action-pack` 和 `intimate-love-care-pack`，同时记录结构解释线与生成事件线。
- 跨域隐喻/经典参照/理论上升：读 `v3-concept-migration-metaphor-pack`，标注隐喻身份、相似点、不相似点和误用风险。
- 框架产品化/课程化/AI 工具化：读 `v3-toolization-accessibility-pack`，检查使用门槛债和解释权不平等。
- 长期追踪/高反身对象/阶段 6：读 `v3-observation-entropy-contraction-pack`，写清扩张、收束、停止追踪和降档条件。
- 框架自身是否失效：读 `v3-framework-governance-falsification-pack`，不得用 CrossFrame 自证 CrossFrame。

## §6 概念保真自检

输出前完成以下检查（内部使用，不展示给普通用户）：

| 检查项 | 填写 |
| --- | --- |
| 本次承担判断作用的概念 | |
| 已读取的概念卡 | |
| 概念被翻译成的现实行为 | 谁做了什么、谁承担了什么、什么改变或没有改变 |
| 相邻概念是否被混淆 | 例如承接 vs 回流、反馈 vs 写回、退出转移 vs 放弃 |
| 证据要求是否满足 | 高 / 中 / 低成本证据；弱信号是否需要保护 |
| 输出是否先说人话 | 删掉术语后是否仍能读懂 |
| 判断档位是否匹配 | 轻量观察 / 开放断言 / 完整诊断 / 强判断 / 低条件行动 / 退出转移 |

## §7 降档速查

| 判断 | 条件 |
| --- | --- |
| 可以维持当前档位 | 已读取对应联读包，且没有关键相邻约束缺口 |
| 降为开放断言 | 证据不足或联读不完整，但仍有明确判断靶点 |
| 降为轻量观察 | 概念只能说成标签、不能落到行为；或只有局部概念/材料 |
| 改为低条件行动 | 证据不足但风险紧急，只能做低风险可撤回动作 |
| 暂停强判断 | 影响权利、名誉、资源、处罚、公共记忆，但未完成判断责任包 |
| 退场或转接 | 开放断言被权力捕获，或框架自身在此场景中需降级、转接、退场 |

**硬降档规则**：
- 没读对应概念卡，但概念承担关键判断：先补读，再输出。
- 证据主要来自低成本材料（自评、AI 报告、漂亮文本）：不得进入强判断。
- AI 缺失材料超过三项：只能输出轻量观察、问题清单或保护性开放断言。
- 高责任影响但无申诉、复核、反报复保护：不得进入高责任诊断。
- 撤回条件写不出来：不得输出开放断言以上的判断。
- 未完成必须联读：不能输出强判断。
- 方向性判断写不出替代解释、反向条件和行动边界：不得维持开放断言以上。
- `vulnerable` 主题未先承接痛苦、安全或最小自主：不得进入冷处理式成文。
- `high-stakes` 主题没有证据边界、反证/申诉入口或必要查源：不得进入强判断或公开建议。

## §8 推理提纲显示

最终推理提纲中只显示包名短行：

```text
- 本次连续联读包：诊断主线包 / 判断责任包 / 表达与文章输出包
```

不要把完整的检查表贴给普通用户，除非用户要求审计或完整工作表。

## §9 补充：概念保真降档规则（精简）

- 概念只能说成标签，不能落到行为 → 降为轻量观察或重写表达
- 证据主要来自低成本材料 → 不得进入强判断
- 高责任影响但无申诉、复核、反报复保护 → 不得进入高责任诊断
- 撤回条件写不出来 → 不得输出开放断言以上的判断

## §10 历史详参

以下文件已整合进本文件，保留为按需查阅的详细参考：

- `continuity-bundles.md`：联读包完整索引（原版）
- `v3-source-spine.md`：源文档标题层级与章节顺序
- `v3-section-digest-index.md`：逐节保真摘要
- `source-continuity-check.md`：连续性检查工作表（完整版）
- `concept-fidelity-check.md`：概念保真检查表（完整版）

需要追踪 v3.0 源结构细节、逐节演化对照或完整相邻约束时，仍可查阅上述文件。日常使用应按当前 v5 路由读取，不能以本历史索引替代。
