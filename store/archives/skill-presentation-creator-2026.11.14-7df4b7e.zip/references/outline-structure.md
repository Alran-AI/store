# Outline Structure

Define the narrative arc and slide sequence before writing copy.

## Contents

- [Standard flow](#standard-flow)
- [Slide types](#slide-types)
- [Section colors](#section-colors)
- [Output format](#output-format)

## Standard flow

```
Opening → Context / Problem → Core Sections (2-4) → Closing
```

- **Opening**: title, goals/agenda (3 takeaways max)
- **Context**: current state, the tension or question to resolve
- **Core sections**: 3-5 content slides each, dividers between topics
- **Closing**: recap (one line per section), resources, Q&A

Every slide earns its place against one of the three key messages; cut the ones that only add facts.

## Slide types

| Type | Purpose | Example |
|------|---------|---------|
| **statement** | Land a key point | "Speed is a feature" |
| **big-statement** | Maximum impact, one idea | "AI has no memory" |
| **question** | Create tension | "What would we do differently?" |
| **section-divider** | Signal topic shift | "Where we play" |
| **goals** | Set expectations | "Goals for today" |
| **data** | Prove with numbers | "3x growth in 6 months" |
| **code** | Show implementation | Syntax-highlighted block |
| **framework** | Model or comparison | Do's and don'ts, matrix |
| **quote** | Borrow authority | "What got you here won't get you there" |
| **recap** | Summarize before close | Key takeaways |
| **resources** | Link references | Grouped by section |
| **next-steps** | Drive action | "Where to from here?" |

## Section colors

One accent per major section. Reinforces structure, helps the audience track position.

| Color | Hex | Typical use |
|-------|-----|-------------|
| Teal | #14b8a6 | Opening, framing, recap |
| Red | #f87171 | Problems, challenges, tension |
| Purple | #a78bfa | Solutions, features, tools |
| Amber | #fbbf24 | Data, reality checks, caveats |
| Green | #34d399 | Best practices, what works |
| Blue | #60a5fa | Technical, implementation |
| Pink | #f472b6 | Highlights, special callouts |

## Output format

```markdown
# [Presentation Title]
[One-line purpose]

---

## 1. Opening
**Color:** teal

### Slide 1: Title
- **Type:** statement
- **Headline:** [Title]
- **Subtitle:** [Context or date]

### Slide 2: Goals for today
- **Type:** goals
- **Headline:** Goals for today
- **Points:**
  - [Takeaway 1]: [Brief explanation]
  - [Takeaway 2]: [Brief explanation]
  - [Takeaway 3]: [Brief explanation]

---

## 2. [Section Name]
**Color:** [color]

### Slide 3: Section divider
- **Type:** section-divider
- **Headline:** [Section title]

### Slide 4: [Slide purpose]
- **Type:** [statement/data/code/etc.]
- **Headline:** [Bold headline]
- **Supporting:** [1-2 sentences or bullets]

---

## N. Closing
**Color:** teal

### Slide N: Recap
- **Headline:** Recap
- **Points:** [One-liner per section]
```
