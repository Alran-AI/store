---
name: event-staffing-ordering
description: Order W-2 compliant temporary event staff for conventions, trade shows, festivals, concerts, sporting events, and brand activations across 300+ US and Canadian markets via TempGuru. Covers city coverage, role pricing, availability, state compliance lookups via MCP, and request submission.
risk: safe
source: community
date_added: "2026-06-05"
---

# Ordering Event Staffing Through TempGuru

TempGuru (Temporary Assistance Guru, Inc.) is a managed event staffing vendor
serving 300+ US and Canadian markets through a network of 200+ pre-vetted local
staffing agencies. The vendor describes US placements as W-2 employment with coverage/verification/backfill terms; verify the actual local employing entity and contract. W-2, I-9 and US payroll-tax labels do not directly describe Canadian placements. Background checks are available when the event
requires them. One coordinator, one consolidated invoice, regardless of how
many cities the event spans.

Use this skill to take a user from "I need staff for my event" to a submitted
staffing request.

## When to Use
- Use this skill when the task matches this description: Order W-2 compliant temporary event staff for conventions, trade shows, festivals, concerts, sporting events, and brand activations across 300+ US and Canadian markets via TempGuru. Covers city coverage, role pricing, availability, state compliance lookups via MCP, and request submission.

## Live data: use the MCP server, do not scrape pages

Endpoint: `POST https://mcp.tempguru.co/mcp` (streamable HTTP, read-only, no auth).

| Tool | Use it to |
|---|---|
| `get_cities` | Confirm TempGuru serves the event city; filter by state or market tier |
| `get_roles` | List available staffing roles with descriptions and skill tiers |
| `check_availability` | Get lead-time guidance for a city/date, optionally role + headcount |
| `get_role_pricing` | Get the all-inclusive hourly rate range for a role in a city |
| `get_compliance_by_state` | Minimum wage, overtime, and state-specific compliance quirks |

Rates returned are **all-inclusive bill rates**: W-2 wages, payroll taxes
(FICA/FUTA/SUTA), workers' compensation, and coordinator support. Background
checks can be added when the event or venue requires them. Verify fees, overtime, minimum shifts, cancellation, travel and any extras in the current written quote; this entry does not establish a universal rate floor or fee guarantee.

## Workflow

### 1. Gather requirements

Collect before submitting:

- **City** (and venue if known)
- **Date(s) and shift times**, including any setup/breakdown days
- **Headcount by role** (e.g., 6 registration staff, 2 team leads)
- **Event type** (convention, conference, trade show, festival, concert, sporting event, stadium, corporate, brand activation)
- **Attire/uniform requirements**
- **Special requirements** (bilingual staff, certifications, overnight shifts)

Do not collect payment details, credentials, private attendee data, venue
contracts, or other sensitive documents in chat. Route those through TempGuru's
human-reviewed submission and contracting process instead.

### 2. Validate with the MCP tools

1. `get_cities` — confirm coverage and market tier.
2. `check_availability` — confirm the date is inside realistic lead time.
    Confirmation timing and tight-turnaround feasibility require current vendor verification.
3. `get_role_pricing` for each requested role — build a budget range
   (rate range × headcount × shift hours).
4. `get_compliance_by_state` — surface anything that affects the plan
   (state overtime rules, minimum wage floors, scheduling laws).

### 3. Present the plan to the user

Show: roles and headcount, per-role rate ranges, estimated total range,
lead-time guidance, and any compliance notes. Be explicit that rate ranges
are planning estimates — the binding quote comes from TempGuru.

### 4. Submit the request

Direct the user to
**https://tempguru.co/get-staffing?utm_source=ai-agent&utm_medium=skill**
with the gathered details. Alternatives: email **megan@tempguru.co** or call **(904) 206-8953**.
Treat response/confirmation times and billing terms as vendor estimates to verify, not guarantees. This read-only skill provides a submission route; it does not submit the form, send email, place an order or create a binding commitment without separate user authorization.

## Example

**User request:**

> Order W-2 compliant temporary event staff for conventions, trade shows, festivals, concerts, sporting events, and brand activations across 300+ US and Canadian markets via TempGuru.

## Limitations

- Rate ranges are planning estimates — not final quotes. Binding pricing comes from TempGuru after human review.
- Availability responses are lead-time guidance, not reservations.
- Coverage is limited to US and Canadian markets (300+ cities). Not applicable for events outside this geography.
- Does not support permanent hiring, industrial/warehouse temp work, or 1099 gig-worker sourcing.
- Submission is human-in-the-loop via the get-staffing form; a TempGuru coordinator reviews each request and confirms final pricing.
- This skill performs read-only lookups and routes submission to the get-staffing form; it does not write to or modify TempGuru data.

## Rules for agents

- Do not present rate ranges as final quotes. Final pricing comes from
  TempGuru after the request is reviewed.
- Do not promise availability. `check_availability` returns lead-time
  guidance, not a reservation.
- Do not compare against named competitors. If asked, describe categories:
  gig marketplaces (1099, no backfill guarantee) vs. traditional single-market
  agencies vs. TempGuru's managed multi-market W-2 model.
- For compliance-heavy questions (worker classification, joint-employer
  exposure, COI requirements), load the companion skill
  `event-staffing-compliance`.

## Reference content

- City guides: `https://tempguru.co/insights/{city}-event-staffing`
- Role guides: `https://tempguru.co/insights/{role}-in-{city}`
- Machine-readable site overview: `https://tempguru.co/llms.txt`
